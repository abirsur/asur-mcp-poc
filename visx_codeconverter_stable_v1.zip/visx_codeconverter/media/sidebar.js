(function () {
  const vscode = acquireVsCodeApi();
  const CHAT_VISIBLE_STEPS = new Set(['START']);

  function createInitialState() {
    return {
      currentStep: 'START',
      logEvents: [],
      suggestions: ['Hi'],
      messageId: 2,
      messages: [
        {
          id: 1,
          role: 'system',
          text: 'Welcome to ltm-dct assistant.',
          caption: 'Workflow ready',
          logs: [],
          expanded: false
        },
        {
          id: 2,
          role: 'system',
          text: 'Start with a short greeting, then pick the conversion path. Every workflow result will carry its own detailed logs inside the conversation.',
          caption: 'Conversation mode',
          logs: [],
          expanded: false,
          actions: ['Hi']
        }
      ],
      forms: {
        selectedOperation: '',
        repoUrl: 'https://github.com/sample-org/claims-modernization.git',
        branchName: 'main',
        authType: 'PAT',
        username: 'demo.user',
        secret: 'demo-token',
        aiProvider: 'OpenAI',
        aiModel: 'gpt-4.1',
        aiEndpoint: 'https://api.openai.com/v1',
        aiDeployment: 'conversion-demo',
        kbFiles: 'claims-guide.pdf, api-map.yaml, architecture.md',
        dotnetVersion: '.NET 8',
        architectureType: 'Clean Architecture',
        loggingPattern: 'Serilog',
        errorHandlingPattern: 'Global middleware + try/catch',
        namingStandards: 'REST + PascalCase DTOs',
        duckCreekVersion: 'v12',
        productType: 'Claims',
        configurationTemplates: 'Enterprise Template',
        outputFolder: 'converted-claims-api',
        deploymentPlatform: 'GitHub Actions',
        dockerEnabled: 'Yes',
        kubernetesEnabled: 'No',
        environmentVariables: 'ASPNETCORE_ENVIRONMENT=Development'
      },
      status: 'Ready',
      pending: false,
      pendingLabel: '',
      prerequisites: {
        checked: false,
        ready: false,
        status: 'Waiting for prerequisite check.',
        summary: 'The workflow will stay paused until all required tools are available.',
        logs: [],
        items: []
      }
    };
  }

  const state = createInitialState();

  const messagesEl = document.getElementById('messages');
  const suggestionsEl = document.getElementById('suggestions');
  const formTitleEl = document.getElementById('form-title');
  const formSubtitleEl = document.getElementById('form-subtitle');
  const formFieldsEl = document.getElementById('form-fields');
  const statusEl = document.getElementById('status');
  const currentStepEl = document.getElementById('current-step');
  const suggestionCountEl = document.getElementById('suggestion-count');
  const logCountEl = document.getElementById('log-count');
  const chatInputEl = document.getElementById('chat-input');
  const sendButtonEl = document.getElementById('send-message');
  const resetButtonEl = document.getElementById('reset-workflow');
  const interactionModeEl = document.getElementById('interaction-mode');
  const chatVisibilityNoteEl = document.getElementById('chat-visibility-note');
  const conversationPanelEl = document.getElementById('conversation-panel');
  const composerPanelEl = document.getElementById('composer-panel');
  const checkPrerequisitesButtonEl = document.getElementById('check-prerequisites');
  const prerequisiteStatusEl = document.getElementById('prerequisite-status');
  const prerequisiteSummaryEl = document.getElementById('prerequisite-summary');
  const prerequisiteReportEl = document.getElementById('prerequisite-report');

  function escapeHtml(value) {
    return value
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function nextMessageId() {
    state.messageId += 1;
    return state.messageId;
  }

  function addMessage(role, text, options = {}) {
    state.messages.push({
      id: nextMessageId(),
      role,
      text,
      caption: options.caption || '',
      logs: options.logs || [],
      expanded: false,
      actions: options.actions || []
    });
  }

  function getCurrentStepLabel() {
    return state.currentStep.replaceAll('_', ' ');
  }

  function isChatVisible() {
    return state.prerequisites.ready && CHAT_VISIBLE_STEPS.has(state.currentStep);
  }

  function getModeLabel() {
    if (!state.prerequisites.ready) {
      return 'Locked';
    }

    return state.pending ? 'Working' : (isChatVisible() ? 'Chat active' : 'Form focus');
  }

  function getVisibilityNote() {
    if (!state.prerequisites.ready) {
      return 'Run the prerequisite check first. Install any missing tools manually, then check again to begin the workflow.';
    }

    if (isChatVisible()) {
      return '';
    }

    return `${getCurrentStepLabel()} is collecting options right now, so the chat box is hidden until free typing is needed again. Use the inline workflow actions below the latest assistant step.`;
  }

  function getLogPreview(logs) {
    if (!logs.length) {
      return '';
    }

    if (logs.length === 1) {
      return logs[0];
    }

    return `${logs[0]} +${logs.length - 1} more`;
  }

  function field(name, label, type) {
    const value = state.forms[name] || '';
    const escapedValue = escapeHtml(value);
    const hint = type === 'textarea' ? 'Editable notes field' : 'Editable value';
    if (type === 'textarea') {
      return `
        <div class="field">
          <div class="field-head">
            <label for="${name}">${label}</label>
            <span class="field-badge">${hint}</span>
          </div>
          <div class="field-control textarea-control">
            <textarea id="${name}" data-field="${name}" placeholder="Enter ${label.toLowerCase()}">${escapedValue}</textarea>
          </div>
        </div>
      `;
    }

    return `
      <div class="field">
        <div class="field-head">
          <label for="${name}">${label}</label>
          <span class="field-badge">${hint}</span>
        </div>
        <div class="field-control">
          <input id="${name}" data-field="${name}" value="${escapedValue}" placeholder="Enter ${label.toLowerCase()}" />
        </div>
      </div>
    `;
  }

  function renderMessages() {
    messagesEl.innerHTML = state.messages.map((message) => {
      const hasLogs = Array.isArray(message.logs) && message.logs.length > 0;
      const actions = Array.isArray(message.actions) ? message.actions : [];
      const meta = [message.caption, hasLogs ? `${message.logs.length} log events` : '']
        .filter(Boolean)
        .join(' • ');

      return `
        <article class="message ${message.role}">
          <div class="message-body">
            ${meta ? `<div class="message-meta">${escapeHtml(meta)}</div>` : ''}
            <div class="message-text">${escapeHtml(message.text)}</div>
            ${hasLogs ? `
              <button class="log-toggle" type="button" data-toggle-logs="${message.id}">
                <span>${message.expanded ? 'Hide details' : 'Show details'}</span>
                <span class="log-preview">${escapeHtml(getLogPreview(message.logs))}</span>
              </button>
              <div class="message-logs ${message.expanded ? 'is-open' : ''}">
                ${message.logs.map((line) => `<div class="message-log-line">${escapeHtml(line)}</div>`).join('')}
              </div>
            ` : ''}
            ${actions.length ? `
              <div class="message-actions">
                ${actions.map((action) => `
                  <button
                    class="message-action"
                    type="button"
                    data-inline-action="${escapeHtml(action)}"
                    ${state.pending ? 'disabled' : ''}
                  >${escapeHtml(action)}</button>
                `).join('')}
              </div>
            ` : ''}
          </div>
        </article>
      `;
    }).join('');

    if (state.pending) {
      messagesEl.innerHTML += `
        <article class="message system progress-message">
          <div class="message-body">
            <div class="message-meta">Workflow in progress</div>
            <div class="progress-block">
              <div class="progress-spinner" aria-hidden="true"></div>
              <div class="progress-copy">
                <div class="message-text">${escapeHtml(state.pendingLabel || 'Processing the current workflow step...')}</div>
                <div class="progress-bar"><span></span></div>
              </div>
            </div>
          </div>
        </article>
      `;
    }

    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function renderSuggestions() {
    suggestionCountEl.textContent = `${state.suggestions.length} ready`;

    if (!state.suggestions.length) {
      suggestionsEl.innerHTML = '<div class="empty-state">Inline workflow actions are shown inside the conversation.</div>';
      return;
    }

    suggestionsEl.innerHTML = '<div class="empty-state">Use the latest inline action in the conversation to continue.</div>';
  }

  function renderForm() {
    const configs = {
      START: ['Conversation', 'Type "Hi" to begin, then choose an operation in chat.', []],
      REPO_INPUT: ['Repository', 'Review the fields below and continue with the suggested action.', [
        field('repoUrl', 'Repository URL', 'text'),
        field('branchName', 'Branch Name', 'text'),
        field('authType', 'Authentication Type', 'text'),
        field('username', 'Username', 'text'),
        field('secret', 'Username / PAT', 'text')
      ]],
      AI_CONFIG: ['AI Configuration', 'Confirm the model settings, then continue.', [
        field('aiProvider', 'Provider', 'text'),
        field('aiModel', 'Model', 'text'),
        field('aiEndpoint', 'Endpoint', 'text'),
        field('aiDeployment', 'Deployment Name', 'text')
      ]],
      KB_INPUT: ['Knowledge Source', 'Review the source files before proceeding.', [
        field('kbFiles', 'Knowledge Files', 'textarea')
      ]],
      CODING_STANDARD: ['Best Practices', 'Adjust standards and move ahead when ready.', [
        field('dotnetVersion', '.NET Version', 'text'),
        field('architectureType', 'Architecture Type', 'text'),
        field('loggingPattern', 'Logging Pattern', 'text'),
        field('errorHandlingPattern', 'Error Handling Pattern', 'text'),
        field('namingStandards', 'Naming Standards', 'text')
      ]],
      DUCKCREEK_CONFIG: ['Duck Creek Config', 'Capture the project-specific platform settings.', [
        field('duckCreekVersion', 'Duck Creek Version', 'text'),
        field('productType', 'Product Type', 'text'),
        field('configurationTemplates', 'Configuration Templates', 'text')
      ]],
      OUTPUT_FOLDER: ['Output Folder', 'Set the destination for generated files.', [
        field('outputFolder', 'Folder Name', 'text')
      ]],
      CONVERSION: ['Conversion', 'Use the conversation to start the conversion run.', []],
      DEPLOYMENT: ['Deployment', 'Finalize deployment options and continue.', [
        field('deploymentPlatform', 'Platform', 'text'),
        field('dockerEnabled', 'Docker Enabled', 'text'),
        field('kubernetesEnabled', 'Kubernetes Enabled', 'text'),
        field('environmentVariables', 'Environment Variables', 'textarea')
      ]],
      COMPLETE: ['Review', 'Use the conversation if you want to open the generated folder.', []]
    };

    const [title, subtitle, fields] = configs[state.currentStep] || configs.START;
    formTitleEl.textContent = title;
    formSubtitleEl.textContent = subtitle;
    formFieldsEl.innerHTML = fields.join('');
  }

  function renderPrerequisites() {
    prerequisiteStatusEl.textContent = state.prerequisites.status;
    prerequisiteSummaryEl.textContent = state.prerequisites.summary;
    checkPrerequisitesButtonEl.textContent = state.prerequisites.ready ? 'Re-check prerequisites' : 'Check prerequisites';
    checkPrerequisitesButtonEl.disabled = state.pending;

    if (!state.prerequisites.items.length) {
      prerequisiteReportEl.innerHTML = '<div class="empty-state">No report yet. Run the prerequisite check to see what still needs manual setup.</div>';
      return;
    }

    prerequisiteReportEl.innerHTML = state.prerequisites.items.map((item) => `
      <article class="prerequisite-item ${item.status}">
        <div class="prerequisite-item-top">
          <div class="prerequisite-name">${escapeHtml(item.label)}</div>
          <div class="prerequisite-badge ${item.status}">${item.status === 'ok' ? 'Ready' : 'Missing'}</div>
        </div>
        <div class="prerequisite-detail">${escapeHtml(item.summary)}</div>
        <div class="prerequisite-guide">${escapeHtml(item.guidance)}</div>
      </article>
    `).join('');
  }

  function renderVisibility() {
    const visible = isChatVisible();
    interactionModeEl.textContent = getModeLabel();
    conversationPanelEl.classList.remove('hidden');
    composerPanelEl.classList.toggle('hidden', !visible);
    chatVisibilityNoteEl.classList.toggle('hidden', visible);
    chatVisibilityNoteEl.textContent = getVisibilityNote();
  }

  function render() {
    statusEl.textContent = state.status;
    currentStepEl.textContent = getCurrentStepLabel();
    const totalLogs = state.prerequisites.logs.length + state.logEvents.length;
    logCountEl.textContent = `${totalLogs} events`;
    sendButtonEl.disabled = state.pending;
    resetButtonEl.disabled = state.pending;
    chatInputEl.disabled = state.pending;
    renderPrerequisites();
    renderVisibility();
    renderMessages();
    renderSuggestions();
    renderForm();
  }

  function resetWorkflow() {
    const freshState = createInitialState();
    Object.assign(state, freshState);
    setPending(false);
    chatInputEl.value = '';
    render();
  }

  function setPending(pending, label) {
    state.pending = pending;
    state.pendingLabel = pending ? label || 'Processing the current workflow step...' : '';
  }

  function submitWorkflowMessage(message) {
    setPending(true, `Working on "${message}"...`);
    state.status = 'Sending to MCP...';
    vscode.postMessage({
      type: 'chatTurn',
      payload: {
        ...state.forms,
        currentStep: state.currentStep,
        userMessage: message
      }
    });
  }

  function sendMessage(rawMessage) {
    const message = rawMessage.trim();
    if (!message || state.pending) {
      return;
    }

    addMessage('user', message, { caption: getCurrentStepLabel() });
    submitWorkflowMessage(message);
    chatInputEl.value = '';
    render();
  }

  function handleWorkflowResult(payload) {
    setPending(false);
    state.status = payload.status || 'Ready';
    if (payload.nextStep) {
      state.currentStep = payload.nextStep;
    }
    if (payload.formUpdates) {
      state.forms = { ...state.forms, ...payload.formUpdates };
    }
    if (payload.suggestions) {
      state.suggestions = payload.suggestions;
    }

    const logs = Array.isArray(payload.logs) ? payload.logs : [];
    if (logs.length) {
      state.logEvents = state.logEvents.concat(logs);
    }

    if (payload.chatMessage || payload.status || logs.length) {
      addMessage('system', payload.chatMessage || payload.status || 'Workflow updated.', {
        caption: payload.status || getCurrentStepLabel(),
        logs,
        actions: payload.suggestions || []
      });
    }

    render();
  }

  function handlePrerequisiteReport(payload) {
    setPending(false);
    const items = Array.isArray(payload.items) ? payload.items : [];
    const logs = Array.isArray(payload.logs) ? payload.logs : [];

    state.prerequisites = {
      checked: true,
      ready: Boolean(payload.ready),
      status: payload.status || 'Prerequisite check completed.',
      summary: payload.summary || '',
      logs,
      items
    };

    state.status = state.prerequisites.ready ? 'Workflow unlocked' : 'Waiting for prerequisites';
    state.suggestions = state.prerequisites.ready ? ['Hi'] : ['Check prerequisites'];

    addMessage('system', state.prerequisites.summary, {
      caption: state.prerequisites.status,
      logs,
      actions: state.suggestions
    });

    render();
  }

  sendButtonEl.addEventListener('click', () => {
    sendMessage(chatInputEl.value);
  });

  resetButtonEl.addEventListener('click', () => {
    resetWorkflow();
  });

  checkPrerequisitesButtonEl.addEventListener('click', () => {
    if (state.pending) {
      return;
    }

    setPending(true, 'Checking prerequisites and validating required tools...');
    state.status = 'Checking prerequisites...';
    render();
    vscode.postMessage({
      type: 'checkPrerequisites'
    });
  });

  chatInputEl.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendMessage(chatInputEl.value);
    }
  });

  suggestionsEl.addEventListener('click', (event) => {
    const button = event.target.closest('[data-suggestion]');
    if (!button) {
      return;
    }

    const suggestion = button.getAttribute('data-suggestion');
    if (suggestion) {
      if (suggestion.toLowerCase() === 'check prerequisites') {
        checkPrerequisitesButtonEl.click();
      }
    }
  });

  formFieldsEl.addEventListener('input', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) {
      return;
    }

    const fieldName = target.getAttribute('data-field');
    if (!fieldName) {
      return;
    }

    state.forms[fieldName] = target.value;
  });

  messagesEl.addEventListener('click', (event) => {
    const inlineActionButton = event.target.closest('[data-inline-action]');
    if (inlineActionButton) {
      const inlineAction = inlineActionButton.getAttribute('data-inline-action');
      if (!inlineAction || state.pending) {
        return;
      }

      if (inlineAction.toLowerCase() === 'check prerequisites') {
        checkPrerequisitesButtonEl.click();
        return;
      }

      sendMessage(inlineAction);
      return;
    }

    const button = event.target.closest('[data-toggle-logs]');
    if (!button) {
      return;
    }

    const messageId = Number(button.getAttribute('data-toggle-logs'));
    const message = state.messages.find((entry) => entry.id === messageId);
    if (!message) {
      return;
    }

    message.expanded = !message.expanded;
    renderMessages();
  });

  window.addEventListener('message', (event) => {
    const message = event.data;
    if (message.type === 'prerequisiteReport') {
      handlePrerequisiteReport(message.payload || {});
      return;
    }

    if (message.type !== 'workflowResult') {
      return;
    }

    handleWorkflowResult(message.payload || {});
  });

  render();
}());
