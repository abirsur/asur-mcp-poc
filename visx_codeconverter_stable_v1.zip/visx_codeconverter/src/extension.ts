import * as vscode from 'vscode';
import { McpClient } from './mcpClient';
import { PrerequisiteChecker } from './prerequisiteChecker';
import { PythonRuntimeManager } from './pythonRuntime';
import { SidebarViewProvider } from './sidebar/SidebarViewProvider';

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  const runtimeManager = new PythonRuntimeManager(context);
  const mcpClient = new McpClient(context, runtimeManager);
  const prerequisiteChecker = new PrerequisiteChecker(context);
  const sidebarViewProvider = new SidebarViewProvider(context, mcpClient, prerequisiteChecker);

  context.subscriptions.push(
    runtimeManager,
    mcpClient,
    vscode.window.registerWebviewViewProvider('ltmDctAssistant.sidebarView', sidebarViewProvider),
    vscode.commands.registerCommand('ltmDctAssistant.focusChat', async () => {
      await vscode.commands.executeCommand('workbench.view.extension.ltmDctAssistant');
    })
  );
}

export function deactivate(): void {
  // Backend process disposal is handled by the subscription lifecycle.
}
