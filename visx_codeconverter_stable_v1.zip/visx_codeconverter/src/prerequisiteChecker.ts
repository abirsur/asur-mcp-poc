import * as vscode from 'vscode';
import { spawn } from 'child_process';

interface PythonCandidate {
  command: string;
  args: string[];
  label: string;
}

export interface PrerequisiteItem {
  id: string;
  label: string;
  status: 'ok' | 'missing';
  summary: string;
  guidance: string;
}

export interface PrerequisiteReport {
  ready: boolean;
  status: string;
  summary: string;
  logs: string[];
  items: PrerequisiteItem[];
}

export class PrerequisiteChecker {
  constructor(private readonly context: vscode.ExtensionContext) {}

  async checkAll(): Promise<PrerequisiteReport> {
    const items: PrerequisiteItem[] = [];
    const logs: string[] = ['[CHECK] Starting prerequisite validation'];

    items.push(await this.checkWorkspace());
    items.push(await this.checkPython());
    items.push(await this.checkCommand({
      id: 'git',
      label: 'Git',
      commands: [{ command: 'git', args: ['--version'] }],
      successSummary: (output) => `Detected ${output}`,
      missingSummary: 'Git was not detected.',
      guidance: 'Install Git and confirm `git --version` works in a new terminal window.'
    }));
    items.push(await this.checkCommand({
      id: 'dotnet',
      label: '.NET SDK',
      commands: [{ command: 'dotnet', args: ['--version'] }],
      successSummary: (output) => `Detected .NET SDK ${output}`,
      missingSummary: '.NET SDK was not detected.',
      guidance: 'Install the .NET SDK, then verify `dotnet --version` from your terminal.'
    }));

    for (const item of items) {
      const prefix = item.status === 'ok' ? '[OK]' : '[MISSING]';
      logs.push(`${prefix} ${item.label}: ${item.summary}`);
      if (item.status === 'missing') {
        logs.push(`[GUIDE] ${item.guidance}`);
      }
    }

    const ready = items.every((item) => item.status === 'ok');
    logs.push(ready ? '[CHECK] All prerequisites passed' : '[CHECK] Prerequisites still missing');

    return {
      ready,
      status: ready ? 'Prerequisites passed.' : 'Prerequisites need attention.',
      summary: ready
        ? 'All prerequisite checks passed. You can start the workflow now.'
        : 'Review the missing items below, install them manually, then click Check prerequisites again.',
      logs,
      items
    };
  }

  private async checkWorkspace(): Promise<PrerequisiteItem> {
    const hasWorkspace = Boolean(vscode.workspace.workspaceFolders?.length);
    return {
      id: 'workspace',
      label: 'Open Workspace',
      status: hasWorkspace ? 'ok' : 'missing',
      summary: hasWorkspace
        ? `Workspace detected: ${vscode.workspace.workspaceFolders?.[0]?.name ?? 'current workspace'}`
        : 'No workspace folder is open.',
      guidance: 'Open the project folder in VS Code before starting the conversion workflow.'
    };
  }

  private getPythonCandidates(): PythonCandidate[] {
    const configured = vscode.workspace.getConfiguration('python').get<string>('defaultInterpreterPath');
    const candidates: PythonCandidate[] = [];
    const seen = new Set<string>();
    const addCandidate = (candidate: PythonCandidate): void => {
      const key = `${candidate.command} ${candidate.args.join(' ')}`.trim();
      if (!seen.has(key)) {
        seen.add(key);
        candidates.push(candidate);
      }
    };

    if (configured) {
      addCandidate({ command: configured, args: [], label: configured });
    }

    if (process.platform === 'win32') {
      addCandidate({ command: 'py', args: ['-3.14'], label: 'py -3.14' });
      addCandidate({ command: 'py', args: [], label: 'py' });
      addCandidate({ command: 'python', args: [], label: 'python' });
      return candidates;
    }

    addCandidate({ command: 'python3.14', args: [], label: 'python3.14' });
    addCandidate({ command: 'python3', args: [], label: 'python3' });
    addCandidate({ command: 'python', args: [], label: 'python' });
    return candidates;
  }

  private async checkPython(): Promise<PrerequisiteItem> {
    const unsupportedVersions: string[] = [];

    for (const candidate of this.getPythonCandidates()) {
      try {
        const output = await this.runAndCapture(candidate.command, [...candidate.args, '--version']);
        const version = this.parsePythonVersion(output);
        if (version && this.isSupportedPython(version)) {
          return {
            id: 'python',
            label: 'Python 3',
            status: 'ok',
            summary: `Detected Python ${version}`,
            guidance: 'Install Python 3.14 and ensure it is available from your terminal.'
          };
        }

        if (version) {
          unsupportedVersions.push(`Python ${version} via ${candidate.label}`);
        }
      } catch {
        // Continue to the next candidate.
      }
    }

    const summary =
      unsupportedVersions.length > 0
        ? `Unsupported Python version detected. Found ${unsupportedVersions.join(', ')}.`
        : 'Python 3.14 was not detected.';

    return {
      id: 'python',
      label: 'Python 3',
      status: 'missing',
      summary,
      guidance: 'Install Python 3.14 and ensure `python`, `python3`, or `py` is available from your terminal.'
    };
  }

  private parsePythonVersion(output: string): string | undefined {
    const match = output.match(/Python\s+(\d+)\.(\d+)\.(\d+)/i);
    if (!match) {
      return undefined;
    }

    return `${match[1]}.${match[2]}.${match[3]}`;
  }

  private isSupportedPython(version: string): boolean {
    const [majorText, minorText] = version.split('.');
    const major = Number(majorText);
    const minor = Number(minorText);
    return major === 3 && minor === 14;
  }

  private async checkCommand(options: {
    id: string;
    label: string;
    commands: Array<{ command: string; args: string[] }>;
    successSummary: (output: string) => string;
    missingSummary: string;
    guidance: string;
  }): Promise<PrerequisiteItem> {
    for (const candidate of options.commands) {
      try {
        const output = await this.runAndCapture(candidate.command, candidate.args);
        return {
          id: options.id,
          label: options.label,
          status: 'ok',
          summary: options.successSummary(output),
          guidance: options.guidance
        };
      } catch {
        // Continue to the next candidate.
      }
    }

    return {
      id: options.id,
      label: options.label,
      status: 'missing',
      summary: options.missingSummary,
      guidance: options.guidance
    };
  }

  private runAndCapture(command: string, args: string[]): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const processHandle = spawn(command, args, {
        cwd: this.context.extensionPath,
        env: this.createProcessEnv()
      });

      let stdout = '';
      let stderr = '';

      processHandle.stdout.on('data', (chunk) => {
        stdout += chunk.toString();
      });
      processHandle.stderr.on('data', (chunk) => {
        stderr += chunk.toString();
      });
      processHandle.on('error', (error) => {
        reject(error);
      });
      processHandle.on('exit', (code) => {
        if (code === 0) {
          resolve((stdout || stderr).trim());
          return;
        }

        reject(new Error(stderr.trim() || stdout.trim() || `Command failed: ${command} ${args.join(' ')}`));
      });
    });
  }

  private createProcessEnv(): NodeJS.ProcessEnv {
    const env = { ...process.env };
    delete env.PYTHONHOME;
    delete env.PYTHONPATH;
    delete env.PYTHONPLATLIBDIR;
    delete env.__PYVENV_LAUNCHER__;

    return {
      ...env,
      PYTHONUNBUFFERED: '1'
    };
  }
}
