import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { spawn } from 'child_process';

interface PythonCandidate {
  command: string;
  args: string[];
  label: string;
}

interface ResolvedPython extends PythonCandidate {
  version: string;
}

export interface PreparedPythonRuntime {
  pythonPath: string;
  runtimeDir: string;
  serverPath: string;
}

export class PythonRuntimeManager {
  private readonly outputChannel = vscode.window.createOutputChannel('ltm-dct assistant Runtime');
  private setupPromise: Promise<PreparedPythonRuntime> | undefined;

  constructor(private readonly context: vscode.ExtensionContext) {}

  async ensureReady(): Promise<PreparedPythonRuntime> {
    if (!this.setupPromise) {
      this.setupPromise = this.bootstrap();
    }
    return this.setupPromise;
  }

  dispose(): void {
    this.outputChannel.dispose();
  }

  private async bootstrap(): Promise<PreparedPythonRuntime> {
    const basePython = await this.resolveBasePython();
    const runtimeDir = this.context.globalStorageUri.fsPath;
    const venvDir = path.join(runtimeDir, 'python-env');
    const stagedExtensionDir = path.join(runtimeDir, 'bundled-runtime');
    const stagedBackendDir = path.join(stagedExtensionDir, 'backend');
    const stagedRequirementsPath = path.join(stagedExtensionDir, 'requirements.txt');
    const sourceBackendDir = path.join(this.context.extensionPath, 'backend');
    const sourceRequirementsPath = path.join(this.context.extensionPath, 'requirements.txt');
    const stampPath = path.join(venvDir, '.requirements-stamp');
    const venvPython = this.getVenvPythonPath(venvDir);
    const serverPath = path.join(stagedBackendDir, 'mcp_server.py');

    fs.mkdirSync(runtimeDir, { recursive: true });
    this.syncBundledRuntime(sourceBackendDir, stagedBackendDir);
    this.copyFileIfChanged(sourceRequirementsPath, stagedRequirementsPath);

    if (!fs.existsSync(venvPython)) {
      this.outputChannel.appendLine(`Creating virtual environment at ${venvDir} with Python ${basePython.version}`);
      await this.run(basePython.command, [...basePython.args, '-m', 'venv', venvDir], stagedExtensionDir);
    }

    const requirementsStamp = fs.readFileSync(stagedRequirementsPath, 'utf8');
    const currentStamp = fs.existsSync(stampPath) ? fs.readFileSync(stampPath, 'utf8') : '';
    if (currentStamp !== requirementsStamp) {
      this.outputChannel.appendLine('Installing bundled Python dependencies.');
      await this.run(venvPython, ['-m', 'pip', 'install', '--upgrade', 'pip'], stagedExtensionDir);
      await this.run(venvPython, ['-m', 'pip', 'install', '-r', stagedRequirementsPath], stagedExtensionDir);
      fs.writeFileSync(stampPath, requirementsStamp, 'utf8');
    }

    return {
      pythonPath: venvPython,
      runtimeDir,
      serverPath
    };
  }

  private async resolveBasePython(): Promise<ResolvedPython> {
    const configured = vscode.workspace.getConfiguration('python').get<string>('defaultInterpreterPath');
    const candidates = this.getPythonCandidates(configured);
    const detectedVersions: string[] = [];

    for (const candidate of candidates) {
      try {
        const version = await this.getPythonVersion(candidate);
        if (this.isSupportedPython(version)) {
          return {
            ...candidate,
            version
          };
        }

        detectedVersions.push(`${candidate.label}: Python ${version}`);
      } catch {
        // Try the next candidate.
      }
    }

    const detectedText = detectedVersions.length > 0 ? ` Detected unsupported versions: ${detectedVersions.join(', ')}.` : '';
    throw new Error(
      `Python 3.14 is required.${detectedText} The extension can auto-install its local runtime and MCP dependencies, but it cannot install Python itself.`
    );
  }

  private getPythonCandidates(configured?: string): PythonCandidate[] {
    const candidates: PythonCandidate[] = [];
    const seen = new Set<string>();
    const addCandidate = (candidate: PythonCandidate): void => {
      const key = `${candidate.command} ${candidate.args.join(' ')}`.trim();
      if (!seen.has(key)) {
        seen.add(key);
        candidates.push(candidate);
      }
    };

    if (configured) {
      addCandidate({
        command: configured,
        args: [],
        label: configured
      });
    }

    if (process.platform === 'win32') {
      addCandidate({ command: 'py', args: ['-3.14'], label: 'py -3.14' });
      addCandidate({ command: 'py', args: [], label: 'py' });
      addCandidate({ command: 'python', args: [], label: 'python' });
      return candidates;
    }

    addCandidate({ command: 'python3.14', args: [], label: 'python3.14' });
    addCandidate({ command: 'python3', args: [], label: 'python3' });
    addCandidate({ command: 'python', args: [], label: 'python' });
    return candidates;
  }

  private async getPythonVersion(candidate: PythonCandidate): Promise<string> {
    const output = await this.runAndCapture(candidate.command, [...candidate.args, '--version'], this.context.extensionPath);
    const match = output.match(/Python\s+(\d+)\.(\d+)\.(\d+)/i);
    if (!match) {
      throw new Error(`Unable to parse Python version from: ${output}`);
    }

    return `${match[1]}.${match[2]}.${match[3]}`;
  }

  private isSupportedPython(version: string): boolean {
    const [majorText, minorText] = version.split('.');
    const major = Number(majorText);
    const minor = Number(minorText);
    return major === 3 && minor === 14;
  }

  private getVenvPythonPath(venvDir: string): string {
    return process.platform === 'win32'
      ? path.join(venvDir, 'Scripts', 'python.exe')
      : path.join(venvDir, 'bin', 'python');
  }

  private syncBundledRuntime(sourceDir: string, targetDir: string): void {
    fs.mkdirSync(targetDir, { recursive: true });

    const sourceEntries = new Set(fs.readdirSync(sourceDir, { withFileTypes: true }).map((entry) => entry.name));
    for (const targetName of fs.readdirSync(targetDir)) {
      if (!sourceEntries.has(targetName)) {
        fs.rmSync(path.join(targetDir, targetName), { recursive: true, force: true });
      }
    }

    for (const entry of fs.readdirSync(sourceDir, { withFileTypes: true })) {
      const sourcePath = path.join(sourceDir, entry.name);
      const targetPath = path.join(targetDir, entry.name);

      if (entry.isDirectory()) {
        this.syncBundledRuntime(sourcePath, targetPath);
        continue;
      }

      this.copyFileIfChanged(sourcePath, targetPath);
    }
  }

  private copyFileIfChanged(sourcePath: string, targetPath: string): void {
    const sourceContent = fs.readFileSync(sourcePath);
    const targetContent = fs.existsSync(targetPath) ? fs.readFileSync(targetPath) : undefined;

    if (!targetContent || !sourceContent.equals(targetContent)) {
      fs.mkdirSync(path.dirname(targetPath), { recursive: true });
      fs.writeFileSync(targetPath, sourceContent);
    }
  }

  private run(command: string, args: string[], cwd: string): Promise<void> {
    return this.runAndCapture(command, args, cwd).then(() => undefined);
  }

  private runAndCapture(command: string, args: string[], cwd: string): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const processHandle = spawn(command, args, {
        cwd,
        env: this.createPythonProcessEnv()
      });

      let stdout = '';
      let stderr = '';
      processHandle.stdout.on('data', (chunk) => {
        const text = chunk.toString();
        stdout += text;
        this.outputChannel.append(text);
      });
      processHandle.stderr.on('data', (chunk) => {
        const text = chunk.toString();
        stderr += text;
        this.outputChannel.append(text);
      });
      processHandle.on('error', (error) => {
        reject(error);
      });
      processHandle.on('exit', (code) => {
        if (code === 0) {
          resolve((stdout || stderr).trim());
          return;
        }
        reject(new Error(stderr.trim() || `Command failed: ${command} ${args.join(' ')}`));
      });
    });
  }

  private createPythonProcessEnv(): NodeJS.ProcessEnv {
    const env = { ...process.env };
    delete env.PYTHONHOME;
    delete env.PYTHONPATH;
    delete env.PYTHONPLATLIBDIR;
    delete env.__PYVENV_LAUNCHER__;

    return {
      ...env,
      PYTHONUNBUFFERED: '1'
    };
  }
}
