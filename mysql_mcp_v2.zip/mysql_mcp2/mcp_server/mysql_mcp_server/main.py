"""
MySQL MCP Server - Main Entry Point
FastMCP server with intelligent database query tools
"""

import asyncio
import logging
from typing import Dict, Any
from langchain_core.tools import tool
from langchain_mcp_adapters.tools import to_fastmcp
from mcp.server.fastmcp import FastMCP

# Import all tools
from .tools import (
    nl_query_interpreter,
    schema_scanner,
    schema_cache_refresher,
    embedding_manager,
    synonym_mapper,
    table_selector,
    join_path_resolver,
    query_constructor,
    query_optimizer,
    plan_analyzer,
    sql_sanitizer,
    query_executor,
    cache_manager,
    partial_cache_executor,
    result_formatter,
    response_ranker,
    query_history_logger,
    metrics_collector,
    feedback_collector,
    prompt_tuner,
    schema_drift_detector,
    anomaly_detector,
    permission_checker,
    query_timeout_manager,
    retry_manager,
    error_handler,
    model_selector,
    multi_query_orchestrator,
    view_explorer,
    analytics_logger
)

# Import database utilities
from .db_utils import db_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Convert all tools to FastMCP format
fastmcp_tools = [
    to_fastmcp(nl_query_interpreter),
    to_fastmcp(schema_scanner),
    to_fastmcp(schema_cache_refresher),
    to_fastmcp(embedding_manager),
    to_fastmcp(synonym_mapper),
    to_fastmcp(table_selector),
    to_fastmcp(join_path_resolver),
    to_fastmcp(query_constructor),
    to_fastmcp(query_optimizer),
    to_fastmcp(plan_analyzer),
    to_fastmcp(sql_sanitizer),
    to_fastmcp(query_executor),
    to_fastmcp(cache_manager),
    to_fastmcp(partial_cache_executor),
    to_fastmcp(result_formatter),
    to_fastmcp(response_ranker),
    to_fastmcp(query_history_logger),
    to_fastmcp(metrics_collector),
    to_fastmcp(feedback_collector),
    to_fastmcp(prompt_tuner),
    to_fastmcp(schema_drift_detector),
    to_fastmcp(anomaly_detector),
    to_fastmcp(permission_checker),
    to_fastmcp(query_timeout_manager),
    to_fastmcp(retry_manager),
    to_fastmcp(error_handler),
    to_fastmcp(model_selector),
    to_fastmcp(multi_query_orchestrator),
    to_fastmcp(view_explorer),
    to_fastmcp(analytics_logger)
]

# Create FastMCP server
mcp = FastMCP("MySQL MCP Server", tools=fastmcp_tools)

async def initialize_server():
    """Initialize the MCP server and database connections"""
    try:
        logger.info("Initializing MySQL MCP Server...")
        
        # Initialize database manager
        await db_manager.initialize()
        
        # Log server information
        logger.info(f"Server initialized with {len(fastmcp_tools)} tools")
        logger.info(f"Database: {db_manager.config.database}")
        logger.info(f"Host: {db_manager.config.host}:{db_manager.config.port}")
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to initialize server: {e}")
        return False

async def cleanup_server():
    """Cleanup server resources"""
    try:
        logger.info("Cleaning up server resources...")
        await db_manager.close()
        logger.info("Server cleanup completed")
    except Exception as e:
        logger.error(f"Server cleanup failed: {e}")

def run_server():
    """Run the MCP server"""
    try:
        # Initialize server
        asyncio.run(initialize_server())
        
        # Run FastMCP server
        logger.info("Starting FastMCP server...")
        mcp.run(transport="sse")
        
    except KeyboardInterrupt:
        logger.info("Server shutdown requested")
        asyncio.run(cleanup_server())
    except Exception as e:
        logger.error(f"Server error: {e}")
        asyncio.run(cleanup_server())

if __name__ == "__main__":
    run_server()
