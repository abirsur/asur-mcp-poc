"""
Anomaly Detector Tool
Detects anomalies in query performance
"""

import logging
import statistics
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class AnomalyDetection(BaseModel):
    """Anomaly detection model"""
    anomaly_type: str
    severity: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    description: str
    detected_value: float
    normal_range: Dict[str, float]
    confidence: float
    timestamp: datetime
    suggestions: List[str]

@tool
async def anomaly_detector(
    detection_type: str = "performance",
    time_window: str = "24h",
    sensitivity: str = "medium"
) -> Dict[str, Any]:
    """
    Detects anomalies in query performance and system behavior.
    
    Args:
        detection_type: Type of anomaly to detect (performance, execution_time, error_rate, resource_usage)
        time_window: Time window for analysis (1h, 24h, 7d)
        sensitivity: Detection sensitivity (low, medium, high)
        
    Returns:
        Dict containing anomaly detection results
    """
    try:
        logger.info(f"Detecting anomalies: {detection_type} in {time_window}")
        
        # Calculate time window
        time_windows = {
            "1h": timedelta(hours=1),
            "24h": timedelta(days=1),
            "7d": timedelta(days=7)
        }
        
        time_delta = time_windows.get(time_window, timedelta(days=1))
        cutoff_time = datetime.now() - time_delta
        
        # Get query history
        query_history = db_manager.get_query_history(limit=1000)
        recent_queries = [
            q for q in query_history 
            if q.get('timestamp', datetime.min) >= cutoff_time
        ]
        
        if not recent_queries:
            return {
                "anomalies": [],
                "detection_type": detection_type,
                "time_window": time_window,
                "total_queries": 0,
                "message": "No recent queries to analyze"
            }
        
        anomalies = []
        
        if detection_type == "performance":
            # Detect performance anomalies
            execution_times = [q.get('execution_time', 0) for q in recent_queries if q.get('execution_time')]
            
            if execution_times:
                avg_time = statistics.mean(execution_times)
                std_time = statistics.stdev(execution_times) if len(execution_times) > 1 else 0
                
                # Set sensitivity thresholds
                sensitivity_thresholds = {
                    "low": 3.0,
                    "medium": 2.0,
                    "high": 1.5
                }
                threshold = sensitivity_thresholds.get(sensitivity, 2.0)
                
                # Find outliers
                for query in recent_queries:
                    exec_time = query.get('execution_time', 0)
                    if exec_time > avg_time + (threshold * std_time):
                        anomaly = AnomalyDetection(
                            anomaly_type="performance",
                            severity="HIGH" if exec_time > avg_time + (3 * std_time) else "MEDIUM",
                            description=f"Query execution time {exec_time:.2f}s exceeds normal range",
                            detected_value=exec_time,
                            normal_range={"mean": avg_time, "std": std_time},
                            confidence=0.8,
                            timestamp=query.get('timestamp', datetime.now()),
                            suggestions=[
                                "Optimize query performance",
                                "Add appropriate indexes",
                                "Consider query restructuring"
                            ]
                        )
                        anomalies.append(anomaly)
        
        elif detection_type == "execution_time":
            # Detect execution time anomalies
            execution_times = [q.get('execution_time', 0) for q in recent_queries if q.get('execution_time')]
            
            if execution_times:
                # Calculate percentiles
                sorted_times = sorted(execution_times)
                p95 = sorted_times[int(len(sorted_times) * 0.95)]
                p99 = sorted_times[int(len(sorted_times) * 0.99)]
                
                # Find queries exceeding 95th percentile
                for query in recent_queries:
                    exec_time = query.get('execution_time', 0)
                    if exec_time > p95:
                        severity = "CRITICAL" if exec_time > p99 else "HIGH"
                        anomaly = AnomalyDetection(
                            anomaly_type="execution_time",
                            severity=severity,
                            description=f"Query execution time {exec_time:.2f}s exceeds 95th percentile",
                            detected_value=exec_time,
                            normal_range={"p95": p95, "p99": p99},
                            confidence=0.9,
                            timestamp=query.get('timestamp', datetime.now()),
                            suggestions=[
                                "Investigate query optimization",
                                "Check for missing indexes",
                                "Consider query timeout settings"
                            ]
                        )
                        anomalies.append(anomaly)
        
        elif detection_type == "error_rate":
            # Detect error rate anomalies
            total_queries = len(recent_queries)
            failed_queries = len([q for q in recent_queries if not q.get('success', True)])
            error_rate = failed_queries / max(total_queries, 1)
            
            # Normal error rate threshold (5%)
            if error_rate > 0.05:
                anomaly = AnomalyDetection(
                    anomaly_type="error_rate",
                    severity="HIGH" if error_rate > 0.1 else "MEDIUM",
                    description=f"Error rate {error_rate:.2%} exceeds normal threshold",
                    detected_value=error_rate,
                    normal_range={"threshold": 0.05},
                    confidence=0.9,
                    timestamp=datetime.now(),
                    suggestions=[
                        "Investigate recent errors",
                        "Check database connectivity",
                        "Review query syntax"
                    ]
                )
                anomalies.append(anomaly)
        
        elif detection_type == "resource_usage":
            # Detect resource usage anomalies
            # This would typically integrate with system monitoring
            # For now, we'll simulate based on query patterns
            
            # Check for high-frequency queries
            query_counts = {}
            for query in recent_queries:
                query_hash = hash(query.get('query', ''))
                query_counts[query_hash] = query_counts.get(query_hash, 0) + 1
            
            # Find frequently repeated queries
            for query_hash, count in query_counts.items():
                if count > 10:  # Threshold for high frequency
                    anomaly = AnomalyDetection(
                        anomaly_type="resource_usage",
                        severity="MEDIUM",
                        description=f"Query executed {count} times in {time_window}",
                        detected_value=count,
                        normal_range={"threshold": 10},
                        confidence=0.7,
                        timestamp=datetime.now(),
                        suggestions=[
                            "Consider query caching",
                            "Optimize repeated queries",
                            "Review query patterns"
                        ]
                    )
                    anomalies.append(anomaly)
        
        # Sort anomalies by severity
        severity_order = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        anomalies.sort(key=lambda x: severity_order.get(x.severity, 0), reverse=True)
        
        result = {
            "anomalies": [anomaly.dict() for anomaly in anomalies],
            "detection_type": detection_type,
            "time_window": time_window,
            "sensitivity": sensitivity,
            "total_queries": len(recent_queries),
            "anomalies_detected": len(anomalies),
            "summary": {
                "critical_anomalies": len([a for a in anomalies if a.severity == "CRITICAL"]),
                "high_anomalies": len([a for a in anomalies if a.severity == "HIGH"]),
                "medium_anomalies": len([a for a in anomalies if a.severity == "MEDIUM"]),
                "low_anomalies": len([a for a in anomalies if a.severity == "LOW"])
            },
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Anomaly detection completed: {len(anomalies)} anomalies found")
        return result
        
    except Exception as e:
        logger.error(f"Anomaly detection failed: {e}")
        return {
            "error": str(e),
            "anomalies": [],
            "detection_type": detection_type,
            "anomalies_detected": 0
        }
