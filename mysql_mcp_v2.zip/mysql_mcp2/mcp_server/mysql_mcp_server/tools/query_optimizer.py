"""
Query Optimizer Tool
Optimizes SQL with index hints, LIMIT, etc.
"""

import logging
import re
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class OptimizationSuggestion(BaseModel):
    """Query optimization suggestion model"""
    type: str  # "index", "limit", "join", "where", "select"
    description: str
    original: str
    optimized: str
    impact: str  # "HIGH", "MEDIUM", "LOW"
    confidence: float

@tool
async def query_optimizer(
    query: str,
    include_index_hints: bool = True,
    add_limits: bool = True,
    max_limit: int = 1000
) -> Dict[str, Any]:
    """
    Optimizes SQL queries with index hints, LIMIT clauses, and other improvements.
    
    Args:
        query: SQL query to optimize
        include_index_hints: Whether to add index hints
        add_limits: Whether to add LIMIT clauses to SELECT queries
        max_limit: Maximum limit to add
        
    Returns:
        Dict containing optimization suggestions and optimized query
    """
    try:
        logger.info("Optimizing SQL query")
        
        original_query = query
        optimized_query = query
        suggestions = []
        
        # Get schema information for index analysis
        schema_info = db_manager.get_schema_info()
        if not schema_info:
            await db_manager.refresh_schema_cache()
            schema_info = db_manager.get_schema_info()
        
        query_upper = query.upper().strip()
        
        # 1. Add LIMIT clause to SELECT queries
        if add_limits and query_upper.startswith('SELECT') and 'LIMIT' not in query_upper:
            # Find the end of the query
            if 'ORDER BY' in query_upper:
                # Insert LIMIT before ORDER BY
                order_by_pos = query_upper.find('ORDER BY')
                optimized_query = query[:order_by_pos].rstrip() + f" LIMIT {max_limit} " + query[order_by_pos:]
            else:
                # Add LIMIT at the end
                optimized_query = query.rstrip() + f" LIMIT {max_limit}"
            
            suggestions.append(OptimizationSuggestion(
                type="limit",
                description=f"Added LIMIT {max_limit} to prevent large result sets",
                original=query,
                optimized=optimized_query,
                impact="HIGH",
                confidence=0.9
            ))
        
        # 2. Add index hints for JOIN operations
        if include_index_hints and schema_info:
            # Find JOIN operations
            join_pattern = r'JOIN\s+(\w+)\s+ON\s+([^=]+)\s*=\s*([^=]+)'
            joins = re.findall(join_pattern, query_upper)
            
            for table, col1, col2 in joins:
                if table in schema_info.indexes:
                    # Check if there are indexes on the join columns
                    table_indexes = schema_info.indexes[table]
                    for index in table_indexes:
                        if index['column'] in [col1.strip(), col2.strip()]:
                            # Add index hint
                            index_hint = f"USE INDEX ({index['name']})"
                            optimized_query = re.sub(
                                f'JOIN\\s+{table}\\s+ON',
                                f'JOIN {table} {index_hint} ON',
                                optimized_query,
                                flags=re.IGNORECASE
                            )
                            
                            suggestions.append(OptimizationSuggestion(
                                type="index",
                                description=f"Added index hint for {table} using {index['name']}",
                                original=query,
                                optimized=optimized_query,
                                impact="MEDIUM",
                                confidence=0.7
                            ))
                            break
        
        # 3. Optimize WHERE clauses
        where_pattern = r'WHERE\s+(.+)'
        where_match = re.search(where_pattern, query_upper)
        if where_match:
            where_clause = where_match.group(1)
            
            # Check for inefficient WHERE conditions
            if 'LIKE' in where_clause and not where_clause.startswith('LIKE'):
                # Suggest using indexes for LIKE patterns
                suggestions.append(OptimizationSuggestion(
                    type="where",
                    description="Consider adding indexes for LIKE operations",
                    original=query,
                    optimized=query,
                    impact="MEDIUM",
                    confidence=0.6
                ))
            
            # Check for OR conditions that could be optimized
            if ' OR ' in where_clause:
                suggestions.append(OptimizationSuggestion(
                    type="where",
                    description="Consider using UNION instead of OR for better performance",
                    original=query,
                    optimized=query,
                    impact="MEDIUM",
                    confidence=0.5
                ))
        
        # 4. Optimize SELECT clauses
        if query_upper.startswith('SELECT *'):
            # Suggest specific columns instead of *
            suggestions.append(OptimizationSuggestion(
                type="select",
                description="Consider selecting specific columns instead of * for better performance",
                original=query,
                optimized=query,
                impact="LOW",
                confidence=0.8
            ))
        
        # 5. Add ORDER BY optimization
        if 'ORDER BY' in query_upper and 'LIMIT' not in query_upper:
            suggestions.append(OptimizationSuggestion(
                type="order",
                description="Consider adding LIMIT with ORDER BY for better performance",
                original=query,
                optimized=query,
                impact="MEDIUM",
                confidence=0.7
            ))
        
        # 6. Check for subqueries that could be optimized
        subquery_pattern = r'\(SELECT\s+.*?\s+FROM\s+.*?\)'
        subqueries = re.findall(subquery_pattern, query_upper)
        if subqueries:
            suggestions.append(OptimizationSuggestion(
                type="subquery",
                description="Consider using JOINs instead of subqueries for better performance",
                original=query,
                optimized=query,
                impact="HIGH",
                confidence=0.6
            ))
        
        # 7. Add query execution plan analysis
        if query_upper.startswith('SELECT'):
            try:
                explain_query = f"EXPLAIN {query}"
                explain_result = await db_manager.execute_query(explain_query)
                
                if explain_result.rows:
                    # Analyze execution plan
                    plan_analysis = []
                    for row in explain_result.rows:
                        if row.get('type') == 'ALL':
                            plan_analysis.append("Full table scan detected - consider adding indexes")
                        elif row.get('Extra') and 'Using filesort' in row['Extra']:
                            plan_analysis.append("Filesort detected - consider optimizing ORDER BY")
                        elif row.get('Extra') and 'Using temporary' in row['Extra']:
                            plan_analysis.append("Temporary table detected - consider optimizing GROUP BY")
                    
                    if plan_analysis:
                        suggestions.append(OptimizationSuggestion(
                            type="execution_plan",
                            description="; ".join(plan_analysis),
                            original=query,
                            optimized=query,
                            impact="HIGH",
                            confidence=0.9
                        ))
            except Exception as e:
                logger.warning(f"Could not analyze execution plan: {e}")
        
        # Calculate overall optimization score
        optimization_score = 0.0
        for suggestion in suggestions:
            if suggestion.impact == "HIGH":
                optimization_score += 0.3
            elif suggestion.impact == "MEDIUM":
                optimization_score += 0.2
            else:
                optimization_score += 0.1
        
        optimization_score = min(optimization_score, 1.0)
        
        result = {
            "original_query": original_query,
            "optimized_query": optimized_query,
            "suggestions": [suggestion.dict() for suggestion in suggestions],
            "optimization_score": optimization_score,
            "summary": {
                "total_suggestions": len(suggestions),
                "high_impact": len([s for s in suggestions if s.impact == "HIGH"]),
                "medium_impact": len([s for s in suggestions if s.impact == "MEDIUM"]),
                "low_impact": len([s for s in suggestions if s.impact == "LOW"]),
                "optimization_applied": len(suggestions) > 0
            }
        }
        
        logger.info(f"Query optimization completed: {len(suggestions)} suggestions, score: {optimization_score:.2f}")
        return result
        
    except Exception as e:
        logger.error(f"Query optimization failed: {e}")
        return {
            "error": str(e),
            "original_query": query,
            "optimized_query": query,
            "suggestions": [],
            "optimization_score": 0.0
        }
