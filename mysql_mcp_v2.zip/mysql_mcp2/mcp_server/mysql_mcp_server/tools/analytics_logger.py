"""
Analytics Logger Tool
Aggregates and logs analytics data
"""

import logging
import json
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class AnalyticsEvent(BaseModel):
    """Analytics event model"""
    event_id: str
    event_type: str
    user_id: Optional[str]
    session_id: Optional[str]
    timestamp: datetime
    data: Dict[str, Any]
    metadata: Dict[str, Any] = Field(default_factory=dict)

@tool
async def analytics_logger(
    action: str = "log",
    event_type: str = "query_execution",
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    data: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Aggregates and logs analytics data for system monitoring and optimization.
    
    Args:
        action: Action to perform (log, get, analyze, export)
        event_type: Type of analytics event
        user_id: User ID associated with the event
        session_id: Session ID
        data: Event data
        metadata: Additional metadata
        
    Returns:
        Dict containing analytics logging results
    """
    try:
        logger.info(f"Analytics logger action: {action}")
        
        if action == "log":
            # Log analytics event
            event_id = f"analytics_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hash(str(datetime.now()))}"
            
            event = AnalyticsEvent(
                event_id=event_id,
                event_type=event_type,
                user_id=user_id,
                session_id=session_id,
                timestamp=datetime.now(),
                data=data or {},
                metadata=metadata or {}
            )
            
            # Store analytics event
            if not hasattr(db_manager, 'analytics_storage'):
                db_manager.analytics_storage = []
            
            db_manager.analytics_storage.append(event.dict())
            
            # Keep only last 10000 events
            if len(db_manager.analytics_storage) > 10000:
                db_manager.analytics_storage = db_manager.analytics_storage[-10000:]
            
            logger.info(f"Analytics event logged: {event_type} ({event_id})")
            
            return {
                "action": "log",
                "event_id": event_id,
                "event_type": event_type,
                "logged": True,
                "timestamp": event.timestamp.isoformat()
            }
        
        elif action == "get":
            # Get analytics events
            if not hasattr(db_manager, 'analytics_storage'):
                db_manager.analytics_storage = []
            
            # Filter by parameters
            events = db_manager.analytics_storage
            
            if event_type:
                events = [e for e in events if e.get('event_type') == event_type]
            
            if user_id:
                events = [e for e in events if e.get('user_id') == user_id]
            
            if session_id:
                events = [e for e in events if e.get('session_id') == session_id]
            
            # Apply time filter if provided
            if metadata and 'time_range' in metadata:
                time_range = metadata['time_range']
                if time_range == '1h':
                    cutoff = datetime.now() - timedelta(hours=1)
                elif time_range == '24h':
                    cutoff = datetime.now() - timedelta(days=1)
                elif time_range == '7d':
                    cutoff = datetime.now() - timedelta(days=7)
                else:
                    cutoff = datetime.now() - timedelta(days=1)
                
                events = [e for e in events if e.get('timestamp', datetime.min) >= cutoff]
            
            # Apply limit
            limit = metadata.get('limit', 100) if metadata else 100
            events = events[-limit:]
            
            return {
                "action": "get",
                "events": events,
                "total_events": len(events),
                "filters": {
                    "event_type": event_type,
                    "user_id": user_id,
                    "session_id": session_id,
                    "time_range": metadata.get('time_range') if metadata else None
                },
                "timestamp": datetime.now().isoformat()
            }
        
        elif action == "analyze":
            # Analyze analytics data
            if not hasattr(db_manager, 'analytics_storage'):
                db_manager.analytics_storage = []
            
            events = db_manager.analytics_storage
            
            # Time range analysis
            time_range = metadata.get('time_range', '24h') if metadata else '24h'
            if time_range == '1h':
                cutoff = datetime.now() - timedelta(hours=1)
            elif time_range == '24h':
                cutoff = datetime.now() - timedelta(days=1)
            elif time_range == '7d':
                cutoff = datetime.now() - timedelta(days=7)
            else:
                cutoff = datetime.now() - timedelta(days=1)
            
            recent_events = [e for e in events if e.get('timestamp', datetime.min) >= cutoff]
            
            # Event type analysis
            event_types = {}
            for event in recent_events:
                etype = event.get('event_type', 'unknown')
                event_types[etype] = event_types.get(etype, 0) + 1
            
            # User activity analysis
            user_activity = {}
            for event in recent_events:
                uid = event.get('user_id', 'anonymous')
                user_activity[uid] = user_activity.get(uid, 0) + 1
            
            # Session analysis
            session_activity = {}
            for event in recent_events:
                sid = event.get('session_id', 'unknown')
                session_activity[sid] = session_activity.get(sid, 0) + 1
            
            # Performance analysis
            performance_events = [e for e in recent_events if e.get('event_type') == 'query_execution']
            execution_times = [e.get('data', {}).get('execution_time', 0) for e in performance_events]
            
            analysis = {
                "time_range": time_range,
                "total_events": len(recent_events),
                "event_types": event_types,
                "user_activity": {
                    "active_users": len(user_activity),
                    "top_users": sorted(user_activity.items(), key=lambda x: x[1], reverse=True)[:5]
                },
                "session_activity": {
                    "active_sessions": len(session_activity),
                    "top_sessions": sorted(session_activity.items(), key=lambda x: x[1], reverse=True)[:5]
                },
                "performance_analysis": {
                    "total_queries": len(performance_events),
                    "avg_execution_time": sum(execution_times) / max(len(execution_times), 1),
                    "min_execution_time": min(execution_times) if execution_times else 0,
                    "max_execution_time": max(execution_times) if execution_times else 0
                },
                "insights": []
            }
            
            # Generate insights
            if len(recent_events) > 100:
                analysis["insights"].append("High activity detected")
            
            if len(user_activity) > 10:
                analysis["insights"].append("Multiple users active")
            
            if execution_times and sum(execution_times) / len(execution_times) > 5.0:
                analysis["insights"].append("Slow query performance detected")
            
            return {
                "action": "analyze",
                "analysis": analysis,
                "timestamp": datetime.now().isoformat()
            }
        
        elif action == "export":
            # Export analytics data
            if not hasattr(db_manager, 'analytics_storage'):
                db_manager.analytics_storage = []
            
            events = db_manager.analytics_storage
            
            # Apply filters
            if event_type:
                events = [e for e in events if e.get('event_type') == event_type]
            
            if user_id:
                events = [e for e in events if e.get('user_id') == user_id]
            
            if session_id:
                events = [e for e in events if e.get('session_id') == session_id]
            
            # Time range filter
            time_range = metadata.get('time_range', '24h') if metadata else '24h'
            if time_range == '1h':
                cutoff = datetime.now() - timedelta(hours=1)
            elif time_range == '24h':
                cutoff = datetime.now() - timedelta(days=1)
            elif time_range == '7d':
                cutoff = datetime.now() - timedelta(days=7)
            else:
                cutoff = datetime.now() - timedelta(days=1)
            
            events = [e for e in events if e.get('timestamp', datetime.min) >= cutoff]
            
            # Export format
            export_format = metadata.get('format', 'json') if metadata else 'json'
            
            if export_format == 'json':
                export_data = json.dumps(events, default=str, indent=2)
            elif export_format == 'csv':
                # Convert to CSV format
                if events:
                    headers = list(events[0].keys())
                    csv_data = ','.join(headers) + '\n'
                    for event in events:
                        row = [str(event.get(h, '')) for h in headers]
                        csv_data += ','.join(row) + '\n'
                    export_data = csv_data
                else:
                    export_data = ""
            else:
                export_data = str(events)
            
            return {
                "action": "export",
                "format": export_format,
                "data": export_data,
                "total_events": len(events),
                "timestamp": datetime.now().isoformat()
            }
        
        else:
            return {
                "error": f"Invalid action: {action}",
                "available_actions": ["log", "get", "analyze", "export"]
            }
        
    except Exception as e:
        logger.error(f"Analytics logging failed: {e}")
        return {
            "error": str(e),
            "action": action,
            "logged": False
        }
