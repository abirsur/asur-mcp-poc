"""
Schema Cache Refresher Tool
Refreshes schema cache periodically
"""

import logging
from typing import Dict, Any
from langchain_core.tools import tool
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

@tool
async def schema_cache_refresher(force_refresh: bool = False) -> Dict[str, Any]:
    """
    Refreshes the database schema cache.
    
    Args:
        force_refresh: Whether to force refresh even if cache is recent
        
    Returns:
        Dict containing refresh status and schema information
    """
    try:
        logger.info("Refreshing schema cache")
        
        # Check if cache is recent (less than 1 hour old)
        schema_info = db_manager.get_schema_info()
        if schema_info and not force_refresh:
            from datetime import datetime, timedelta
            if schema_info.last_updated > datetime.now() - timedelta(hours=1):
                logger.info("Schema cache is recent, skipping refresh")
                return {
                    "status": "skipped",
                    "reason": "Cache is recent",
                    "last_updated": str(schema_info.last_updated),
                    "tables_count": len(schema_info.tables)
                }
        
        # Refresh schema cache
        await db_manager.refresh_schema_cache()
        
        # Get updated schema info
        updated_schema = db_manager.get_schema_info()
        
        if updated_schema:
            logger.info(f"Schema cache refreshed successfully: {len(updated_schema.tables)} tables")
            return {
                "status": "success",
                "last_updated": str(updated_schema.last_updated),
                "tables_count": len(updated_schema.tables),
                "relationships_count": len(updated_schema.relationships),
                "indexes_count": len(updated_schema.indexes),
                "database": db_manager.config.database
            }
        else:
            return {
                "status": "failed",
                "error": "Failed to retrieve schema after refresh"
            }
            
    except Exception as e:
        logger.error(f"Schema cache refresh failed: {e}")
        return {
            "status": "error",
            "error": str(e),
            "last_updated": None
        }
