"""
Query Constructor Tool
Builds SQL from interpreted intent
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class SQLQuery(BaseModel):
    """SQL query model"""
    query: str
    query_type: str
    tables: List[str]
    confidence: float
    explanation: str

@tool
async def query_constructor(
    intent: Dict[str, Any],
    selected_tables: List[str],
    join_paths: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Builds SQL query from interpreted intent and table selections.
    
    Args:
        intent: Structured query intent
        selected_tables: Tables selected for the query
        join_paths: Join paths between tables
        
    Returns:
        Dict containing constructed SQL query
    """
    try:
        logger.info("Constructing SQL query from intent")
        
        action = intent.get('action', 'SELECT')
        columns = intent.get('columns', [])
        conditions = intent.get('conditions', [])
        aggregations = intent.get('aggregations', [])
        ordering = intent.get('ordering')
        grouping = intent.get('grouping', [])
        limit = intent.get('limit')
        
        if action.upper() == 'SELECT':
            # Build SELECT query
            query_parts = []
            
            # SELECT clause
            if aggregations:
                # Handle aggregations
                select_clause = []
                for agg in aggregations:
                    if agg.upper() == 'COUNT':
                        select_clause.append(f"COUNT(*) as total_count")
                    elif agg.upper() == 'SUM':
                        if columns:
                            select_clause.append(f"SUM({columns[0]}) as sum_{columns[0]}")
                        else:
                            select_clause.append("SUM(*) as total_sum")
                    elif agg.upper() == 'AVG':
                        if columns:
                            select_clause.append(f"AVG({columns[0]}) as avg_{columns[0]}")
                        else:
                            select_clause.append("AVG(*) as total_avg")
                    elif agg.upper() == 'MAX':
                        if columns:
                            select_clause.append(f"MAX({columns[0]}) as max_{columns[0]}")
                        else:
                            select_clause.append("MAX(*) as total_max")
                    elif agg.upper() == 'MIN':
                        if columns:
                            select_clause.append(f"MIN({columns[0]}) as min_{columns[0]}")
                        else:
                            select_clause.append("MIN(*) as total_min")
                
                if not select_clause:
                    select_clause = ["*"]
                
                query_parts.append(f"SELECT {', '.join(select_clause)}")
            else:
                # Regular SELECT
                if columns:
                    # Validate columns against schema
                    schema_info = db_manager.get_schema_info()
                    valid_columns = []
                    for col in columns:
                        for table in selected_tables:
                            if table in schema_info.tables:
                                table_columns = [c['COLUMN_NAME'] for c in schema_info.tables[table]['columns']]
                                if col in table_columns:
                                    valid_columns.append(f"{table}.{col}")
                                    break
                        else:
                            # Column not found in any table, try without table prefix
                            valid_columns.append(col)
                    
                    if valid_columns:
                        query_parts.append(f"SELECT {', '.join(valid_columns)}")
                    else:
                        query_parts.append("SELECT *")
                else:
                    query_parts.append("SELECT *")
            
            # FROM clause
            if selected_tables:
                if len(selected_tables) == 1:
                    query_parts.append(f"FROM {selected_tables[0]}")
                else:
                    # Multiple tables - need joins
                    from_clause = f"FROM {selected_tables[0]}"
                    
                    # Add joins based on join paths
                    for join_path in join_paths:
                        table1 = join_path.get('table1')
                        table2 = join_path.get('table2')
                        join_type = join_path.get('join_type', 'INNER')
                        join_condition = join_path.get('join_condition')
                        
                        if table1 in selected_tables and table2 in selected_tables:
                            from_clause += f" {join_type} JOIN {table2} ON {join_condition}"
                    
                    query_parts.append(from_clause)
            else:
                return {"error": "No tables selected for query"}
            
            # WHERE clause
            if conditions:
                where_conditions = []
                for condition in conditions:
                    column = condition.get('column', '')
                    operator = condition.get('operator', '=')
                    value = condition.get('value', '')
                    
                    # Validate column exists in selected tables
                    column_found = False
                    for table in selected_tables:
                        if table in db_manager.get_schema_info().tables:
                            table_columns = [c['COLUMN_NAME'] for c in db_manager.get_schema_info().tables[table]['columns']]
                            if column in table_columns:
                                where_conditions.append(f"{table}.{column} {operator} '{value}'")
                                column_found = True
                                break
                    
                    if not column_found:
                        where_conditions.append(f"{column} {operator} '{value}'")
                
                if where_conditions:
                    query_parts.append(f"WHERE {' AND '.join(where_conditions)}")
            
            # GROUP BY clause
            if grouping:
                query_parts.append(f"GROUP BY {', '.join(grouping)}")
            
            # ORDER BY clause
            if ordering:
                column = ordering.get('column', '')
                direction = ordering.get('direction', 'ASC')
                query_parts.append(f"ORDER BY {column} {direction}")
            
            # LIMIT clause
            if limit:
                query_parts.append(f"LIMIT {limit}")
            
            # Construct final query
            sql_query = " ".join(query_parts)
            
            # Calculate confidence based on completeness
            confidence = 0.5  # Base confidence
            if columns:
                confidence += 0.2
            if conditions:
                confidence += 0.2
            if selected_tables:
                confidence += 0.1
            
            confidence = min(confidence, 1.0)
            
            result = {
                "sql_query": sql_query,
                "query_type": "SELECT",
                "tables": selected_tables,
                "confidence": confidence,
                "explanation": f"SELECT query with {len(selected_tables)} tables, {len(columns)} columns, {len(conditions)} conditions",
                "query_parts": {
                    "select": query_parts[0] if query_parts else "",
                    "from": query_parts[1] if len(query_parts) > 1 else "",
                    "where": query_parts[2] if len(query_parts) > 2 else "",
                    "group_by": query_parts[3] if len(query_parts) > 3 else "",
                    "order_by": query_parts[4] if len(query_parts) > 4 else "",
                    "limit": query_parts[5] if len(query_parts) > 5 else ""
                }
            }
            
        else:
            # Other query types (INSERT, UPDATE, DELETE)
            result = {
                "sql_query": f"-- {action} query not implemented yet",
                "query_type": action,
                "tables": selected_tables,
                "confidence": 0.3,
                "explanation": f"{action} queries are not yet supported",
                "error": f"{action} queries not implemented"
            }
        
        logger.info(f"SQL query constructed with confidence: {result.get('confidence', 0)}")
        return result
        
    except Exception as e:
        logger.error(f"Query construction failed: {e}")
        return {
            "error": str(e),
            "sql_query": None,
            "query_type": "ERROR",
            "confidence": 0.0
        }
