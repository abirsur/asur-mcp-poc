"""
Schema Scanner Tool
Scans database tables, columns, types, and relationships
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class TableInfo(BaseModel):
    """Table information model"""
    name: str
    type: str
    comment: Optional[str]
    row_count: Optional[int]
    columns: List[Dict[str, Any]]
    indexes: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]

class SchemaScanResult(BaseModel):
    """Schema scan result model"""
    tables: List[TableInfo]
    total_tables: int
    total_columns: int
    scan_timestamp: str
    database_name: str

@tool
async def schema_scanner(include_row_counts: bool = True, include_indexes: bool = True) -> Dict[str, Any]:
    """
    Scans database tables, columns, types, and relationships.
    
    Args:
        include_row_counts: Whether to include row counts for each table
        include_indexes: Whether to include index information
        
    Returns:
        Dict containing comprehensive schema information
    """
    try:
        logger.info("Starting schema scan")
        
        # Get or refresh schema cache
        schema_info = db_manager.get_schema_info()
        if not schema_info:
            await db_manager.refresh_schema_cache()
            schema_info = db_manager.get_schema_info()
        
        if not schema_info:
            return {"error": "Failed to retrieve schema information"}
        
        tables = []
        total_columns = 0
        
        for table_name, table_data in schema_info.tables.items():
            # Get row count if requested
            row_count = None
            if include_row_counts:
                try:
                    count_result = await db_manager.execute_query(f"SELECT COUNT(*) as count FROM `{table_name}`")
                    row_count = count_result.rows[0]['count'] if count_result.rows else 0
                except Exception as e:
                    logger.warning(f"Could not get row count for table {table_name}: {e}")
            
            # Get index information if requested
            indexes = []
            if include_indexes and table_name in schema_info.indexes:
                indexes = schema_info.indexes[table_name]
            
            # Get relationship information
            relationships = []
            if table_name in schema_info.relationships:
                relationships = schema_info.relationships[table_name]
            
            table_info = TableInfo(
                name=table_name,
                type=table_data['type'],
                comment=table_data['comment'],
                row_count=row_count,
                columns=table_data['columns'],
                indexes=indexes,
                relationships=relationships
            )
            
            tables.append(table_info)
            total_columns += len(table_data['columns'])
        
        # Sort tables by name
        tables.sort(key=lambda x: x.name)
        
        result = SchemaScanResult(
            tables=tables,
            total_tables=len(tables),
            total_columns=total_columns,
            scan_timestamp=str(schema_info.last_updated),
            database_name=db_manager.config.database
        )
        
        logger.info(f"Schema scan completed: {len(tables)} tables, {total_columns} columns")
        
        return {
            "schema_scan": result.dict(),
            "summary": {
                "database": db_manager.config.database,
                "tables_count": len(tables),
                "columns_count": total_columns,
                "scan_timestamp": str(schema_info.last_updated)
            },
            "tables": [table.dict() for table in tables]
        }
        
    except Exception as e:
        logger.error(f"Schema scan failed: {e}")
        return {
            "error": str(e),
            "schema_scan": None,
            "summary": {
                "database": db_manager.config.database,
                "tables_count": 0,
                "columns_count": 0,
                "scan_timestamp": None
            }
        }
