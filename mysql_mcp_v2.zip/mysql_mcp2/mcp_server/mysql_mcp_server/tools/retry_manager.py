"""
Retry Manager Tool
Handles transient database errors with retries
"""

import logging
import asyncio
import random
from typing import Dict, List, Any, Optional, Callable
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime

logger = logging.getLogger(__name__)

class RetryConfig(BaseModel):
    """Retry configuration model"""
    max_retries: int = Field(default=3, description="Maximum number of retries")
    base_delay: float = Field(default=1.0, description="Base delay in seconds")
    max_delay: float = Field(default=60.0, description="Maximum delay in seconds")
    backoff_factor: float = Field(default=2.0, description="Exponential backoff factor")
    jitter: bool = Field(default=True, description="Add random jitter to delays")

@tool
async def retry_manager(
    operation: str,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    backoff_factor: float = 2.0,
    jitter: bool = True
) -> Dict[str, Any]:
    """
    Handles transient database errors with retries and exponential backoff.
    
    Args:
        operation: Description of the operation being retried
        max_retries: Maximum number of retries
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        backoff_factor: Exponential backoff factor
        jitter: Whether to add random jitter to delays
        
    Returns:
        Dict containing retry configuration and status
    """
    try:
        logger.info(f"Retry manager initialized for: {operation}")
        
        retry_config = RetryConfig(
            max_retries=max_retries,
            base_delay=base_delay,
            max_delay=max_delay,
            backoff_factor=backoff_factor,
            jitter=jitter
        )
        
        # Calculate retry delays
        delays = []
        for attempt in range(max_retries):
            delay = min(base_delay * (backoff_factor ** attempt), max_delay)
            if jitter:
                # Add random jitter (±25% of delay)
                jitter_amount = delay * 0.25 * (2 * random.random() - 1)
                delay += jitter_amount
            delays.append(max(0, delay))
        
        result = {
            "operation": operation,
            "retry_config": retry_config.dict(),
            "retry_delays": delays,
            "total_max_delay": sum(delays),
            "retry_strategy": {
                "exponential_backoff": True,
                "jitter_enabled": jitter,
                "max_attempts": max_retries + 1,
                "base_delay_seconds": base_delay,
                "max_delay_seconds": max_delay
            },
            "status": "configured",
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Retry manager configured: {max_retries} retries, {sum(delays):.2f}s total delay")
        return result
        
    except Exception as e:
        logger.error(f"Retry manager configuration failed: {e}")
        return {
            "error": str(e),
            "operation": operation,
            "retry_config": None,
            "status": "failed"
        }

async def execute_with_retry(
    operation_func: Callable,
    operation_name: str,
    retry_config: Optional[RetryConfig] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    Execute an operation with retry logic.
    
    Args:
        operation_func: Function to execute
        operation_name: Name of the operation
        retry_config: Retry configuration
        **kwargs: Additional arguments for the operation
        
    Returns:
        Dict containing execution results
    """
    if retry_config is None:
        retry_config = RetryConfig()
    
    last_error = None
    attempt = 0
    
    while attempt <= retry_config.max_retries:
        try:
            logger.info(f"Executing {operation_name} (attempt {attempt + 1})")
            result = await operation_func(**kwargs)
            
            if attempt > 0:
                logger.info(f"Operation {operation_name} succeeded after {attempt} retries")
            
            return {
                "success": True,
                "result": result,
                "attempts": attempt + 1,
                "operation": operation_name,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            last_error = e
            attempt += 1
            
            if attempt <= retry_config.max_retries:
                # Calculate delay for next attempt
                delay = min(
                    retry_config.base_delay * (retry_config.backoff_factor ** (attempt - 1)),
                    retry_config.max_delay
                )
                
                if retry_config.jitter:
                    jitter_amount = delay * 0.25 * (2 * random.random() - 1)
                    delay += jitter_amount
                
                logger.warning(f"Operation {operation_name} failed (attempt {attempt}): {e}")
                logger.info(f"Retrying in {delay:.2f} seconds...")
                
                await asyncio.sleep(delay)
            else:
                logger.error(f"Operation {operation_name} failed after {retry_config.max_retries} retries: {e}")
                break
    
    return {
        "success": False,
        "error": str(last_error),
        "attempts": attempt,
        "operation": operation_name,
        "timestamp": datetime.now().isoformat()
    }
