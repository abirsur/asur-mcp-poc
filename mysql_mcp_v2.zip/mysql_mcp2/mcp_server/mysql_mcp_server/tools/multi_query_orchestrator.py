"""
Multi Query Orchestrator Tool
Handles multi-part questions
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class QueryPart(BaseModel):
    """Query part model"""
    part_id: str
    query: str
    dependencies: List[str]
    execution_order: int
    result: Optional[Any] = None
    status: str = "pending"  # "pending", "running", "completed", "failed"
    error: Optional[str] = None

class OrchestrationResult(BaseModel):
    """Orchestration result model"""
    orchestration_id: str
    total_parts: int
    completed_parts: int
    failed_parts: int
    execution_time: float
    results: List[Dict[str, Any]]
    dependencies_resolved: bool
    timestamp: datetime

@tool
async def multi_query_orchestrator(
    query_parts: List[Dict[str, Any]],
    execution_strategy: str = "sequential",
    max_parallel: int = 3
) -> Dict[str, Any]:
    """
    Handles multi-part questions by orchestrating query execution.
    
    Args:
        query_parts: List of query parts with dependencies
        execution_strategy: Execution strategy (sequential, parallel, hybrid)
        max_parallel: Maximum parallel executions for hybrid strategy
        
    Returns:
        Dict containing orchestration results
    """
    try:
        logger.info(f"Orchestrating {len(query_parts)} query parts")
        
        start_time = datetime.now()
        orchestration_id = f"orch_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Convert to QueryPart objects
        parts = []
        for i, part_data in enumerate(query_parts):
            part = QueryPart(
                part_id=part_data.get('part_id', f"part_{i}"),
                query=part_data.get('query', ''),
                dependencies=part_data.get('dependencies', []),
                execution_order=part_data.get('execution_order', i),
                result=None,
                status="pending"
            )
            parts.append(part)
        
        # Sort by execution order
        parts.sort(key=lambda x: x.execution_order)
        
        results = []
        completed_parts = 0
        failed_parts = 0
        
        if execution_strategy == "sequential":
            # Execute parts sequentially
            for part in parts:
                try:
                    part.status = "running"
                    result = await db_manager.execute_query(part.query)
                    part.result = result.dict() if hasattr(result, 'dict') else result
                    part.status = "completed"
                    completed_parts += 1
                    
                    results.append({
                        "part_id": part.part_id,
                        "query": part.query,
                        "result": part.result,
                        "status": part.status,
                        "execution_order": part.execution_order
                    })
                    
                except Exception as e:
                    part.status = "failed"
                    part.error = str(e)
                    failed_parts += 1
                    
                    results.append({
                        "part_id": part.part_id,
                        "query": part.query,
                        "result": None,
                        "status": part.status,
                        "error": part.error,
                        "execution_order": part.execution_order
                    })
        
        elif execution_strategy == "parallel":
            # Execute all parts in parallel
            async def execute_part(part):
                try:
                    part.status = "running"
                    result = await db_manager.execute_query(part.query)
                    part.result = result.dict() if hasattr(result, 'dict') else result
                    part.status = "completed"
                    return part
                except Exception as e:
                    part.status = "failed"
                    part.error = str(e)
                    return part
            
            # Execute all parts concurrently
            tasks = [execute_part(part) for part in parts]
            completed_parts_list = await asyncio.gather(*tasks, return_exceptions=True)
            
            for part in completed_parts_list:
                if isinstance(part, Exception):
                    failed_parts += 1
                else:
                    if part.status == "completed":
                        completed_parts += 1
                    else:
                        failed_parts += 1
                    
                    results.append({
                        "part_id": part.part_id,
                        "query": part.query,
                        "result": part.result,
                        "status": part.status,
                        "error": part.error,
                        "execution_order": part.execution_order
                    })
        
        elif execution_strategy == "hybrid":
            # Execute parts in batches based on dependencies
            executed_parts = set()
            remaining_parts = parts.copy()
            
            while remaining_parts:
                # Find parts that can be executed (no pending dependencies)
                ready_parts = []
                for part in remaining_parts:
                    if all(dep in executed_parts for dep in part.dependencies):
                        ready_parts.append(part)
                
                if not ready_parts:
                    # Circular dependency or error
                    break
                
                # Execute ready parts in parallel (up to max_parallel)
                batch_size = min(len(ready_parts), max_parallel)
                batch_parts = ready_parts[:batch_size]
                
                async def execute_batch_part(part):
                    try:
                        part.status = "running"
                        result = await db_manager.execute_query(part.query)
                        part.result = result.dict() if hasattr(result, 'dict') else result
                        part.status = "completed"
                        return part
                    except Exception as e:
                        part.status = "failed"
                        part.error = str(e)
                        return part
                
                # Execute batch
                batch_results = await asyncio.gather(*[execute_batch_part(part) for part in batch_parts])
                
                for part in batch_results:
                    if part.status == "completed":
                        completed_parts += 1
                    else:
                        failed_parts += 1
                    
                    executed_parts.add(part.part_id)
                    remaining_parts.remove(part)
                    
                    results.append({
                        "part_id": part.part_id,
                        "query": part.query,
                        "result": part.result,
                        "status": part.status,
                        "error": part.error,
                        "execution_order": part.execution_order
                    })
        
        # Calculate execution time
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # Check if all dependencies were resolved
        dependencies_resolved = all(
            all(dep in [r["part_id"] for r in results if r["status"] == "completed"] 
            for dep in part.dependencies
            for part in parts
        )
        
        orchestration_result = OrchestrationResult(
            orchestration_id=orchestration_id,
            total_parts=len(query_parts),
            completed_parts=completed_parts,
            failed_parts=failed_parts,
            execution_time=execution_time,
            results=results,
            dependencies_resolved=dependencies_resolved,
            timestamp=start_time
        )
        
        result = {
            "orchestration": orchestration_result.dict(),
            "execution_strategy": execution_strategy,
            "max_parallel": max_parallel,
            "summary": {
                "total_parts": len(query_parts),
                "completed_parts": completed_parts,
                "failed_parts": failed_parts,
                "success_rate": completed_parts / max(len(query_parts), 1),
                "execution_time": execution_time,
                "dependencies_resolved": dependencies_resolved
            },
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Orchestration completed: {completed_parts}/{len(query_parts)} parts successful")
        return result
        
    except Exception as e:
        logger.error(f"Multi-query orchestration failed: {e}")
        return {
            "error": str(e),
            "orchestration": None,
            "execution_strategy": execution_strategy,
            "summary": {
                "total_parts": len(query_parts),
                "completed_parts": 0,
                "failed_parts": len(query_parts),
                "success_rate": 0.0,
                "execution_time": 0.0,
                "dependencies_resolved": False
            }
        }
