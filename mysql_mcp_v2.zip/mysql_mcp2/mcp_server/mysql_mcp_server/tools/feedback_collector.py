"""
Feedback Collector Tool
Captures user feedback for LLM improvement
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class FeedbackEntry(BaseModel):
    """Feedback entry model"""
    feedback_id: str
    user_id: Optional[str]
    session_id: Optional[str]
    query: str
    result: Any
    feedback_type: str  # "positive", "negative", "suggestion"
    rating: Optional[int] = None  # 1-5 scale
    comment: Optional[str] = None
    timestamp: datetime
    metadata: Dict[str, Any] = Field(default_factory=dict)

@tool
async def feedback_collector(
    action: str = "submit",
    feedback_id: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    query: Optional[str] = None,
    result: Optional[Any] = None,
    feedback_type: str = "positive",
    rating: Optional[int] = None,
    comment: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Captures user feedback for LLM improvement and system optimization.
    
    Args:
        action: Action to perform (submit, get, analyze, stats)
        feedback_id: Unique feedback identifier
        user_id: User ID who provided feedback
        session_id: Session ID
        query: Original query that generated the result
        result: Query result that user is providing feedback on
        feedback_type: Type of feedback (positive, negative, suggestion)
        rating: Rating on 1-5 scale
        comment: Additional comment
        metadata: Additional metadata
        
    Returns:
        Dict containing feedback collection results
    """
    try:
        logger.info(f"Feedback collector action: {action}")
        
        if action == "submit":
            if not feedback_id:
                feedback_id = f"feedback_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hash(str(datetime.now()))}"
            
            # Create feedback entry
            feedback_entry = FeedbackEntry(
                feedback_id=feedback_id,
                user_id=user_id,
                session_id=session_id,
                query=query or "",
                result=result,
                feedback_type=feedback_type,
                rating=rating,
                comment=comment,
                timestamp=datetime.now(),
                metadata=metadata or {}
            )
            
            # Store feedback (in production, this would go to a database)
            if not hasattr(db_manager, 'feedback_storage'):
                db_manager.feedback_storage = []
            
            db_manager.feedback_storage.append(feedback_entry.dict())
            
            logger.info(f"Feedback submitted: {feedback_id} ({feedback_type})")
            
            return {
                "action": "submit",
                "feedback_id": feedback_id,
                "submitted": True,
                "timestamp": feedback_entry.timestamp.isoformat(),
                "feedback_type": feedback_type,
                "rating": rating
            }
        
        elif action == "get":
            # Get feedback entries
            if not hasattr(db_manager, 'feedback_storage'):
                db_manager.feedback_storage = []
            
            limit = metadata.get('limit', 50) if metadata else 50
            offset = metadata.get('offset', 0) if metadata else 0
            
            feedback_entries = db_manager.feedback_storage[offset:offset + limit]
            
            return {
                "action": "get",
                "feedback_entries": feedback_entries,
                "total_feedback": len(db_manager.feedback_storage),
                "returned_feedback": len(feedback_entries),
                "offset": offset,
                "limit": limit
            }
        
        elif action == "analyze":
            # Analyze feedback patterns
            if not hasattr(db_manager, 'feedback_storage'):
                db_manager.feedback_storage = []
            
            total_feedback = len(db_manager.feedback_storage)
            positive_feedback = len([f for f in db_manager.feedback_storage if f.get('feedback_type') == 'positive'])
            negative_feedback = len([f for f in db_manager.feedback_storage if f.get('feedback_type') == 'negative'])
            suggestions = len([f for f in db_manager.feedback_storage if f.get('feedback_type') == 'suggestion'])
            
            # Calculate average rating
            ratings = [f.get('rating') for f in db_manager.feedback_storage if f.get('rating') is not None]
            avg_rating = sum(ratings) / len(ratings) if ratings else 0.0
            
            # Get most common feedback types
            feedback_types = {}
            for entry in db_manager.feedback_storage:
                ftype = entry.get('feedback_type', 'unknown')
                feedback_types[ftype] = feedback_types.get(ftype, 0) + 1
            
            analysis = {
                "total_feedback": total_feedback,
                "positive_feedback": positive_feedback,
                "negative_feedback": negative_feedback,
                "suggestions": suggestions,
                "average_rating": avg_rating,
                "feedback_distribution": feedback_types,
                "satisfaction_rate": positive_feedback / max(total_feedback, 1),
                "improvement_areas": [
                    "Query accuracy" if negative_feedback > positive_feedback else "Response time",
                    "Result formatting" if suggestions > 0 else "User experience"
                ]
            }
            
            return {
                "action": "analyze",
                "analysis": analysis,
                "timestamp": datetime.now().isoformat()
            }
        
        elif action == "stats":
            # Get feedback statistics
            if not hasattr(db_manager, 'feedback_storage'):
                db_manager.feedback_storage = []
            
            total_feedback = len(db_manager.feedback_storage)
            
            # Recent feedback (last 24 hours)
            cutoff_time = datetime.now() - timedelta(hours=24)
            recent_feedback = [
                f for f in db_manager.feedback_storage 
                if f.get('timestamp', datetime.min) >= cutoff_time
            ]
            
            stats = {
                "total_feedback": total_feedback,
                "recent_feedback_24h": len(recent_feedback),
                "feedback_types": {
                    "positive": len([f for f in db_manager.feedback_storage if f.get('feedback_type') == 'positive']),
                    "negative": len([f for f in db_manager.feedback_storage if f.get('feedback_type') == 'negative']),
                    "suggestion": len([f for f in db_manager.feedback_storage if f.get('feedback_type') == 'suggestion'])
                },
                "average_rating": sum(f.get('rating', 0) for f in db_manager.feedback_storage if f.get('rating')) / max(len([f for f in db_manager.feedback_storage if f.get('rating')]), 1)
            }
            
            return {
                "action": "stats",
                "statistics": stats,
                "timestamp": datetime.now().isoformat()
            }
        
        else:
            return {
                "error": f"Invalid action: {action}",
                "available_actions": ["submit", "get", "analyze", "stats"]
            }
        
    except Exception as e:
        logger.error(f"Feedback collection failed: {e}")
        return {
            "error": str(e),
            "action": action,
            "submitted": False
        }
