"""
Response Ranker Tool
Ranks candidate SQL queries by confidence
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime

logger = logging.getLogger(__name__)

class QueryCandidate(BaseModel):
    """Query candidate model"""
    query: str
    confidence: float
    execution_time: Optional[float] = None
    result_count: Optional[int] = None
    complexity_score: float = 0.0
    optimization_score: float = 0.0
    ranking_score: float = 0.0

@tool
def response_ranker(
    query_candidates: List[Dict[str, Any]],
    ranking_factors: List[str] = None
) -> Dict[str, Any]:
    """
    Ranks candidate SQL queries by confidence and other factors.
    
    Args:
        query_candidates: List of candidate queries with metadata
        ranking_factors: Factors to consider in ranking (confidence, execution_time, result_count, complexity)
        
    Returns:
        Dict containing ranked queries and ranking analysis
    """
    try:
        logger.info(f"Ranking {len(query_candidates)} query candidates")
        
        if not query_candidates:
            return {
                "ranked_queries": [],
                "ranking_analysis": {},
                "total_candidates": 0
            }
        
        if ranking_factors is None:
            ranking_factors = ["confidence", "execution_time", "result_count", "complexity"]
        
        # Convert to QueryCandidate objects
        candidates = []
        for candidate in query_candidates:
            query_candidate = QueryCandidate(
                query=candidate.get('query', ''),
                confidence=candidate.get('confidence', 0.0),
                execution_time=candidate.get('execution_time'),
                result_count=candidate.get('result_count'),
                complexity_score=candidate.get('complexity_score', 0.0),
                optimization_score=candidate.get('optimization_score', 0.0)
            )
            candidates.append(query_candidate)
        
        # Calculate ranking scores
        for candidate in candidates:
            ranking_score = 0.0
            factors_used = 0
            
            # Confidence factor (0-1, higher is better)
            if "confidence" in ranking_factors:
                ranking_score += candidate.confidence * 0.4
                factors_used += 1
            
            # Execution time factor (0-1, lower is better)
            if "execution_time" in ranking_factors and candidate.execution_time is not None:
                # Normalize execution time (assume 10s is max for good score)
                time_score = max(0, 1 - (candidate.execution_time / 10.0))
                ranking_score += time_score * 0.3
                factors_used += 1
            
            # Result count factor (0-1, moderate results are better)
            if "result_count" in ranking_factors and candidate.result_count is not None:
                # Prefer results between 10-1000 rows
                if 10 <= candidate.result_count <= 1000:
                    count_score = 1.0
                elif candidate.result_count < 10:
                    count_score = candidate.result_count / 10.0
                else:
                    count_score = max(0, 1 - (candidate.result_count - 1000) / 10000.0)
                ranking_score += count_score * 0.2
                factors_used += 1
            
            # Complexity factor (0-1, lower complexity is better)
            if "complexity" in ranking_factors:
                complexity_score = max(0, 1 - candidate.complexity_score)
                ranking_score += complexity_score * 0.1
                factors_used += 1
            
            # Normalize by number of factors used
            if factors_used > 0:
                ranking_score = ranking_score / factors_used
            
            candidate.ranking_score = ranking_score
        
        # Sort by ranking score (descending)
        ranked_candidates = sorted(candidates, key=lambda x: x.ranking_score, reverse=True)
        
        # Generate ranking analysis
        ranking_analysis = {
            "total_candidates": len(candidates),
            "ranking_factors": ranking_factors,
            "score_distribution": {
                "min_score": min(c.ranking_score for c in candidates),
                "max_score": max(c.ranking_score for c in candidates),
                "avg_score": sum(c.ranking_score for c in candidates) / len(candidates)
            },
            "top_candidate": {
                "query": ranked_candidates[0].query if ranked_candidates else None,
                "ranking_score": ranked_candidates[0].ranking_score if ranked_candidates else None,
                "confidence": ranked_candidates[0].confidence if ranked_candidates else None
            }
        }
        
        # Add ranking positions
        for i, candidate in enumerate(ranked_candidates):
            candidate.ranking_position = i + 1
        
        result = {
            "ranked_queries": [candidate.dict() for candidate in ranked_candidates],
            "ranking_analysis": ranking_analysis,
            "total_candidates": len(candidates),
            "ranking_timestamp": datetime.now().isoformat(),
            "recommendations": {
                "best_query": ranked_candidates[0].query if ranked_candidates else None,
                "confidence_threshold": 0.7,
                "execution_priority": "high" if ranked_candidates[0].ranking_score > 0.8 else "medium" if ranked_candidates[0].ranking_score > 0.5 else "low"
            }
        }
        
        logger.info(f"Query ranking completed: {len(ranked_candidates)} candidates ranked")
        return result
        
    except Exception as e:
        logger.error(f"Response ranking failed: {e}")
        return {
            "error": str(e),
            "ranked_queries": [],
            "ranking_analysis": {},
            "total_candidates": 0
        }
