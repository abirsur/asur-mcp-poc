"""
Schema Drift Detector Tool
Detects database schema changes
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class SchemaChange(BaseModel):
    """Schema change model"""
    change_type: str  # "table_added", "table_removed", "column_added", "column_removed", "column_modified"
    table_name: str
    column_name: Optional[str] = None
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    severity: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    description: str
    timestamp: datetime
    impact_assessment: List[str]

@tool
async def schema_drift_detector(
    compare_with: str = "previous",
    detection_sensitivity: str = "medium"
) -> Dict[str, Any]:
    """
    Detects database schema changes and drift.
    
    Args:
        compare_with: What to compare against (previous, baseline, snapshot)
        detection_sensitivity: Detection sensitivity (low, medium, high)
        
    Returns:
        Dict containing schema drift detection results
    """
    try:
        logger.info("Detecting schema drift")
        
        # Get current schema
        current_schema = db_manager.get_schema_info()
        if not current_schema:
            await db_manager.refresh_schema_cache()
            current_schema = db_manager.get_schema_info()
        
        if not current_schema:
            return {
                "error": "No current schema available",
                "changes": [],
                "drift_detected": False
            }
        
        # Get previous schema (in production, this would be stored)
        if not hasattr(db_manager, 'schema_snapshots'):
            db_manager.schema_snapshots = []
        
        # Find the most recent snapshot
        previous_schema = None
        if db_manager.schema_snapshots:
            previous_schema = db_manager.schema_snapshots[-1]
        
        if not previous_schema:
            # No previous schema to compare with
            return {
                "changes": [],
                "drift_detected": False,
                "message": "No previous schema available for comparison",
                "current_schema": {
                    "tables_count": len(current_schema.tables),
                    "relationships_count": len(current_schema.relationships),
                    "indexes_count": len(current_schema.indexes)
                }
            }
        
        changes = []
        
        # Compare tables
        current_tables = set(current_schema.tables.keys())
        previous_tables = set(previous_schema.get('tables', {}).keys())
        
        # New tables
        new_tables = current_tables - previous_tables
        for table in new_tables:
            change = SchemaChange(
                change_type="table_added",
                table_name=table,
                severity="MEDIUM",
                description=f"New table '{table}' added to schema",
                timestamp=datetime.now(),
                impact_assessment=[
                    "New table available for queries",
                    "May affect existing query plans",
                    "Consider updating documentation"
                ]
            )
            changes.append(change)
        
        # Removed tables
        removed_tables = previous_tables - current_tables
        for table in removed_tables:
            change = SchemaChange(
                change_type="table_removed",
                table_name=table,
                severity="HIGH",
                description=f"Table '{table}' removed from schema",
                timestamp=datetime.now(),
                impact_assessment=[
                    "Queries referencing this table will fail",
                    "Update existing queries",
                    "Check for dependent views or procedures"
                ]
            )
            changes.append(change)
        
        # Compare columns for existing tables
        common_tables = current_tables & previous_tables
        for table in common_tables:
            current_table = current_schema.tables[table]
            previous_table = previous_schema.get('tables', {}).get(table, {})
            
            current_columns = {col['COLUMN_NAME']: col for col in current_table.get('columns', [])}
            previous_columns = {col['COLUMN_NAME']: col for col in previous_table.get('columns', [])}
            
            # New columns
            new_columns = set(current_columns.keys()) - set(previous_columns.keys())
            for column in new_columns:
                change = SchemaChange(
                    change_type="column_added",
                    table_name=table,
                    column_name=column,
                    severity="LOW",
                    description=f"New column '{column}' added to table '{table}'",
                    timestamp=datetime.now(),
                    impact_assessment=[
                        "New column available for queries",
                        "Existing queries unaffected",
                        "Consider updating documentation"
                    ]
                )
                changes.append(change)
            
            # Removed columns
            removed_columns = set(previous_columns.keys()) - set(current_columns.keys())
            for column in removed_columns:
                change = SchemaChange(
                    change_type="column_removed",
                    table_name=table,
                    column_name=column,
                    severity="HIGH",
                    description=f"Column '{column}' removed from table '{table}'",
                    timestamp=datetime.now(),
                    impact_assessment=[
                        "Queries referencing this column will fail",
                        "Update existing queries",
                        "Check for dependent views or procedures"
                    ]
                )
                changes.append(change)
            
            # Modified columns
            common_columns = set(current_columns.keys()) & set(previous_columns.keys())
            for column in common_columns:
                current_col = current_columns[column]
                previous_col = previous_columns[column]
                
                # Check for data type changes
                if current_col.get('DATA_TYPE') != previous_col.get('DATA_TYPE'):
                    change = SchemaChange(
                        change_type="column_modified",
                        table_name=table,
                        column_name=column,
                        old_value=previous_col.get('DATA_TYPE'),
                        new_value=current_col.get('DATA_TYPE'),
                        severity="MEDIUM",
                        description=f"Column '{column}' data type changed from {previous_col.get('DATA_TYPE')} to {current_col.get('DATA_TYPE')}",
                        timestamp=datetime.now(),
                        impact_assessment=[
                            "Data type change may affect query results",
                            "Check for data compatibility",
                            "Update application code if needed"
                        ]
                    )
                    changes.append(change)
                
                # Check for nullability changes
                if current_col.get('IS_NULLABLE') != previous_col.get('IS_NULLABLE'):
                    change = SchemaChange(
                        change_type="column_modified",
                        table_name=table,
                        column_name=column,
                        old_value=previous_col.get('IS_NULLABLE'),
                        new_value=current_col.get('IS_NULLABLE'),
                        severity="MEDIUM",
                        description=f"Column '{column}' nullability changed from {previous_col.get('IS_NULLABLE')} to {current_col.get('IS_NULLABLE')}",
                        timestamp=datetime.now(),
                        impact_assessment=[
                            "Nullability change may affect query results",
                            "Check for data compatibility",
                            "Update application code if needed"
                        ]
                    )
                    changes.append(change)
        
        # Compare relationships
        current_relationships = current_schema.relationships
        previous_relationships = previous_schema.get('relationships', {})
        
        # New relationships
        for table, rels in current_relationships.items():
            if table not in previous_relationships:
                for rel in rels:
                    change = SchemaChange(
                        change_type="relationship_added",
                        table_name=table,
                        column_name=rel.get('column'),
                        severity="LOW",
                        description=f"New relationship added: {table}.{rel.get('column')} -> {rel.get('referenced_table')}.{rel.get('referenced_column')}",
                        timestamp=datetime.now(),
                        impact_assessment=[
                            "New join opportunities available",
                            "May improve query performance",
                            "Consider updating query optimization"
                        ]
                    )
                    changes.append(change)
        
        # Compare indexes
        current_indexes = current_schema.indexes
        previous_indexes = previous_schema.get('indexes', {})
        
        # New indexes
        for table, indexes in current_indexes.items():
            if table not in previous_indexes:
                for index in indexes:
                    change = SchemaChange(
                        change_type="index_added",
                        table_name=table,
                        column_name=index.get('column'),
                        severity="LOW",
                        description=f"New index '{index.get('name')}' added to table '{table}'",
                        timestamp=datetime.now(),
                        impact_assessment=[
                            "May improve query performance",
                            "Consider updating query optimization",
                            "Monitor index usage"
                        ]
                    )
                    changes.append(change)
        
        # Calculate drift severity
        critical_changes = len([c for c in changes if c.severity == "CRITICAL"])
        high_changes = len([c for c in changes if c.severity == "HIGH"])
        medium_changes = len([c for c in changes if c.severity == "MEDIUM"])
        low_changes = len([c for c in changes if c.severity == "LOW"])
        
        overall_severity = "LOW"
        if critical_changes > 0:
            overall_severity = "CRITICAL"
        elif high_changes > 0:
            overall_severity = "HIGH"
        elif medium_changes > 0:
            overall_severity = "MEDIUM"
        
        # Store current schema as new snapshot
        db_manager.schema_snapshots.append({
            "timestamp": datetime.now().isoformat(),
            "tables": current_schema.tables,
            "relationships": current_schema.relationships,
            "indexes": current_schema.indexes
        })
        
        # Keep only last 10 snapshots
        if len(db_manager.schema_snapshots) > 10:
            db_manager.schema_snapshots = db_manager.schema_snapshots[-10:]
        
        result = {
            "changes": [change.dict() for change in changes],
            "drift_detected": len(changes) > 0,
            "overall_severity": overall_severity,
            "change_summary": {
                "total_changes": len(changes),
                "critical_changes": critical_changes,
                "high_changes": high_changes,
                "medium_changes": medium_changes,
                "low_changes": low_changes
            },
            "detection_timestamp": datetime.now().isoformat(),
            "comparison_baseline": compare_with
        }
        
        logger.info(f"Schema drift detection completed: {len(changes)} changes found")
        return result
        
    except Exception as e:
        logger.error(f"Schema drift detection failed: {e}")
        return {
            "error": str(e),
            "changes": [],
            "drift_detected": False
        }
