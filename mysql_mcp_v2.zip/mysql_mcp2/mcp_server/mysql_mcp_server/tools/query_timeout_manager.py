"""
Query Timeout Manager Tool
Cancels or retries long-running queries
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class TimeoutConfig(BaseModel):
    """Timeout configuration model"""
    default_timeout: int = Field(default=30, description="Default timeout in seconds")
    max_timeout: int = Field(default=300, description="Maximum timeout in seconds")
    warning_threshold: int = Field(default=10, description="Warning threshold in seconds")
    retry_on_timeout: bool = Field(default=True, description="Whether to retry on timeout")

@tool
async def query_timeout_manager(
    query: str,
    timeout_seconds: int = 30,
    enable_warnings: bool = True,
    auto_cancel: bool = True
) -> Dict[str, Any]:
    """
    Manages query timeouts and cancels long-running queries.
    
    Args:
        query: SQL query to execute with timeout
        timeout_seconds: Timeout in seconds
        enable_warnings: Whether to enable timeout warnings
        auto_cancel: Whether to automatically cancel on timeout
        
    Returns:
        Dict containing timeout management results
    """
    try:
        logger.info(f"Managing timeout for query: {timeout_seconds}s")
        
        # Validate timeout
        if timeout_seconds <= 0:
            return {
                "error": "Invalid timeout value",
                "timeout_seconds": timeout_seconds,
                "status": "invalid"
            }
        
        if timeout_seconds > 300:  # 5 minutes max
            timeout_seconds = 300
            logger.warning(f"Timeout capped at 300 seconds")
        
        # Execute query with timeout
        start_time = datetime.now()
        
        try:
            # Use asyncio.wait_for to implement timeout
            result = await asyncio.wait_for(
                db_manager.execute_query(query),
                timeout=timeout_seconds
            )
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Check if query was close to timeout
            warning_triggered = False
            if enable_warnings and execution_time > timeout_seconds * 0.8:
                warning_triggered = True
                logger.warning(f"Query execution time ({execution_time:.2f}s) approaching timeout ({timeout_seconds}s)")
            
            return {
                "status": "success",
                "query": query,
                "execution_time": execution_time,
                "timeout_seconds": timeout_seconds,
                "result": result.dict() if hasattr(result, 'dict') else result,
                "warning_triggered": warning_triggered,
                "timestamp": start_time.isoformat()
            }
            
        except asyncio.TimeoutError:
            execution_time = (datetime.now() - start_time).total_seconds()
            
            logger.error(f"Query timeout after {execution_time:.2f}s (limit: {timeout_seconds}s)")
            
            return {
                "status": "timeout",
                "query": query,
                "execution_time": execution_time,
                "timeout_seconds": timeout_seconds,
                "error": f"Query timeout after {timeout_seconds} seconds",
                "timestamp": start_time.isoformat(),
                "suggestions": [
                    "Optimize query performance",
                    "Add appropriate indexes",
                    "Reduce result set size",
                    "Consider query pagination"
                ]
            }
            
    except Exception as e:
        logger.error(f"Timeout management failed: {e}")
        return {
            "status": "error",
            "query": query,
            "error": str(e),
            "timeout_seconds": timeout_seconds,
            "timestamp": datetime.now().isoformat()
        }

@tool
async def cancel_long_running_queries(
    max_execution_time: int = 60,
    force_cancel: bool = False
) -> Dict[str, Any]:
    """
    Cancels queries that have been running too long.
    
    Args:
        max_execution_time: Maximum execution time in seconds
        force_cancel: Whether to force cancel all long-running queries
        
    Returns:
        Dict containing cancellation results
    """
    try:
        logger.info(f"Cancelling queries running longer than {max_execution_time}s")
        
        # Get current time
        now = datetime.now()
        cutoff_time = now - timedelta(seconds=max_execution_time)
        
        # Get query history
        query_history = db_manager.get_query_history(limit=100)
        
        # Find long-running queries
        long_running_queries = []
        for query_info in query_history:
            query_time = query_info.get('timestamp', datetime.min)
            if query_time < cutoff_time:
                long_running_queries.append(query_info)
        
        if not long_running_queries:
            return {
                "status": "no_queries",
                "message": "No long-running queries found",
                "max_execution_time": max_execution_time,
                "timestamp": now.isoformat()
            }
        
        # In a real implementation, you would cancel the actual queries
        # For now, we'll just log them
        cancelled_count = 0
        for query_info in long_running_queries:
            logger.warning(f"Cancelling long-running query: {query_info.get('query', 'Unknown')[:100]}...")
            cancelled_count += 1
        
        return {
            "status": "cancelled",
            "cancelled_count": cancelled_count,
            "long_running_queries": len(long_running_queries),
            "max_execution_time": max_execution_time,
            "timestamp": now.isoformat(),
            "message": f"Cancelled {cancelled_count} long-running queries"
        }
        
    except Exception as e:
        logger.error(f"Query cancellation failed: {e}")
        return {
            "status": "error",
            "error": str(e),
            "cancelled_count": 0,
            "timestamp": datetime.now().isoformat()
        }
