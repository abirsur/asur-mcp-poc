"""
SQL Sanitizer Tool
Sanitizes SQL against injection or destructive operations
"""

import logging
import re
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

class SanitizationResult(BaseModel):
    """SQL sanitization result model"""
    is_safe: bool
    sanitized_query: str
    warnings: List[str]
    blocked_operations: List[str]
    risk_level: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"

@tool
def sql_sanitizer(
    query: str,
    allow_ddl: bool = False,
    allow_dml: bool = True,
    max_query_length: int = 10000
) -> Dict[str, Any]:
    """
    Sanitizes SQL against injection and destructive operations.
    
    Args:
        query: SQL query to sanitize
        allow_ddl: Whether to allow DDL operations (CREATE, DROP, ALTER)
        allow_dml: Whether to allow DML operations (INSERT, UPDATE, DELETE)
        max_query_length: Maximum allowed query length
        
    Returns:
        Dict containing sanitization results and safety assessment
    """
    try:
        logger.info("Sanitizing SQL query")
        
        # Basic checks
        warnings = []
        blocked_operations = []
        risk_level = "LOW"
        
        # Check query length
        if len(query) > max_query_length:
            return {
                "is_safe": False,
                "sanitized_query": "",
                "warnings": [f"Query too long: {len(query)} > {max_query_length}"],
                "blocked_operations": ["LENGTH_EXCEEDED"],
                "risk_level": "CRITICAL",
                "error": "Query exceeds maximum length"
            }
        
        # Normalize query for analysis
        query_upper = query.upper().strip()
        
        # Check for dangerous operations
        dangerous_operations = {
            'DROP': 'DROP TABLE/DATABASE',
            'TRUNCATE': 'TRUNCATE TABLE',
            'DELETE': 'DELETE without WHERE',
            'ALTER': 'ALTER TABLE',
            'CREATE': 'CREATE TABLE/DATABASE',
            'GRANT': 'GRANT permissions',
            'REVOKE': 'REVOKE permissions',
            'EXEC': 'EXECUTE stored procedures',
            'EXECUTE': 'EXECUTE stored procedures',
            'CALL': 'CALL stored procedures'
        }
        
        # Check for blocked operations
        for operation, description in dangerous_operations.items():
            if operation in query_upper:
                if operation in ['DROP', 'TRUNCATE', 'ALTER', 'CREATE'] and not allow_ddl:
                    blocked_operations.append(description)
                    risk_level = "CRITICAL"
                elif operation in ['DELETE'] and not allow_dml:
                    blocked_operations.append(description)
                    risk_level = "HIGH"
                elif operation in ['GRANT', 'REVOKE', 'EXEC', 'EXECUTE', 'CALL']:
                    blocked_operations.append(description)
                    risk_level = "CRITICAL"
        
        # Check for SQL injection patterns
        injection_patterns = [
            r"'.*OR.*'.*=",  # OR injection
            r"'.*UNION.*SELECT",  # UNION injection
            r"'.*;.*--",  # Comment injection
            r"'.*;.*DROP",  # Drop injection
            r"'.*;.*INSERT",  # Insert injection
            r"'.*;.*UPDATE",  # Update injection
            r"'.*;.*DELETE",  # Delete injection
            r"'.*;.*EXEC",  # Exec injection
            r"'.*;.*CALL",  # Call injection
            r"'.*;.*GRANT",  # Grant injection
            r"'.*;.*REVOKE",  # Revoke injection
        ]
        
        for pattern in injection_patterns:
            if re.search(pattern, query_upper):
                warnings.append(f"Potential SQL injection pattern detected: {pattern}")
                risk_level = "HIGH"
        
        # Check for suspicious patterns
        suspicious_patterns = [
            r"'.*;.*",  # Multiple statements
            r"'.*--.*",  # Comments
            r"'.*/\*.*\*/",  # Block comments
            r"'.*WAITFOR.*",  # Time delays
            r"'.*SLEEP.*",  # Sleep functions
            r"'.*BENCHMARK.*",  # Benchmark functions
        ]
        
        for pattern in suspicious_patterns:
            if re.search(pattern, query_upper):
                warnings.append(f"Suspicious pattern detected: {pattern}")
                if risk_level == "LOW":
                    risk_level = "MEDIUM"
        
        # Check for proper WHERE clauses in DELETE/UPDATE
        if 'DELETE' in query_upper and 'WHERE' not in query_upper:
            warnings.append("DELETE without WHERE clause - potentially dangerous")
            risk_level = "HIGH"
        elif 'UPDATE' in query_upper and 'WHERE' not in query_upper:
            warnings.append("UPDATE without WHERE clause - potentially dangerous")
            risk_level = "HIGH"
        
        # Check for LIMIT clauses (good practice)
        if 'SELECT' in query_upper and 'LIMIT' not in query_upper:
            warnings.append("SELECT without LIMIT - may return large result set")
            if risk_level == "LOW":
                risk_level = "MEDIUM"
        
        # Sanitize the query
        sanitized_query = query
        
        # Remove comments
        sanitized_query = re.sub(r'--.*$', '', sanitized_query, flags=re.MULTILINE)
        sanitized_query = re.sub(r'/\*.*?\*/', '', sanitized_query, flags=re.DOTALL)
        
        # Remove multiple statements (keep only first)
        statements = [stmt.strip() for stmt in sanitized_query.split(';') if stmt.strip()]
        if len(statements) > 1:
            sanitized_query = statements[0]
            warnings.append("Multiple statements detected - only first statement kept")
        
        # Trim whitespace
        sanitized_query = sanitized_query.strip()
        
        # Determine if query is safe
        is_safe = len(blocked_operations) == 0 and risk_level != "CRITICAL"
        
        result = {
            "is_safe": is_safe,
            "sanitized_query": sanitized_query,
            "warnings": warnings,
            "blocked_operations": blocked_operations,
            "risk_level": risk_level,
            "analysis": {
                "original_length": len(query),
                "sanitized_length": len(sanitized_query),
                "statements_detected": len(statements),
                "injection_patterns_found": len([w for w in warnings if "injection" in w.lower()]),
                "suspicious_patterns_found": len([w for w in warnings if "suspicious" in w.lower()])
            }
        }
        
        logger.info(f"SQL sanitization completed - Risk level: {risk_level}, Safe: {is_safe}")
        return result
        
    except Exception as e:
        logger.error(f"SQL sanitization failed: {e}")
        return {
            "is_safe": False,
            "sanitized_query": "",
            "warnings": [f"Sanitization error: {str(e)}"],
            "blocked_operations": ["SANITIZATION_ERROR"],
            "risk_level": "CRITICAL",
            "error": str(e)
        }
