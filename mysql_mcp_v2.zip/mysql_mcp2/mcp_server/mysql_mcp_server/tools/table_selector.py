"""
Table Selector Tool
Selects relevant tables for a query
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class TableSelection(BaseModel):
    """Table selection model"""
    table_name: str
    relevance_score: float
    reason: str
    columns: List[str]
    row_count: Optional[int]

@tool
async def table_selector(
    query_intent: Dict[str, Any],
    max_tables: int = 5,
    min_relevance: float = 0.3
) -> Dict[str, Any]:
    """
    Selects relevant tables for a query based on intent and schema analysis.
    
    Args:
        query_intent: Structured query intent from NL interpreter
        max_tables: Maximum number of tables to return
        min_relevance: Minimum relevance score threshold
        
    Returns:
        Dict containing selected tables with relevance scores
    """
    try:
        logger.info("Selecting relevant tables for query")
        
        # Get schema information
        schema_info = db_manager.get_schema_info()
        if not schema_info:
            await db_manager.refresh_schema_cache()
            schema_info = db_manager.get_schema_info()
        
        if not schema_info:
            return {"error": "No schema information available"}
        
        # Extract intent information
        intent_tables = query_intent.get('tables', [])
        intent_columns = query_intent.get('columns', [])
        intent_conditions = query_intent.get('conditions', [])
        
        table_scores = {}
        
        # Score tables based on intent
        for table_name, table_info in schema_info.tables.items():
            score = 0.0
            reasons = []
            
            # Direct table mention
            if table_name.lower() in [t.lower() for t in intent_tables]:
                score += 1.0
                reasons.append("Direct table mention")
            
            # Column mentions
            table_columns = [col['COLUMN_NAME'] for col in table_info['columns']]
            for intent_col in intent_columns:
                if intent_col.lower() in [col.lower() for col in table_columns]:
                    score += 0.5
                    reasons.append(f"Column '{intent_col}' found")
            
            # Condition column mentions
            for condition in intent_conditions:
                col_name = condition.get('column', '')
                if col_name.lower() in [col.lower() for col in table_columns]:
                    score += 0.3
                    reasons.append(f"Condition column '{col_name}' found")
            
            # Table name similarity
            for intent_table in intent_tables:
                if intent_table.lower() in table_name.lower() or table_name.lower() in intent_table.lower():
                    score += 0.7
                    reasons.append(f"Name similarity with '{intent_table}'")
            
            # Relationship analysis
            if table_name in schema_info.relationships:
                for rel in schema_info.relationships[table_name]:
                    ref_table = rel['referenced_table']
                    if ref_table in intent_tables:
                        score += 0.4
                        reasons.append(f"Related to '{ref_table}'")
            
            # Table size consideration (prefer smaller tables for joins)
            try:
                count_result = await db_manager.execute_query(f"SELECT COUNT(*) as count FROM `{table_name}`")
                row_count = count_result.rows[0]['count'] if count_result.rows else 0
                
                # Prefer tables with reasonable size
                if row_count < 10000:
                    score += 0.1
                    reasons.append("Reasonable table size")
                elif row_count > 100000:
                    score -= 0.1
                    reasons.append("Large table size")
            except:
                pass  # Ignore errors in row count
            
            if score > 0:
                table_scores[table_name] = {
                    'score': score,
                    'reasons': reasons,
                    'row_count': None
                }
        
        # Sort by score and select top tables
        sorted_tables = sorted(table_scores.items(), key=lambda x: x[1]['score'], reverse=True)
        selected_tables = []
        
        for table_name, info in sorted_tables[:max_tables]:
            if info['score'] >= min_relevance:
                # Get table columns
                table_info = schema_info.tables[table_name]
                columns = [col['COLUMN_NAME'] for col in table_info['columns']]
                
                selection = TableSelection(
                    table_name=table_name,
                    relevance_score=info['score'],
                    reason="; ".join(info['reasons']),
                    columns=columns,
                    row_count=info.get('row_count')
                )
                selected_tables.append(selection)
        
        result = {
            "selected_tables": [table.dict() for table in selected_tables],
            "total_tables_analyzed": len(schema_info.tables),
            "tables_selected": len(selected_tables),
            "selection_criteria": {
                "max_tables": max_tables,
                "min_relevance": min_relevance,
                "intent_tables": intent_tables,
                "intent_columns": intent_columns
            }
        }
        
        logger.info(f"Selected {len(selected_tables)} relevant tables")
        return result
        
    except Exception as e:
        logger.error(f"Table selection failed: {e}")
        return {
            "error": str(e),
            "selected_tables": [],
            "total_tables_analyzed": 0
        }
