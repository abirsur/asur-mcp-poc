"""
Plan Analyzer Tool
Analyzes EXPLAIN output for bottlenecks
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class PlanAnalysis(BaseModel):
    """Query plan analysis model"""
    table: str
    type: str
    possible_keys: List[str]
    key: Optional[str]
    key_len: Optional[int]
    ref: Optional[str]
    rows: int
    extra: Optional[str]
    performance_rating: str  # "EXCELLENT", "GOOD", "FAIR", "POOR"
    issues: List[str]
    suggestions: List[str]

@tool
async def plan_analyzer(
    query: str,
    include_suggestions: bool = True
) -> Dict[str, Any]:
    """
    Analyzes EXPLAIN output for performance bottlenecks and optimization opportunities.
    
    Args:
        query: SQL query to analyze
        include_suggestions: Whether to include optimization suggestions
        
    Returns:
        Dict containing plan analysis and recommendations
    """
    try:
        logger.info("Analyzing query execution plan")
        
        # Get EXPLAIN output
        explain_query = f"EXPLAIN {query}"
        explain_result = await db_manager.execute_query(explain_query)
        
        if not explain_result.rows:
            return {
                "error": "No execution plan available",
                "query": query,
                "analysis": []
            }
        
        analyses = []
        overall_rating = "EXCELLENT"
        total_rows = 0
        performance_issues = []
        
        for row in explain_result.rows:
            # Extract plan information
            table = row.get('table', 'Unknown')
            type_ = row.get('type', 'Unknown')
            possible_keys = row.get('possible_keys', '').split(',') if row.get('possible_keys') else []
            key = row.get('key')
            key_len = row.get('key_len')
            ref = row.get('ref')
            rows = row.get('rows', 0)
            extra = row.get('Extra', '')
            
            total_rows += rows
            
            # Analyze performance
            issues = []
            suggestions = []
            performance_rating = "EXCELLENT"
            
            # Check for full table scans
            if type_ == 'ALL':
                issues.append("Full table scan detected")
                suggestions.append("Add appropriate indexes")
                performance_rating = "POOR"
                overall_rating = "POOR"
            
            # Check for index usage
            elif type_ in ['index', 'range', 'ref', 'eq_ref']:
                if not key:
                    issues.append("Index available but not used")
                    suggestions.append("Check index selectivity and query conditions")
                    performance_rating = "FAIR"
                    if overall_rating == "EXCELLENT":
                        overall_rating = "FAIR"
            
            # Check for temporary tables
            if 'Using temporary' in extra:
                issues.append("Temporary table created")
                suggestions.append("Optimize GROUP BY or ORDER BY clauses")
                performance_rating = "FAIR"
                if overall_rating == "EXCELLENT":
                    overall_rating = "FAIR"
            
            # Check for filesort
            if 'Using filesort' in extra:
                issues.append("Filesort operation detected")
                suggestions.append("Add indexes for ORDER BY columns")
                performance_rating = "FAIR"
                if overall_rating == "EXCELLENT":
                    overall_rating = "FAIR"
            
            # Check for index scan
            if 'Using index' in extra:
                suggestions.append("Good: Using index efficiently")
            
            # Check for index condition pushdown
            if 'Using index condition' in extra:
                suggestions.append("Good: Using index condition pushdown")
            
            # Check row count
            if rows > 10000:
                issues.append(f"Large result set ({rows} rows)")
                suggestions.append("Consider adding LIMIT clause or optimizing WHERE conditions")
                if performance_rating == "EXCELLENT":
                    performance_rating = "FAIR"
                    if overall_rating == "EXCELLENT":
                        overall_rating = "FAIR"
            
            # Check for nested loop joins
            if type_ == 'ref' and rows > 1000:
                issues.append("Potentially expensive nested loop join")
                suggestions.append("Consider query restructuring or additional indexes")
                if performance_rating == "EXCELLENT":
                    performance_rating = "FAIR"
                    if overall_rating == "EXCELLENT":
                        overall_rating = "FAIR"
            
            analysis = PlanAnalysis(
                table=table,
                type=type_,
                possible_keys=possible_keys,
                key=key,
                key_len=key_len,
                ref=ref,
                rows=rows,
                extra=extra,
                performance_rating=performance_rating,
                issues=issues,
                suggestions=suggestions
            )
            
            analyses.append(analysis)
            performance_issues.extend(issues)
        
        # Generate overall recommendations
        overall_suggestions = []
        if overall_rating == "POOR":
            overall_suggestions.extend([
                "Consider adding indexes for frequently queried columns",
                "Optimize WHERE clauses to reduce result sets",
                "Consider query restructuring"
            ])
        elif overall_rating == "FAIR":
            overall_suggestions.extend([
                "Add indexes for better performance",
                "Consider query optimization"
            ])
        
        # Calculate performance score
        performance_score = 1.0
        if overall_rating == "POOR":
            performance_score = 0.2
        elif overall_rating == "FAIR":
            performance_score = 0.6
        elif overall_rating == "GOOD":
            performance_score = 0.8
        
        result = {
            "query": query,
            "overall_rating": overall_rating,
            "performance_score": performance_score,
            "total_rows": total_rows,
            "plan_analyses": [analysis.dict() for analysis in analyses],
            "summary": {
                "tables_analyzed": len(analyses),
                "performance_issues": len(performance_issues),
                "suggestions_count": sum(len(analysis.suggestions) for analysis in analyses),
                "worst_performing_table": max(analyses, key=lambda x: len(x.issues)).table if analyses else None
            }
        }
        
        if include_suggestions:
            result["overall_suggestions"] = overall_suggestions
        
        logger.info(f"Plan analysis completed: {overall_rating} rating, {len(performance_issues)} issues")
        return result
        
    except Exception as e:
        logger.error(f"Plan analysis failed: {e}")
        return {
            "error": str(e),
            "query": query,
            "overall_rating": "ERROR",
            "performance_score": 0.0,
            "plan_analyses": []
        }
