"""
Model Selector Tool
Chooses LLM/model endpoint by query complexity
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime

logger = logging.getLogger(__name__)

class ModelSelection(BaseModel):
    """Model selection model"""
    model_name: str
    model_type: str  # "fast", "balanced", "powerful"
    confidence: float
    reasoning: str
    estimated_cost: float
    estimated_time: float
    capabilities: List[str]

@tool
def model_selector(
    query: str,
    query_complexity: Optional[float] = None,
    user_preference: Optional[str] = None,
    budget_limit: Optional[float] = None
) -> Dict[str, Any]:
    """
    Chooses the most appropriate LLM/model endpoint based on query complexity.
    
    Args:
        query: SQL query or natural language query
        query_complexity: Complexity score (0-1, higher is more complex)
        user_preference: User's model preference (fast, balanced, powerful)
        budget_limit: Budget limit for model usage
        
    Returns:
        Dict containing model selection and reasoning
    """
    try:
        logger.info("Selecting appropriate model for query")
        
        # Calculate query complexity if not provided
        if query_complexity is None:
            query_complexity = calculate_query_complexity(query)
        
        # Available models with their characteristics
        models = {
            "gpt-3.5-turbo": {
                "type": "fast",
                "cost_per_token": 0.001,
                "max_tokens": 4000,
                "capabilities": ["simple_queries", "basic_analysis", "fast_response"],
                "best_for": "Simple queries, quick responses"
            },
            "gpt-4": {
                "type": "powerful",
                "cost_per_token": 0.03,
                "max_tokens": 8000,
                "capabilities": ["complex_queries", "advanced_analysis", "reasoning"],
                "best_for": "Complex queries, advanced reasoning"
            },
            "gpt-4-turbo": {
                "type": "balanced",
                "cost_per_token": 0.01,
                "max_tokens": 128000,
                "capabilities": ["complex_queries", "large_context", "balanced_performance"],
                "best_for": "Large queries, balanced performance"
            },
            "claude-3-sonnet": {
                "type": "balanced",
                "cost_per_token": 0.015,
                "max_tokens": 200000,
                "capabilities": ["complex_queries", "large_context", "code_analysis"],
                "best_for": "Code analysis, large context"
            },
            "claude-3-opus": {
                "type": "powerful",
                "cost_per_token": 0.075,
                "max_tokens": 200000,
                "capabilities": ["complex_queries", "advanced_reasoning", "code_analysis"],
                "best_for": "Most complex queries, advanced reasoning"
            }
        }
        
        # Select model based on complexity and preferences
        selected_model = None
        reasoning = ""
        
        if query_complexity < 0.3:
            # Simple query - use fast model
            if user_preference == "fast" or not user_preference:
                selected_model = "gpt-3.5-turbo"
                reasoning = "Simple query detected, using fast model for quick response"
            else:
                selected_model = "gpt-4-turbo"
                reasoning = "Simple query but user prefers balanced model"
        
        elif query_complexity < 0.7:
            # Medium complexity - use balanced model
            if user_preference == "fast":
                selected_model = "gpt-3.5-turbo"
                reasoning = "Medium complexity but user prefers fast model"
            elif user_preference == "powerful":
                selected_model = "gpt-4"
                reasoning = "Medium complexity but user prefers powerful model"
            else:
                selected_model = "gpt-4-turbo"
                reasoning = "Medium complexity query, using balanced model"
        
        else:
            # High complexity - use powerful model
            if user_preference == "fast":
                selected_model = "gpt-4-turbo"
                reasoning = "High complexity query, using most capable fast model"
            elif user_preference == "balanced":
                selected_model = "gpt-4-turbo"
                reasoning = "High complexity query, using balanced model"
            else:
                selected_model = "claude-3-opus"
                reasoning = "High complexity query, using most powerful model"
        
        # Apply budget constraints
        if budget_limit is not None:
            model_cost = models[selected_model]["cost_per_token"]
            estimated_tokens = len(query.split()) * 2  # Rough estimate
            estimated_cost = model_cost * estimated_tokens
            
            if estimated_cost > budget_limit:
                # Fall back to cheaper model
                if selected_model == "claude-3-opus":
                    selected_model = "gpt-4"
                    reasoning += " (downgraded due to budget constraints)"
                elif selected_model == "gpt-4":
                    selected_model = "gpt-4-turbo"
                    reasoning += " (downgraded due to budget constraints)"
                elif selected_model == "gpt-4-turbo":
                    selected_model = "gpt-3.5-turbo"
                    reasoning += " (downgraded due to budget constraints)"
        
        # Create model selection
        model_info = models[selected_model]
        model_selection = ModelSelection(
            model_name=selected_model,
            model_type=model_info["type"],
            confidence=0.9 if query_complexity < 0.5 else 0.8,
            reasoning=reasoning,
            estimated_cost=model_info["cost_per_token"] * len(query.split()) * 2,
            estimated_time=1.0 if model_info["type"] == "fast" else 2.0 if model_info["type"] == "balanced" else 3.0,
            capabilities=model_info["capabilities"]
        )
        
        result = {
            "model_selection": model_selection.dict(),
            "query": query,
            "query_complexity": query_complexity,
            "user_preference": user_preference,
            "budget_limit": budget_limit,
            "alternative_models": [
                {"name": name, "type": info["type"], "reason": f"Alternative: {info['best_for']}"}
                for name, info in models.items() if name != selected_model
            ],
            "selection_timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Model selected: {selected_model} for complexity {query_complexity:.2f}")
        return result
        
    except Exception as e:
        logger.error(f"Model selection failed: {e}")
        return {
            "error": str(e),
            "model_selection": None,
            "query": query
        }

def calculate_query_complexity(query: str) -> float:
    """Calculate query complexity score (0-1)"""
    try:
        query_upper = query.upper()
        
        # Base complexity factors
        complexity = 0.0
        
        # Length factor
        if len(query) > 1000:
            complexity += 0.3
        elif len(query) > 500:
            complexity += 0.2
        elif len(query) > 200:
            complexity += 0.1
        
        # JOIN complexity
        join_count = query_upper.count('JOIN')
        complexity += min(join_count * 0.1, 0.3)
        
        # Subquery complexity
        subquery_count = query_upper.count('SELECT') - 1
        complexity += min(subquery_count * 0.15, 0.3)
        
        # Aggregation complexity
        agg_count = sum(query_upper.count(agg) for agg in ['COUNT', 'SUM', 'AVG', 'MAX', 'MIN', 'GROUP BY'])
        complexity += min(agg_count * 0.05, 0.2)
        
        # Window functions
        window_count = query_upper.count('OVER')
        complexity += min(window_count * 0.1, 0.2)
        
        # CTEs
        cte_count = query_upper.count('WITH')
        complexity += min(cte_count * 0.1, 0.2)
        
        # Normalize to 0-1 range
        return min(complexity, 1.0)
        
    except Exception:
        return 0.5  # Default medium complexity
