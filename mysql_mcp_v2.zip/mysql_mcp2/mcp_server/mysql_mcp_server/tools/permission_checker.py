"""
Permission Checker Tool
Enforces read-only and access policies
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class PermissionResult(BaseModel):
    """Permission check result model"""
    allowed: bool
    permission_type: str  # "read", "write", "admin"
    resource: str
    user_id: Optional[str]
    reason: str
    restrictions: List[str]
    timestamp: datetime

@tool
async def permission_checker(
    query: str,
    user_id: Optional[str] = None,
    permission_type: str = "read",
    enforce_read_only: bool = True
) -> Dict[str, Any]:
    """
    Enforces read-only and access policies for database operations.
    
    Args:
        query: SQL query to check permissions for
        user_id: User ID requesting access
        permission_type: Type of permission (read, write, admin)
        enforce_read_only: Whether to enforce read-only mode
        
    Returns:
        Dict containing permission check results
    """
    try:
        logger.info(f"Checking permissions for {permission_type} operation")
        
        query_upper = query.upper().strip()
        
        # Check for dangerous operations
        dangerous_operations = [
            'DROP', 'TRUNCATE', 'DELETE', 'ALTER', 'CREATE', 'GRANT', 'REVOKE',
            'EXEC', 'EXECUTE', 'CALL', 'INSERT', 'UPDATE', 'REPLACE'
        ]
        
        # Check if query contains dangerous operations
        contains_dangerous = any(op in query_upper for op in dangerous_operations)
        
        # Determine if operation is allowed
        allowed = True
        reason = "Operation allowed"
        restrictions = []
        
        if enforce_read_only and contains_dangerous:
            allowed = False
            reason = "Read-only mode enforced - write operations not allowed"
            restrictions.append("Write operations disabled")
        
        # Check user permissions (simplified)
        if user_id:
            # In production, this would check against user permissions
            if permission_type == "admin" and not user_id.startswith("admin_"):
                allowed = False
                reason = "Admin permissions required"
                restrictions.append("Insufficient privileges")
            elif permission_type == "write" and not user_id.startswith("write_"):
                allowed = False
                reason = "Write permissions required"
                restrictions.append("Insufficient privileges")
        
        # Check for specific table access
        if allowed:
            # Extract table names from query
            table_names = []
            if 'FROM' in query_upper:
                from_pos = query_upper.find('FROM')
                from_clause = query[from_pos:].split()[1]
                if 'WHERE' in from_clause:
                    from_clause = from_clause.split('WHERE')[0]
                table_names.append(from_clause.strip())
            
            if 'JOIN' in query_upper:
                # Extract JOIN tables
                join_pos = query_upper.find('JOIN')
                join_clause = query[join_pos:].split()[1]
                if 'ON' in join_clause:
                    join_clause = join_clause.split('ON')[0]
                table_names.append(join_clause.strip())
            
            # Check table access permissions
            for table in table_names:
                if table.startswith('admin_') and permission_type != "admin":
                    allowed = False
                    reason = f"Admin table '{table}' requires admin permissions"
                    restrictions.append(f"Table '{table}' access denied")
                    break
                elif table.startswith('write_') and permission_type == "read":
                    allowed = False
                    reason = f"Write table '{table}' requires write permissions"
                    restrictions.append(f"Table '{table}' access denied")
                    break
        
        # Check query complexity
        if allowed:
            # Count JOINs, subqueries, etc.
            join_count = query_upper.count('JOIN')
            subquery_count = query_upper.count('SELECT') - 1
            
            if join_count > 5:
                restrictions.append("Query complexity limit exceeded")
                if permission_type == "read":
                    allowed = False
                    reason = "Query too complex for read permissions"
            
            if subquery_count > 3:
                restrictions.append("Subquery limit exceeded")
                if permission_type == "read":
                    allowed = False
                    reason = "Query too complex for read permissions"
        
        # Check for data access patterns
        if allowed and 'LIMIT' not in query_upper:
            restrictions.append("Consider adding LIMIT clause for large result sets")
        
        # Create permission result
        permission_result = PermissionResult(
            allowed=allowed,
            permission_type=permission_type,
            resource=query,
            user_id=user_id,
            reason=reason,
            restrictions=restrictions,
            timestamp=datetime.now()
        )
        
        result = {
            "permission_check": permission_result.dict(),
            "query": query,
            "user_id": user_id,
            "permission_type": permission_type,
            "enforce_read_only": enforce_read_only,
            "timestamp": datetime.now().isoformat()
        }
        
        if allowed:
            logger.info(f"Permission granted for {permission_type} operation")
        else:
            logger.warning(f"Permission denied for {permission_type} operation: {reason}")
        
        return result
        
    except Exception as e:
        logger.error(f"Permission check failed: {e}")
        return {
            "error": str(e),
            "permission_check": {
                "allowed": False,
                "reason": f"Permission check failed: {str(e)}",
                "restrictions": ["System error"]
            },
            "query": query,
            "user_id": user_id
        }
