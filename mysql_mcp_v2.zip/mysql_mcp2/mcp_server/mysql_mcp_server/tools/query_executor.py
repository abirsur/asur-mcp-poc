"""
Query Executor Tool
Executes SQL queries asynchronously with pagination
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Union
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager, QueryResult

logger = logging.getLogger(__name__)

class ExecutionOptions(BaseModel):
    """Query execution options"""
    timeout: int = Field(default=30, description="Query timeout in seconds")
    max_rows: int = Field(default=1000, description="Maximum rows to return")
    page_size: int = Field(default=100, description="Page size for pagination")
    page: int = Field(default=1, description="Page number (1-based)")
    explain: bool = Field(default=False, description="Include EXPLAIN output")

@tool
async def query_executor(
    query: str,
    params: Optional[Dict[str, Any]] = None,
    options: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Executes SQL queries asynchronously with pagination and timeout management.
    
    Args:
        query: SQL query to execute
        params: Query parameters for prepared statements
        options: Execution options (timeout, max_rows, page_size, etc.)
        
    Returns:
        Dict containing query results with metadata
    """
    try:
        logger.info(f"Executing query: {query[:100]}...")
        
        # Parse options
        exec_options = ExecutionOptions()
        if options:
            for key, value in options.items():
                if hasattr(exec_options, key):
                    setattr(exec_options, key, value)
        
        # Sanitize query (basic check)
        query_upper = query.upper().strip()
        if any(dangerous in query_upper for dangerous in ['DROP', 'DELETE', 'TRUNCATE', 'ALTER']):
            logger.warning(f"Potentially dangerous query detected: {query}")
        
        # Execute query with timeout
        try:
            result = await asyncio.wait_for(
                db_manager.execute_query(query, params),
                timeout=exec_options.timeout
            )
        except asyncio.TimeoutError:
            logger.error(f"Query timeout after {exec_options.timeout} seconds")
            return {
                "error": f"Query timeout after {exec_options.timeout} seconds",
                "query": query,
                "execution_time": exec_options.timeout
            }
        
        # Apply pagination if needed
        if exec_options.max_rows and len(result.rows) > exec_options.max_rows:
            start_idx = (exec_options.page - 1) * exec_options.page_size
            end_idx = start_idx + exec_options.page_size
            paginated_rows = result.rows[start_idx:end_idx]
            
            pagination_info = {
                "total_rows": len(result.rows),
                "returned_rows": len(paginated_rows),
                "page": exec_options.page,
                "page_size": exec_options.page_size,
                "total_pages": (len(result.rows) + exec_options.page_size - 1) // exec_options.page_size,
                "has_next": end_idx < len(result.rows),
                "has_previous": exec_options.page > 1
            }
        else:
            paginated_rows = result.rows
            pagination_info = {
                "total_rows": len(result.rows),
                "returned_rows": len(result.rows),
                "page": 1,
                "page_size": len(result.rows),
                "total_pages": 1,
                "has_next": False,
                "has_previous": False
            }
        
        # Get EXPLAIN output if requested
        explain_output = None
        if exec_options.explain and query_upper.startswith('SELECT'):
            try:
                explain_result = await db_manager.execute_query(f"EXPLAIN {query}", params)
                explain_output = explain_result.rows
            except Exception as e:
                logger.warning(f"Could not get EXPLAIN output: {e}")
        
        # Format result
        response = {
            "status": "success",
            "query": query,
            "rows": paginated_rows,
            "count": len(paginated_rows),
            "execution_time": result.execution_time,
            "timestamp": result.timestamp.isoformat(),
            "pagination": pagination_info,
            "metadata": {
                "query_type": query_upper.split()[0] if query_upper else "UNKNOWN",
                "execution_time_ms": round(result.execution_time * 1000, 2),
                "rows_affected": result.count
            }
        }
        
        if explain_output:
            response["explain"] = explain_output
        
        logger.info(f"Query executed successfully in {result.execution_time:.3f}s")
        return response
        
    except Exception as e:
        logger.error(f"Query execution failed: {e}")
        return {
            "status": "error",
            "error": str(e),
            "query": query,
            "execution_time": 0,
            "rows": [],
            "count": 0
        }
