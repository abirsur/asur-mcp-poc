"""
Natural Language Query Interpreter Tool
Converts natural language queries into structured intent
"""

import logging
import re
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class QueryIntent(BaseModel):
    """Structured query intent model"""
    action: str = Field(description="The main action (SELECT, INSERT, UPDATE, DELETE)")
    tables: List[str] = Field(description="Tables involved in the query")
    columns: List[str] = Field(description="Columns to select or modify")
    conditions: List[Dict[str, Any]] = Field(description="WHERE conditions")
    joins: List[Dict[str, str]] = Field(description="JOIN relationships")
    aggregations: List[str] = Field(description="Aggregation functions (COUNT, SUM, etc.)")
    ordering: Optional[Dict[str, str]] = Field(description="ORDER BY clause")
    grouping: List[str] = Field(description="GROUP BY columns")
    limit: Optional[int] = Field(description="LIMIT clause")
    confidence: float = Field(description="Confidence score (0-1)")

@tool
async def nl_query_interpreter(query: str) -> Dict[str, Any]:
    """
    Converts natural language database queries into structured intent.
    
    Args:
        query: Natural language query (e.g., "Show me all users from California")
        
    Returns:
        Dict containing structured query intent with action, tables, columns, etc.
    """
    try:
        logger.info(f"Interpreting NL query: {query}")
        
        # Initialize intent with defaults
        intent = QueryIntent(
            action="SELECT",
            tables=[],
            columns=[],
            conditions=[],
            joins=[],
            aggregations=[],
            ordering=None,
            grouping=[],
            limit=None,
            confidence=0.0
        )
        
        # Get schema information
        schema_info = db_manager.get_schema_info()
        if not schema_info:
            await db_manager.refresh_schema_cache()
            schema_info = db_manager.get_schema_info()
        
        # Simple pattern matching for common queries
        query_lower = query.lower()
        
        # Detect action type
        if any(word in query_lower for word in ['show', 'list', 'get', 'find', 'search', 'display']):
            intent.action = "SELECT"
            intent.confidence += 0.3
        elif any(word in query_lower for word in ['insert', 'add', 'create', 'new']):
            intent.action = "INSERT"
            intent.confidence += 0.3
        elif any(word in query_lower for word in ['update', 'modify', 'change', 'edit']):
            intent.action = "UPDATE"
            intent.confidence += 0.3
        elif any(word in query_lower for word in ['delete', 'remove', 'drop']):
            intent.action = "DELETE"
            intent.confidence += 0.3
        
        # Extract table names using schema information
        if schema_info:
            for table_name in schema_info.tables.keys():
                if table_name.lower() in query_lower or f"{table_name}s".lower() in query_lower:
                    intent.tables.append(table_name)
                    intent.confidence += 0.2
        
        # Extract column names
        column_patterns = [
            r'\b(\w+)\s+(?:from|in|where)\b',
            r'\b(?:select|show)\s+(\w+)',
            r'\b(\w+)\s*=\s*["\']',
        ]
        
        for pattern in column_patterns:
            matches = re.findall(pattern, query_lower)
            for match in matches:
                if match not in intent.columns:
                    intent.columns.append(match)
        
        # Extract conditions
        condition_patterns = [
            r'(\w+)\s*=\s*["\']([^"\']+)["\']',
            r'(\w+)\s*>\s*(\d+)',
            r'(\w+)\s*<\s*(\d+)',
            r'(\w+)\s*like\s*["\']([^"\']+)["\']',
        ]
        
        for pattern in condition_patterns:
            matches = re.findall(pattern, query_lower)
            for match in matches:
                intent.conditions.append({
                    'column': match[0],
                    'operator': '=' if '=' in pattern else '>' if '>' in pattern else '<' if '<' in pattern else 'LIKE',
                    'value': match[1]
                })
        
        # Extract aggregations
        agg_patterns = [
            r'\bcount\b',
            r'\bsum\b',
            r'\bavg\b',
            r'\bmax\b',
            r'\bmin\b'
        ]
        
        for pattern in agg_patterns:
            if re.search(pattern, query_lower):
                intent.aggregations.append(pattern.replace('\\b', '').replace('\\', ''))
        
        # Extract ordering
        order_match = re.search(r'order\s+by\s+(\w+)\s+(asc|desc)?', query_lower)
        if order_match:
            intent.ordering = {
                'column': order_match.group(1),
                'direction': order_match.group(2) or 'ASC'
            }
        
        # Extract limit
        limit_match = re.search(r'limit\s+(\d+)', query_lower)
        if limit_match:
            intent.limit = int(limit_match.group(1))
        
        # Normalize confidence
        intent.confidence = min(intent.confidence, 1.0)
        
        result = {
            "intent": intent.dict(),
            "original_query": query,
            "interpretation_confidence": intent.confidence,
            "suggested_tables": intent.tables,
            "suggested_columns": intent.columns
        }
        
        logger.info(f"Query interpreted with confidence: {intent.confidence}")
        return result
        
    except Exception as e:
        logger.error(f"Failed to interpret NL query: {e}")
        return {
            "error": str(e),
            "intent": None,
            "original_query": query,
            "interpretation_confidence": 0.0
        }
