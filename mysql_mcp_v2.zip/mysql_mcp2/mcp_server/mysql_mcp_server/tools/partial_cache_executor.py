"""
Partial Cache Executor Tool
Streams large query results with partial caching
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, AsyncGenerator
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class PartialCacheConfig(BaseModel):
    """Partial cache configuration model"""
    chunk_size: int = Field(default=100, description="Number of rows per chunk")
    max_chunks: int = Field(default=10, description="Maximum number of chunks to cache")
    cache_ttl: int = Field(default=3600, description="Cache TTL in seconds")
    enable_streaming: bool = Field(default=True, description="Enable streaming results")

@tool
async def partial_cache_executor(
    query: str,
    chunk_size: int = 100,
    max_chunks: int = 10,
    cache_ttl: int = 3600,
    enable_streaming: bool = True
) -> Dict[str, Any]:
    """
    Streams large query results with partial caching for better memory management.
    
    Args:
        query: SQL query to execute
        chunk_size: Number of rows per chunk
        max_chunks: Maximum number of chunks to cache
        cache_ttl: Cache TTL in seconds
        enable_streaming: Whether to enable streaming results
        
    Returns:
        Dict containing streaming results and cache information
    """
    try:
        logger.info(f"Executing query with partial caching: {chunk_size} rows per chunk")
        
        # Add LIMIT to query if not present
        if 'LIMIT' not in query.upper():
            query_with_limit = f"{query} LIMIT {chunk_size * max_chunks}"
        else:
            query_with_limit = query
        
        # Execute query
        start_time = datetime.now()
        result = await db_manager.execute_query(query_with_limit)
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # Split results into chunks
        all_rows = result.rows
        total_rows = len(all_rows)
        chunks = []
        
        for i in range(0, total_rows, chunk_size):
            chunk = all_rows[i:i + chunk_size]
            chunks.append({
                "chunk_id": i // chunk_size,
                "rows": chunk,
                "row_count": len(chunk),
                "start_index": i,
                "end_index": min(i + chunk_size - 1, total_rows - 1)
            })
        
        # Cache chunks if enabled
        cached_chunks = 0
        if enable_streaming:
            for chunk in chunks:
                cache_key = f"query_chunk_{hash(query)}_{chunk['chunk_id']}"
                try:
                    await db_manager.cache.set(cache_key, chunk, ttl=cache_ttl)
                    cached_chunks += 1
                except Exception as e:
                    logger.warning(f"Failed to cache chunk {chunk['chunk_id']}: {e}")
        
        # Generate streaming response
        streaming_response = {
            "query": query,
            "total_rows": total_rows,
            "chunk_size": chunk_size,
            "total_chunks": len(chunks),
            "cached_chunks": cached_chunks,
            "execution_time": execution_time,
            "streaming_enabled": enable_streaming,
            "cache_ttl": cache_ttl,
            "chunks": chunks,
            "metadata": {
                "query_hash": hash(query),
                "timestamp": start_time.isoformat(),
                "memory_efficient": True,
                "cache_status": "enabled" if enable_streaming else "disabled"
            }
        }
        
        logger.info(f"Partial cache execution completed: {len(chunks)} chunks, {cached_chunks} cached")
        return streaming_response
        
    except Exception as e:
        logger.error(f"Partial cache execution failed: {e}")
        return {
            "error": str(e),
            "query": query,
            "total_rows": 0,
            "chunks": [],
            "cached_chunks": 0,
            "execution_time": 0.0
        }

@tool
async def get_cached_chunk(
    query_hash: int,
    chunk_id: int
) -> Dict[str, Any]:
    """
    Retrieves a cached chunk by query hash and chunk ID.
    
    Args:
        query_hash: Hash of the original query
        chunk_id: ID of the chunk to retrieve
        
    Returns:
        Dict containing cached chunk data
    """
    try:
        cache_key = f"query_chunk_{query_hash}_{chunk_id}"
        cached_chunk = await db_manager.cache.get(cache_key)
        
        if cached_chunk:
            return {
                "chunk_id": chunk_id,
                "query_hash": query_hash,
                "cached": True,
                "chunk_data": cached_chunk,
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {
                "chunk_id": chunk_id,
                "query_hash": query_hash,
                "cached": False,
                "chunk_data": None,
                "error": "Chunk not found in cache"
            }
            
    except Exception as e:
        logger.error(f"Failed to retrieve cached chunk: {e}")
        return {
            "error": str(e),
            "chunk_id": chunk_id,
            "query_hash": query_hash,
            "cached": False
        }
