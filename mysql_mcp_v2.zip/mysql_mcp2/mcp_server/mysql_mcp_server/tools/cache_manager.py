"""
Cache Manager Tool
Caches schema, results, and embeddings
"""

import logging
import time
from typing import Dict, List, Any, Optional, Union
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class CacheEntry(BaseModel):
    """Cache entry model"""
    key: str
    value: Any
    timestamp: float
    ttl: int
    hit_count: int = 0

@tool
async def cache_manager(
    action: str,
    key: Optional[str] = None,
    value: Optional[Any] = None,
    ttl: int = 3600
) -> Dict[str, Any]:
    """
    Manages caching for schema, results, and embeddings.
    
    Args:
        action: Cache action ("get", "set", "delete", "clear", "stats", "list")
        key: Cache key
        value: Value to cache
        ttl: Time to live in seconds
        
    Returns:
        Dict containing cache operation results
    """
    try:
        logger.info(f"Cache manager action: {action}")
        
        if action == "get":
            if not key:
                return {"error": "Key required for get operation"}
            
            # Try to get from cache
            try:
                cached_value = await db_manager.cache.get(key)
                if cached_value:
                    # Update hit count
                    db_manager.metrics["cache_hits"] += 1
                    return {
                        "action": "get",
                        "key": key,
                        "value": cached_value,
                        "found": True,
                        "hit_count": db_manager.metrics["cache_hits"]
                    }
                else:
                    db_manager.metrics["cache_misses"] += 1
                    return {
                        "action": "get",
                        "key": key,
                        "value": None,
                        "found": False,
                        "hit_count": db_manager.metrics["cache_hits"]
                    }
            except Exception as e:
                db_manager.metrics["cache_misses"] += 1
                return {
                    "action": "get",
                    "key": key,
                    "value": None,
                    "found": False,
                    "error": str(e)
                }
        
        elif action == "set":
            if not key or value is None:
                return {"error": "Key and value required for set operation"}
            
            try:
                await db_manager.cache.set(key, value, ttl=ttl)
                return {
                    "action": "set",
                    "key": key,
                    "value": value,
                    "ttl": ttl,
                    "success": True
                }
            except Exception as e:
                return {
                    "action": "set",
                    "key": key,
                    "value": value,
                    "success": False,
                    "error": str(e)
                }
        
        elif action == "delete":
            if not key:
                return {"error": "Key required for delete operation"}
            
            try:
                await db_manager.cache.delete(key)
                return {
                    "action": "delete",
                    "key": key,
                    "success": True
                }
            except Exception as e:
                return {
                    "action": "delete",
                    "key": key,
                    "success": False,
                    "error": str(e)
                }
        
        elif action == "clear":
            try:
                await db_manager.clear_cache()
                return {
                    "action": "clear",
                    "success": True,
                    "message": "All caches cleared"
                }
            except Exception as e:
                return {
                    "action": "clear",
                    "success": False,
                    "error": str(e)
                }
        
        elif action == "stats":
            # Get cache statistics
            metrics = db_manager.get_metrics()
            cache_stats = {
                "cache_hits": metrics.get("cache_hits", 0),
                "cache_misses": metrics.get("cache_misses", 0),
                "hit_rate": metrics.get("cache_hits", 0) / max(metrics.get("cache_hits", 0) + metrics.get("cache_misses", 0), 1),
                "total_queries": metrics.get("total_queries", 0),
                "successful_queries": metrics.get("successful_queries", 0),
                "failed_queries": metrics.get("failed_queries", 0),
                "average_execution_time": metrics.get("average_execution_time", 0.0)
            }
            
            return {
                "action": "stats",
                "cache_statistics": cache_stats,
                "schema_cache": {
                    "available": db_manager.schema_cache is not None,
                    "last_updated": str(db_manager.schema_cache.last_updated) if db_manager.schema_cache else None,
                    "tables_count": len(db_manager.schema_cache.tables) if db_manager.schema_cache else 0
                },
                "embedding_cache": {
                    "available": db_manager.embedding_index is not None,
                    "vectors_count": len(db_manager.embedding_vectors) if db_manager.embedding_vectors else 0
                }
            }
        
        elif action == "list":
            # List cache keys (this is a simplified implementation)
            try:
                # Get some common cache keys
                common_keys = [
                    "schema_cache",
                    "embedding_index",
                    "query_results",
                    "table_metadata"
                ]
                
                available_keys = []
                for key in common_keys:
                    try:
                        value = await db_manager.cache.get(key)
                        if value:
                            available_keys.append(key)
                    except:
                        pass
                
                return {
                    "action": "list",
                    "available_keys": available_keys,
                    "total_keys": len(available_keys)
                }
            except Exception as e:
                return {
                    "action": "list",
                    "available_keys": [],
                    "total_keys": 0,
                    "error": str(e)
                }
        
        else:
            return {
                "error": f"Invalid action: {action}",
                "available_actions": ["get", "set", "delete", "clear", "stats", "list"]
            }
        
    except Exception as e:
        logger.error(f"Cache manager failed: {e}")
        return {
            "error": str(e),
            "action": action
        }
