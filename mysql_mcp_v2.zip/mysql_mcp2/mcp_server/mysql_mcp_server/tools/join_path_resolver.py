"""
Join Path Resolver Tool
Determines join paths based on relationships
"""

import logging
from typing import Dict, List, Any, Optional, Tuple
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class JoinPath(BaseModel):
    """Join path model"""
    table1: str
    table2: str
    join_type: str  # "INNER", "LEFT", "RIGHT", "FULL"
    join_condition: str
    confidence: float

@tool
async def join_path_resolver(
    tables: List[str],
    join_type_preference: str = "INNER"
) -> Dict[str, Any]:
    """
    Determines join paths based on database relationships.
    
    Args:
        tables: List of tables to join
        join_type_preference: Preferred join type (INNER, LEFT, RIGHT, FULL)
        
    Returns:
        Dict containing join paths and relationships
    """
    try:
        logger.info(f"Resolving join paths for {len(tables)} tables")
        
        # Get schema information
        schema_info = db_manager.get_schema_info()
        if not schema_info:
            await db_manager.refresh_schema_cache()
            schema_info = db_manager.get_schema_info()
        
        if not schema_info:
            return {"error": "No schema information available"}
        
        if len(tables) < 2:
            return {
                "join_paths": [],
                "message": "At least 2 tables required for joins"
            }
        
        join_paths = []
        relationships = schema_info.relationships
        
        # Find direct relationships
        for i, table1 in enumerate(tables):
            for j, table2 in enumerate(tables[i+1:], i+1):
                # Check if table1 references table2
                if table1 in relationships:
                    for rel in relationships[table1]:
                        if rel['referenced_table'] == table2:
                            join_path = JoinPath(
                                table1=table1,
                                table2=table2,
                                join_type=join_type_preference,
                                join_condition=f"{table1}.{rel['column']} = {table2}.{rel['referenced_column']}",
                                confidence=1.0
                            )
                            join_paths.append(join_path)
                
                # Check if table2 references table1
                if table2 in relationships:
                    for rel in relationships[table2]:
                        if rel['referenced_table'] == table1:
                            join_path = JoinPath(
                                table1=table1,
                                table2=table2,
                                join_type=join_type_preference,
                                join_condition=f"{table2}.{rel['column']} = {table1}.{rel['referenced_column']}",
                                confidence=1.0
                            )
                            join_paths.append(join_path)
                
                # Check for common column names (heuristic)
                table1_columns = [col['COLUMN_NAME'] for col in schema_info.tables[table1]['columns']]
                table2_columns = [col['COLUMN_NAME'] for col in schema_info.tables[table2]['columns']]
                
                common_columns = set(table1_columns) & set(table2_columns)
                for col in common_columns:
                    # Check if it's likely a foreign key (common patterns)
                    if any(pattern in col.lower() for pattern in ['id', 'key', 'ref']):
                        join_path = JoinPath(
                            table1=table1,
                            table2=table2,
                            join_type=join_type_preference,
                            join_condition=f"{table1}.{col} = {table2}.{col}",
                            confidence=0.7
                        )
                        join_paths.append(join_path)
        
        # Find indirect relationships through intermediate tables
        for table1 in tables:
            for table2 in tables:
                if table1 != table2:
                    # Check if there's a path through another table
                    for intermediate_table in schema_info.tables.keys():
                        if intermediate_table not in tables:
                            # Check table1 -> intermediate -> table2
                            if (table1 in relationships and 
                                any(rel['referenced_table'] == intermediate_table for rel in relationships[table1])):
                                if (intermediate_table in relationships and 
                                    any(rel['referenced_table'] == table2 for rel in relationships[intermediate_table])):
                                    
                                    # Get the actual relationships
                                    rel1 = next(rel for rel in relationships[table1] if rel['referenced_table'] == intermediate_table)
                                    rel2 = next(rel for rel in relationships[intermediate_table] if rel['referenced_table'] == table2)
                                    
                                    join_path = JoinPath(
                                        table1=table1,
                                        table2=table2,
                                        join_type=join_type_preference,
                                        join_condition=f"{table1}.{rel1['column']} = {intermediate_table}.{rel1['referenced_column']} AND {intermediate_table}.{rel2['column']} = {table2}.{rel2['referenced_column']}",
                                        confidence=0.8
                                    )
                                    join_paths.append(join_path)
        
        # Remove duplicate join paths
        unique_paths = []
        seen_paths = set()
        for path in join_paths:
            path_key = tuple(sorted([path.table1, path.table2]))
            if path_key not in seen_paths:
                unique_paths.append(path)
                seen_paths.add(path_key)
        
        # Sort by confidence
        unique_paths.sort(key=lambda x: x.confidence, reverse=True)
        
        result = {
            "join_paths": [path.dict() for path in unique_paths],
            "total_paths": len(unique_paths),
            "tables": tables,
            "join_type_preference": join_type_preference,
            "analysis": {
                "direct_relationships": len([p for p in unique_paths if p['confidence'] == 1.0]),
                "heuristic_relationships": len([p for p in unique_paths if p['confidence'] == 0.7]),
                "indirect_relationships": len([p for p in unique_paths if p['confidence'] == 0.8])
            }
        }
        
        logger.info(f"Found {len(unique_paths)} join paths")
        return result
        
    except Exception as e:
        logger.error(f"Join path resolution failed: {e}")
        return {
            "error": str(e),
            "join_paths": [],
            "total_paths": 0
        }
