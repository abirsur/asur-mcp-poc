"""
Synonym Mapper Tool
Maps user terms to database schema synonyms
"""

import logging
import re
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class SynonymMapping(BaseModel):
    """Synonym mapping model"""
    user_term: str
    schema_term: str
    confidence: float
    mapping_type: str  # "exact", "partial", "semantic"

@tool
async def synonym_mapper(
    user_terms: List[str],
    include_partial_matches: bool = True,
    min_confidence: float = 0.5
) -> Dict[str, Any]:
    """
    Maps user terms to database schema synonyms.
    
    Args:
        user_terms: List of user terms to map
        include_partial_matches: Whether to include partial matches
        min_confidence: Minimum confidence threshold for mappings
        
    Returns:
        Dict containing synonym mappings
    """
    try:
        logger.info(f"Mapping {len(user_terms)} user terms to schema")
        
        # Get schema information
        schema_info = db_manager.get_schema_info()
        if not schema_info:
            await db_manager.refresh_schema_cache()
            schema_info = db_manager.get_schema_info()
        
        if not schema_info:
            return {"error": "No schema information available"}
        
        # Extract all schema terms
        schema_terms = []
        for table_name, table_info in schema_info.tables.items():
            schema_terms.append(table_name)
            for column in table_info['columns']:
                schema_terms.append(f"{table_name}.{column['COLUMN_NAME']}")
                schema_terms.append(column['COLUMN_NAME'])
        
        mappings = []
        
        for user_term in user_terms:
            user_term_lower = user_term.lower()
            
            # Exact matches
            for schema_term in schema_terms:
                if user_term_lower == schema_term.lower():
                    mappings.append(SynonymMapping(
                        user_term=user_term,
                        schema_term=schema_term,
                        confidence=1.0,
                        mapping_type="exact"
                    ))
            
            # Partial matches
            if include_partial_matches:
                for schema_term in schema_terms:
                    schema_term_lower = schema_term.lower()
                    
                    # Check if user term is contained in schema term
                    if user_term_lower in schema_term_lower:
                        confidence = len(user_term_lower) / len(schema_term_lower)
                        if confidence >= min_confidence:
                            mappings.append(SynonymMapping(
                                user_term=user_term,
                                schema_term=schema_term,
                                confidence=confidence,
                                mapping_type="partial"
                            ))
                    
                    # Check if schema term is contained in user term
                    elif schema_term_lower in user_term_lower:
                        confidence = len(schema_term_lower) / len(user_term_lower)
                        if confidence >= min_confidence:
                            mappings.append(SynonymMapping(
                                user_term=user_term,
                                schema_term=schema_term,
                                confidence=confidence,
                                mapping_type="partial"
                            ))
            
            # Fuzzy matching for common variations
            fuzzy_patterns = [
                (r's$', ''),  # Remove plural 's'
                (r'ies$', 'y'),  # Change 'ies' to 'y'
                (r'ing$', ''),  # Remove 'ing'
                (r'ed$', ''),  # Remove 'ed'
            ]
            
            for pattern, replacement in fuzzy_patterns:
                modified_term = re.sub(pattern, replacement, user_term_lower)
                if modified_term != user_term_lower:
                    for schema_term in schema_terms:
                        if modified_term == schema_term.lower():
                            mappings.append(SynonymMapping(
                                user_term=user_term,
                                schema_term=schema_term,
                                confidence=0.8,
                                mapping_type="semantic"
                            ))
        
        # Remove duplicates and sort by confidence
        unique_mappings = {}
        for mapping in mappings:
            key = (mapping.user_term, mapping.schema_term)
            if key not in unique_mappings or mapping.confidence > unique_mappings[key].confidence:
                unique_mappings[key] = mapping
        
        final_mappings = list(unique_mappings.values())
        final_mappings.sort(key=lambda x: x.confidence, reverse=True)
        
        # Group by user term
        grouped_mappings = {}
        for mapping in final_mappings:
            if mapping.user_term not in grouped_mappings:
                grouped_mappings[mapping.user_term] = []
            grouped_mappings[mapping.user_term].append(mapping.dict())
        
        result = {
            "mappings": grouped_mappings,
            "total_mappings": len(final_mappings),
            "user_terms": user_terms,
            "schema_terms_count": len(schema_terms),
            "mapping_summary": {
                "exact_matches": len([m for m in final_mappings if m.mapping_type == "exact"]),
                "partial_matches": len([m for m in final_mappings if m.mapping_type == "partial"]),
                "semantic_matches": len([m for m in final_mappings if m.mapping_type == "semantic"])
            }
        }
        
        logger.info(f"Found {len(final_mappings)} synonym mappings")
        return result
        
    except Exception as e:
        logger.error(f"Synonym mapping failed: {e}")
        return {
            "error": str(e),
            "mappings": {},
            "total_mappings": 0
        }
