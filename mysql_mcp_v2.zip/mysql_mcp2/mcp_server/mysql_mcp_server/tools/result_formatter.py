"""
Result Formatter Tool
Formats query results into JSON/tabular output
"""

import logging
import json
from typing import Dict, List, Any, Optional, Union
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime

logger = logging.getLogger(__name__)

class FormatOptions(BaseModel):
    """Result formatting options"""
    format_type: str = Field(default="json", description="Output format (json, table, csv)")
    include_metadata: bool = Field(default=True, description="Include execution metadata")
    max_cell_length: int = Field(default=100, description="Maximum cell content length")
    pretty_print: bool = Field(default=True, description="Pretty print JSON output")

@tool
def result_formatter(
    rows: List[Dict[str, Any]],
    count: int,
    execution_time: float,
    query: str,
    format_type: str = "json",
    include_metadata: bool = True,
    max_cell_length: int = 100,
    pretty_print: bool = True
) -> Dict[str, Any]:
    """
    Formats query results into JSON/tabular output with metadata.
    
    Args:
        rows: Query result rows
        count: Number of rows
        execution_time: Query execution time in seconds
        query: Original SQL query
        format_type: Output format (json, table, csv)
        include_metadata: Whether to include execution metadata
        max_cell_length: Maximum cell content length
        pretty_print: Whether to pretty print JSON
        
    Returns:
        Dict containing formatted results with metadata
    """
    try:
        logger.info(f"Formatting {count} rows in {format_type} format")
        
        # Truncate long cell values
        formatted_rows = []
        for row in rows:
            formatted_row = {}
            for key, value in row.items():
                if isinstance(value, str) and len(value) > max_cell_length:
                    formatted_row[key] = value[:max_cell_length] + "..."
                else:
                    formatted_row[key] = value
            formatted_rows.append(formatted_row)
        
        # Format based on type
        if format_type.lower() == "json":
            if pretty_print:
                formatted_data = json.dumps(formatted_rows, indent=2, default=str)
            else:
                formatted_data = json.dumps(formatted_rows, default=str)
            
            result = {
                "format": "json",
                "data": formatted_data,
                "rows": formatted_rows
            }
        
        elif format_type.lower() == "table":
            # Create table format
            if not formatted_rows:
                table_data = "No rows returned"
            else:
                # Get column names
                columns = list(formatted_rows[0].keys()) if formatted_rows else []
                
                # Create table header
                header = " | ".join(f"{col:^15}" for col in columns)
                separator = "-" * len(header)
                
                # Create table rows
                table_rows = [header, separator]
                for row in formatted_rows:
                    row_str = " | ".join(f"{str(row.get(col, '')):^15}" for col in columns)
                    table_rows.append(row_str)
                
                table_data = "\n".join(table_rows)
            
            result = {
                "format": "table",
                "data": table_data,
                "rows": formatted_rows
            }
        
        elif format_type.lower() == "csv":
            if not formatted_rows:
                csv_data = ""
            else:
                # Get column names
                columns = list(formatted_rows[0].keys()) if formatted_rows else []
                
                # Create CSV header
                csv_lines = [",".join(columns)]
                
                # Create CSV rows
                for row in formatted_rows:
                    csv_row = []
                    for col in columns:
                        value = str(row.get(col, ""))
                        # Escape quotes and wrap in quotes if contains comma
                        if "," in value or '"' in value:
                            value = f'"{value.replace('"', '""')}"'
                        csv_row.append(value)
                    csv_lines.append(",".join(csv_row))
                
                csv_data = "\n".join(csv_lines)
            
            result = {
                "format": "csv",
                "data": csv_data,
                "rows": formatted_rows
            }
        
        else:
            return {
                "error": f"Unsupported format type: {format_type}",
                "supported_formats": ["json", "table", "csv"]
            }
        
        # Add metadata if requested
        if include_metadata:
            result["metadata"] = {
                "query": query,
                "count": count,
                "execution_time": execution_time,
                "execution_time_ms": round(execution_time * 1000, 2),
                "timestamp": datetime.now().isoformat(),
                "format_type": format_type,
                "max_cell_length": max_cell_length
            }
        
        logger.info(f"Results formatted as {format_type}")
        return result
        
    except Exception as e:
        logger.error(f"Result formatting failed: {e}")
        return {
            "error": str(e),
            "format": format_type,
            "data": None,
            "rows": rows,
            "count": count
        }
