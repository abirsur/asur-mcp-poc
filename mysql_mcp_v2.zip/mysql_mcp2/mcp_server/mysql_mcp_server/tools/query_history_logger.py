"""
Query History Logger Tool
Logs all executed queries and their metadata
"""

import logging
import json
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class QueryLogEntry(BaseModel):
    """Query log entry model"""
    query: str
    execution_time: float
    timestamp: datetime
    success: bool
    result_count: int
    error_message: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    query_hash: int
    metadata: Dict[str, Any] = Field(default_factory=dict)

@tool
async def query_history_logger(
    action: str = "log",
    query: Optional[str] = None,
    execution_time: Optional[float] = None,
    success: bool = True,
    result_count: int = 0,
    error_message: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Logs all executed queries and their metadata for analysis and auditing.
    
    Args:
        action: Action to perform (log, get, search, stats)
        query: SQL query to log
        execution_time: Query execution time in seconds
        success: Whether query was successful
        result_count: Number of rows returned
        error_message: Error message if query failed
        user_id: User ID who executed the query
        session_id: Session ID
        metadata: Additional metadata
        
    Returns:
        Dict containing logging results or query history
    """
    try:
        logger.info(f"Query history logger action: {action}")
        
        if action == "log":
            if not query:
                return {"error": "Query required for logging"}
            
            # Create log entry
            log_entry = QueryLogEntry(
                query=query,
                execution_time=execution_time or 0.0,
                timestamp=datetime.now(),
                success=success,
                result_count=result_count,
                error_message=error_message,
                user_id=user_id,
                session_id=session_id,
                query_hash=hash(query),
                metadata=metadata or {}
            )
            
            # Add to query history
            db_manager.query_history.append(log_entry.dict())
            
            # Keep only last 1000 entries
            if len(db_manager.query_history) > 1000:
                db_manager.query_history = db_manager.query_history[-1000:]
            
            logger.info(f"Query logged: {query[:50]}... (success: {success})")
            
            return {
                "action": "log",
                "logged": True,
                "query_hash": log_entry.query_hash,
                "timestamp": log_entry.timestamp.isoformat(),
                "total_queries": len(db_manager.query_history)
            }
        
        elif action == "get":
            # Get query history
            limit = metadata.get('limit', 100) if metadata else 100
            offset = metadata.get('offset', 0) if metadata else 0
            
            history = db_manager.query_history[offset:offset + limit]
            
            return {
                "action": "get",
                "query_history": history,
                "total_queries": len(db_manager.query_history),
                "returned_queries": len(history),
                "offset": offset,
                "limit": limit
            }
        
        elif action == "search":
            # Search query history
            search_term = metadata.get('search_term', '') if metadata else ''
            search_type = metadata.get('search_type', 'query') if metadata else 'query'
            
            matching_queries = []
            for entry in db_manager.query_history:
                if search_type == 'query' and search_term.lower() in entry.get('query', '').lower():
                    matching_queries.append(entry)
                elif search_type == 'user' and entry.get('user_id') == search_term:
                    matching_queries.append(entry)
                elif search_type == 'session' and entry.get('session_id') == search_term:
                    matching_queries.append(entry)
            
            return {
                "action": "search",
                "search_term": search_term,
                "search_type": search_type,
                "matching_queries": matching_queries,
                "total_matches": len(matching_queries)
            }
        
        elif action == "stats":
            # Get query statistics
            total_queries = len(db_manager.query_history)
            successful_queries = len([q for q in db_manager.query_history if q.get('success', True)])
            failed_queries = total_queries - successful_queries
            
            if total_queries > 0:
                avg_execution_time = sum(q.get('execution_time', 0) for q in db_manager.query_history) / total_queries
                success_rate = successful_queries / total_queries
            else:
                avg_execution_time = 0.0
                success_rate = 0.0
            
            # Get recent queries (last 24 hours)
            cutoff_time = datetime.now() - timedelta(hours=24)
            recent_queries = [q for q in db_manager.query_history if q.get('timestamp', datetime.min) >= cutoff_time]
            
            # Get most common queries
            query_counts = {}
            for entry in db_manager.query_history:
                query_hash = entry.get('query_hash', 0)
                query_counts[query_hash] = query_counts.get(query_hash, 0) + 1
            
            most_common = sorted(query_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            
            stats = {
                "total_queries": total_queries,
                "successful_queries": successful_queries,
                "failed_queries": failed_queries,
                "success_rate": success_rate,
                "avg_execution_time": avg_execution_time,
                "recent_queries_24h": len(recent_queries),
                "most_common_queries": most_common,
                "unique_queries": len(query_counts)
            }
            
            return {
                "action": "stats",
                "statistics": stats,
                "timestamp": datetime.now().isoformat()
            }
        
        else:
            return {
                "error": f"Invalid action: {action}",
                "available_actions": ["log", "get", "search", "stats"]
            }
        
    except Exception as e:
        logger.error(f"Query history logging failed: {e}")
        return {
            "error": str(e),
            "action": action,
            "logged": False
        }
