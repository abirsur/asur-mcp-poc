"""
View Explorer Tool
Uses database views or stored procedures when applicable
"""

import logging
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class ViewInfo(BaseModel):
    """View information model"""
    view_name: str
    definition: str
    columns: List[Dict[str, Any]]
    dependencies: List[str]
    is_updatable: bool
    security_type: str
    created_date: Optional[str] = None

class StoredProcedureInfo(BaseModel):
    """Stored procedure information model"""
    procedure_name: str
    parameters: List[Dict[str, Any]]
    return_type: str
    security_type: str
    created_date: Optional[str] = None

@tool
async def view_explorer(
    action: str = "list",
    view_name: Optional[str] = None,
    include_dependencies: bool = True
) -> Dict[str, Any]:
    """
    Explores database views and stored procedures for query optimization.
    
    Args:
        action: Action to perform (list, get, analyze, execute)
        view_name: Specific view name to explore
        include_dependencies: Whether to include view dependencies
        
    Returns:
        Dict containing view/procedure information
    """
    try:
        logger.info(f"View explorer action: {action}")
        
        if action == "list":
            # List all available views
            views_query = """
            SELECT 
                TABLE_NAME as view_name,
                VIEW_DEFINITION as definition,
                IS_UPDATABLE as is_updatable,
                SECURITY_TYPE as security_type,
                CREATE_TIME as created_date
            FROM INFORMATION_SCHEMA.VIEWS 
            WHERE TABLE_SCHEMA = %s
            ORDER BY TABLE_NAME
            """
            
            views_result = await db_manager.execute_query(views_query, (db_manager.config.database,))
            
            views = []
            for view in views_result.rows:
                # Get view columns
                columns_query = """
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
                ORDER BY ORDINAL_POSITION
                """
                columns_result = await db_manager.execute_query(columns_query, (db_manager.config.database, view['view_name']))
                
                view_info = ViewInfo(
                    view_name=view['view_name'],
                    definition=view['definition'],
                    columns=columns_result.rows,
                    dependencies=[],
                    is_updatable=view['is_updatable'] == 'YES',
                    security_type=view['security_type'],
                    created_date=str(view['created_date']) if view['created_date'] else None
                )
                
                # Get dependencies if requested
                if include_dependencies:
                    # Extract table names from view definition
                    definition = view['definition'].upper()
                    dependencies = []
                    for table_name in db_manager.get_schema_info().tables.keys():
                        if table_name.upper() in definition:
                            dependencies.append(table_name)
                    view_info.dependencies = dependencies
                
                views.append(view_info)
            
            return {
                "action": "list",
                "views": [view.dict() for view in views],
                "total_views": len(views),
                "database": db_manager.config.database,
                "timestamp": datetime.now().isoformat()
            }
        
        elif action == "get" and view_name:
            # Get specific view information
            view_query = """
            SELECT 
                TABLE_NAME as view_name,
                VIEW_DEFINITION as definition,
                IS_UPDATABLE as is_updatable,
                SECURITY_TYPE as security_type,
                CREATE_TIME as created_date
            FROM INFORMATION_SCHEMA.VIEWS 
            WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
            """
            
            view_result = await db_manager.execute_query(view_query, (db_manager.config.database, view_name))
            
            if not view_result.rows:
                return {
                    "error": f"View '{view_name}' not found",
                    "action": "get",
                    "view_name": view_name
                }
            
            view_data = view_result.rows[0]
            
            # Get view columns
            columns_query = """
            SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_COMMENT
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
            ORDER BY ORDINAL_POSITION
            """
            columns_result = await db_manager.execute_query(columns_query, (db_manager.config.database, view_name))
            
            # Get dependencies
            dependencies = []
            if include_dependencies:
                definition = view_data['definition'].upper()
                for table_name in db_manager.get_schema_info().tables.keys():
                    if table_name.upper() in definition:
                        dependencies.append(table_name)
            
            view_info = ViewInfo(
                view_name=view_data['view_name'],
                definition=view_data['definition'],
                columns=columns_result.rows,
                dependencies=dependencies,
                is_updatable=view_data['is_updatable'] == 'YES',
                security_type=view_data['security_type'],
                created_date=str(view_data['created_date']) if view_data['created_date'] else None
            )
            
            return {
                "action": "get",
                "view_info": view_info.dict(),
                "view_name": view_name,
                "timestamp": datetime.now().isoformat()
            }
        
        elif action == "analyze":
            # Analyze views for optimization opportunities
            views_query = """
            SELECT 
                TABLE_NAME as view_name,
                VIEW_DEFINITION as definition,
                IS_UPDATABLE as is_updatable
            FROM INFORMATION_SCHEMA.VIEWS 
            WHERE TABLE_SCHEMA = %s
            """
            
            views_result = await db_manager.execute_query(views_query, (db_manager.config.database,))
            
            analysis = {
                "total_views": len(views_result.rows),
                "updatable_views": len([v for v in views_result.rows if v['is_updatable'] == 'YES']),
                "read_only_views": len([v for v in views_result.rows if v['is_updatable'] == 'NO']),
                "optimization_opportunities": [],
                "recommendations": []
            }
            
            # Analyze each view
            for view in views_result.rows:
                definition = view['definition']
                
                # Check for complex joins
                if definition.upper().count('JOIN') > 3:
                    analysis["optimization_opportunities"].append({
                        "view": view['view_name'],
                        "issue": "Complex joins",
                        "description": f"View '{view['view_name']}' has {definition.upper().count('JOIN')} joins",
                        "recommendation": "Consider breaking into smaller views"
                    })
                
                # Check for subqueries
                if definition.upper().count('SELECT') > 1:
                    analysis["optimization_opportunities"].append({
                        "view": view['view_name'],
                        "issue": "Subqueries",
                        "description": f"View '{view['view_name']}' contains subqueries",
                        "recommendation": "Consider using JOINs instead of subqueries"
                    })
                
                # Check for aggregations
                if any(agg in definition.upper() for agg in ['COUNT', 'SUM', 'AVG', 'MAX', 'MIN']):
                    analysis["optimization_opportunities"].append({
                        "view": view['view_name'],
                        "issue": "Aggregations",
                        "description": f"View '{view['view_name']}' contains aggregations",
                        "recommendation": "Consider materialized views for better performance"
                    })
            
            # Generate recommendations
            if analysis["total_views"] > 10:
                analysis["recommendations"].append("Consider consolidating similar views")
            
            if analysis["updatable_views"] > 5:
                analysis["recommendations"].append("Review updatable views for security implications")
            
            return {
                "action": "analyze",
                "analysis": analysis,
                "database": db_manager.config.database,
                "timestamp": datetime.now().isoformat()
            }
        
        elif action == "execute" and view_name:
            # Execute view query
            try:
                # Get view definition
                view_query = f"SELECT * FROM {view_name} LIMIT 100"
                result = await db_manager.execute_query(view_query)
                
                return {
                    "action": "execute",
                    "view_name": view_name,
                    "result": result.dict() if hasattr(result, 'dict') else result,
                    "execution_time": result.execution_time,
                    "timestamp": datetime.now().isoformat()
                }
                
            except Exception as e:
                return {
                    "action": "execute",
                    "view_name": view_name,
                    "error": str(e),
                    "result": None
                }
        
        else:
            return {
                "error": f"Invalid action: {action}",
                "available_actions": ["list", "get", "analyze", "execute"]
            }
        
    except Exception as e:
        logger.error(f"View exploration failed: {e}")
        return {
            "error": str(e),
            "action": action,
            "views": [],
            "total_views": 0
        }
