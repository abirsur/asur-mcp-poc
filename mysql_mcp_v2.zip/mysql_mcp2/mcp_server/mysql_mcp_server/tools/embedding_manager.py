"""
Embedding Manager Tool
Generates and stores semantic embeddings for schema terms using FAISS
"""

import logging
import pickle
import numpy as np
import faiss
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class EmbeddingResult(BaseModel):
    """Embedding result model"""
    term: str
    vector: List[float]
    similarity_score: float

@tool
async def embedding_manager(
    action: str = "generate",
    query_term: Optional[str] = None,
    top_k: int = 5
) -> Dict[str, Any]:
    """
    Generates and stores semantic embeddings for schema terms using FAISS.
    
    Args:
        action: Action to perform ("generate", "search", "similarity")
        query_term: Term to search for similarity
        top_k: Number of top similar terms to return
        
    Returns:
        Dict containing embedding results or search results
    """
    try:
        logger.info(f"Embedding manager action: {action}")
        
        if action == "generate":
            # Generate embeddings for schema terms
            await db_manager.initialize_embeddings()
            
            schema_info = db_manager.get_schema_info()
            if not schema_info:
                return {"error": "No schema information available"}
            
            # Extract all schema terms
            terms = []
            for table_name, table_info in schema_info.tables.items():
                terms.append(table_name)
                for column in table_info['columns']:
                    terms.append(f"{table_name}.{column['COLUMN_NAME']}")
            
            return {
                "action": "generate",
                "status": "success",
                "terms_count": len(terms),
                "embedding_dimension": 128,
                "index_type": "IndexFlatIP",
                "terms": terms[:10]  # Show first 10 terms
            }
        
        elif action == "search" and query_term:
            # Search for similar terms
            if not db_manager.embedding_index:
                await db_manager.initialize_embeddings()
            
            if not db_manager.embedding_index:
                return {"error": "Embedding index not available"}
            
            # Generate query vector (simple random for demo, use proper embedding in production)
            query_vector = np.random.rand(1, 128).astype('float32')
            faiss.normalize_L2(query_vector)
            
            # Search for similar vectors
            scores, indices = db_manager.embedding_index.search(query_vector, top_k)
            
            # Get terms from schema
            schema_info = db_manager.get_schema_info()
            if not schema_info:
                return {"error": "No schema information available"}
            
            terms = []
            for table_name, table_info in schema_info.tables.items():
                terms.append(table_name)
                for column in table_info['columns']:
                    terms.append(f"{table_name}.{column['COLUMN_NAME']}")
            
            results = []
            for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
                if idx < len(terms):
                    results.append(EmbeddingResult(
                        term=terms[idx],
                        vector=db_manager.embedding_vectors.get(terms[idx], []).tolist(),
                        similarity_score=float(score)
                    ))
            
            return {
                "action": "search",
                "query_term": query_term,
                "results": [result.dict() for result in results],
                "top_k": top_k
            }
        
        elif action == "similarity" and query_term:
            # Calculate similarity between terms
            if not db_manager.embedding_vectors:
                await db_manager.initialize_embeddings()
            
            # Find the most similar terms
            if query_term in db_manager.embedding_vectors:
                query_vector = db_manager.embedding_vectors[query_term].reshape(1, -1)
                
                # Search for similar vectors
                scores, indices = db_manager.embedding_index.search(query_vector, top_k)
                
                # Get terms
                schema_info = db_manager.get_schema_info()
                terms = []
                for table_name, table_info in schema_info.tables.items():
                    terms.append(table_name)
                    for column in table_info['columns']:
                        terms.append(f"{table_name}.{column['COLUMN_NAME']}")
                
                similar_terms = []
                for score, idx in zip(scores[0], indices[0]):
                    if idx < len(terms) and terms[idx] != query_term:
                        similar_terms.append({
                            "term": terms[idx],
                            "similarity": float(score)
                        })
                
                return {
                    "action": "similarity",
                    "query_term": query_term,
                    "similar_terms": similar_terms
                }
            else:
                return {
                    "action": "similarity",
                    "query_term": query_term,
                    "error": "Term not found in embeddings"
                }
        
        else:
            return {
                "error": "Invalid action or missing query_term",
                "available_actions": ["generate", "search", "similarity"]
            }
            
    except Exception as e:
        logger.error(f"Embedding manager failed: {e}")
        return {
            "error": str(e),
            "action": action
        }
