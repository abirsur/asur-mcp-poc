"""
Error Handler Tool
Centralized exception handler for all tools
"""

import logging
import traceback
from typing import Dict, List, Any, Optional, Union
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime
import asyncio

logger = logging.getLogger(__name__)

class ErrorInfo(BaseModel):
    """Error information model"""
    error_type: str
    error_message: str
    error_code: Optional[str]
    timestamp: datetime
    tool_name: str
    severity: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
    stack_trace: Optional[str]
    context: Dict[str, Any]

@tool
def error_handler(
    error: Union[Exception, str],
    tool_name: str = "unknown",
    context: Optional[Dict[str, Any]] = None,
    severity: str = "MEDIUM"
) -> Dict[str, Any]:
    """
    Centralized exception handler for all tools.
    
    Args:
        error: Exception or error message
        tool_name: Name of the tool that encountered the error
        context: Additional context information
        severity: Error severity level
        
    Returns:
        Dict containing error information and handling results
    """
    try:
        logger.error(f"Error handler called for {tool_name}: {error}")
        
        # Parse error information
        if isinstance(error, Exception):
            error_type = type(error).__name__
            error_message = str(error)
            error_code = getattr(error, 'code', None)
            stack_trace = traceback.format_exc()
        else:
            error_type = "UnknownError"
            error_message = str(error)
            error_code = None
            stack_trace = None
        
        # Determine severity if not provided
        if severity == "MEDIUM":
            if any(keyword in error_message.lower() for keyword in ['timeout', 'connection', 'database']):
                severity = "HIGH"
            elif any(keyword in error_message.lower() for keyword in ['critical', 'fatal', 'abort']):
                severity = "CRITICAL"
            elif any(keyword in error_message.lower() for keyword in ['warning', 'minor', 'info']):
                severity = "LOW"
        
        # Create error info
        error_info = ErrorInfo(
            error_type=error_type,
            error_message=error_message,
            error_code=error_code,
            timestamp=datetime.now(),
            tool_name=tool_name,
            severity=severity,
            stack_trace=stack_trace,
            context=context or {}
        )
        
        # Determine handling strategy based on error type
        handling_strategy = "log_and_continue"
        retry_eligible = False
        user_message = error_message
        
        if error_type in ['ConnectionError', 'TimeoutError', 'asyncio.TimeoutError']:
            handling_strategy = "retry_with_backoff"
            retry_eligible = True
            user_message = "Database connection issue. Retrying..."
        elif error_type in ['PermissionError', 'AccessDeniedError']:
            handling_strategy = "fail_fast"
            user_message = "Access denied. Check permissions."
        elif error_type in ['ValueError', 'TypeError']:
            handling_strategy = "validate_input"
            user_message = "Invalid input provided. Please check parameters."
        elif error_type in ['MemoryError', 'ResourceError']:
            handling_strategy = "reduce_scope"
            user_message = "Resource limit exceeded. Reducing query scope."
        elif severity == "CRITICAL":
            handling_strategy = "fail_fast"
            user_message = "Critical error occurred. Operation aborted."
        
        # Generate error response
        error_response = {
            "error": True,
            "error_info": error_info.dict(),
            "handling_strategy": handling_strategy,
            "retry_eligible": retry_eligible,
            "user_message": user_message,
            "timestamp": datetime.now().isoformat(),
            "suggestions": []
        }
        
        # Add suggestions based on error type
        if error_type == 'ConnectionError':
            error_response["suggestions"].extend([
                "Check database connection settings",
                "Verify network connectivity",
                "Check if database server is running"
            ])
        elif error_type == 'TimeoutError':
            error_response["suggestions"].extend([
                "Increase query timeout",
                "Optimize query performance",
                "Check database load"
            ])
        elif error_type == 'PermissionError':
            error_response["suggestions"].extend([
                "Check user permissions",
                "Verify database access rights",
                "Contact database administrator"
            ])
        elif error_type == 'ValueError':
            error_response["suggestions"].extend([
                "Validate input parameters",
                "Check data types",
                "Review query syntax"
            ])
        
        # Log error details
        logger.error(f"Error in {tool_name}: {error_type} - {error_message}")
        if stack_trace:
            logger.debug(f"Stack trace: {stack_trace}")
        
        return error_response
        
    except Exception as e:
        # Fallback error handling
        logger.critical(f"Error handler itself failed: {e}")
        return {
            "error": True,
            "error_info": {
                "error_type": "ErrorHandlerFailure",
                "error_message": str(e),
                "timestamp": datetime.now().isoformat(),
                "tool_name": "error_handler",
                "severity": "CRITICAL"
            },
            "handling_strategy": "fail_fast",
            "user_message": "System error occurred. Please contact support.",
            "suggestions": ["Contact system administrator", "Check system logs"]
        }
