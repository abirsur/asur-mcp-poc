"""
Metrics Collector Tool
Collects performance metrics and exposes them
"""

import logging
import time
from typing import Dict, List, Any, Optional
from langchain_core.tools import tool
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
from ..db_utils import db_manager

logger = logging.getLogger(__name__)

class PerformanceMetrics(BaseModel):
    """Performance metrics model"""
    timestamp: datetime
    total_queries: int
    successful_queries: int
    failed_queries: int
    average_execution_time: float
    cache_hits: int
    cache_misses: int
    hit_rate: float
    active_connections: int
    schema_cache_age: float

@tool
async def metrics_collector(
    metric_types: List[str] = None,
    time_range: str = "1h"
) -> Dict[str, Any]:
    """
    Collects performance metrics and exposes them.
    
    Args:
        metric_types: Types of metrics to collect (all, queries, cache, connections, schema)
        time_range: Time range for metrics (1h, 24h, 7d)
        
    Returns:
        Dict containing performance metrics
    """
    try:
        logger.info("Collecting performance metrics")
        
        if metric_types is None:
            metric_types = ["all"]
        
        # Get base metrics
        base_metrics = db_manager.get_metrics()
        
        # Calculate time range
        time_ranges = {
            "1h": timedelta(hours=1),
            "24h": timedelta(days=1),
            "7d": timedelta(days=7)
        }
        
        time_delta = time_ranges.get(time_range, timedelta(hours=1))
        cutoff_time = datetime.now() - time_delta
        
        # Filter query history by time range
        query_history = db_manager.get_query_history(limit=1000)
        recent_queries = [
            q for q in query_history 
            if q.get('timestamp', datetime.min) >= cutoff_time
        ]
        
        metrics = {}
        
        # Query metrics
        if "all" in metric_types or "queries" in metric_types:
            query_metrics = {
                "total_queries": len(recent_queries),
                "successful_queries": len([q for q in recent_queries if q.get('success', True)]),
                "failed_queries": len([q for q in recent_queries if not q.get('success', True)]),
                "average_execution_time": sum(q.get('execution_time', 0) for q in recent_queries) / max(len(recent_queries), 1),
                "min_execution_time": min((q.get('execution_time', 0) for q in recent_queries), default=0),
                "max_execution_time": max((q.get('execution_time', 0) for q in recent_queries), default=0),
                "queries_per_minute": len(recent_queries) / max(time_delta.total_seconds() / 60, 1)
            }
            metrics["queries"] = query_metrics
        
        # Cache metrics
        if "all" in metric_types or "cache" in metric_types:
            cache_hits = base_metrics.get("cache_hits", 0)
            cache_misses = base_metrics.get("cache_misses", 0)
            total_cache_requests = cache_hits + cache_misses
            
            cache_metrics = {
                "cache_hits": cache_hits,
                "cache_misses": cache_misses,
                "hit_rate": cache_hits / max(total_cache_requests, 1),
                "miss_rate": cache_misses / max(total_cache_requests, 1),
                "total_cache_requests": total_cache_requests
            }
            metrics["cache"] = cache_metrics
        
        # Connection metrics
        if "all" in metric_types or "connections" in metric_types:
            connection_metrics = {
                "max_connections": db_manager.config.max_connections,
                "min_connections": db_manager.config.min_connections,
                "pool_available": db_manager.pool is not None,
                "database": db_manager.config.database,
                "host": db_manager.config.host,
                "port": db_manager.config.port
            }
            metrics["connections"] = connection_metrics
        
        # Schema metrics
        if "all" in metric_types or "schema" in metric_types:
            schema_info = db_manager.get_schema_info()
            schema_metrics = {
                "schema_available": schema_info is not None,
                "tables_count": len(schema_info.tables) if schema_info else 0,
                "relationships_count": len(schema_info.relationships) if schema_info else 0,
                "indexes_count": len(schema_info.indexes) if schema_info else 0,
                "last_updated": str(schema_info.last_updated) if schema_info else None,
                "embedding_available": db_manager.embedding_index is not None,
                "embedding_vectors_count": len(db_manager.embedding_vectors) if db_manager.embedding_vectors else 0
            }
            metrics["schema"] = schema_metrics
        
        # System metrics
        if "all" in metric_types or "system" in metric_types:
            import psutil
            system_metrics = {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage('/').percent,
                "uptime": time.time() - psutil.boot_time()
            }
            metrics["system"] = system_metrics
        
        # Performance trends
        if "all" in metric_types or "trends" in metric_types:
            # Calculate trends over time
            hourly_queries = {}
            for query in recent_queries:
                hour = query.get('timestamp', datetime.now()).replace(minute=0, second=0, microsecond=0)
                if hour not in hourly_queries:
                    hourly_queries[hour] = 0
                hourly_queries[hour] += 1
            
            trends = {
                "hourly_query_counts": hourly_queries,
                "peak_hour": max(hourly_queries.items(), key=lambda x: x[1])[0] if hourly_queries else None,
                "average_queries_per_hour": len(recent_queries) / max(time_delta.total_seconds() / 3600, 1)
            }
            metrics["trends"] = trends
        
        # Overall performance score
        performance_score = 0.0
        if "queries" in metrics:
            success_rate = metrics["queries"]["successful_queries"] / max(metrics["queries"]["total_queries"], 1)
            performance_score += success_rate * 0.4
        
        if "cache" in metrics:
            hit_rate = metrics["cache"]["hit_rate"]
            performance_score += hit_rate * 0.3
        
        if "queries" in metrics:
            avg_time = metrics["queries"]["average_execution_time"]
            if avg_time < 1.0:  # Less than 1 second
                performance_score += 0.3
            elif avg_time < 5.0:  # Less than 5 seconds
                performance_score += 0.2
            else:
                performance_score += 0.1
        
        result = {
            "metrics": metrics,
            "performance_score": min(performance_score, 1.0),
            "collection_timestamp": datetime.now().isoformat(),
            "time_range": time_range,
            "metric_types": metric_types,
            "summary": {
                "total_metrics": len(metrics),
                "collection_successful": True,
                "performance_rating": "EXCELLENT" if performance_score >= 0.8 else "GOOD" if performance_score >= 0.6 else "FAIR" if performance_score >= 0.4 else "POOR"
            }
        }
        
        logger.info(f"Metrics collected: {len(metrics)} metric types, performance score: {performance_score:.2f}")
        return result
        
    except Exception as e:
        logger.error(f"Metrics collection failed: {e}")
        return {
            "error": str(e),
            "metrics": {},
            "performance_score": 0.0,
            "collection_timestamp": datetime.now().isoformat()
        }
