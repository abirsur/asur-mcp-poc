"""
Database utilities for MySQL MCP Server
Handles connection pooling, schema caching, and query execution
"""

import asyncio
import logging
import json
import pickle
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from functools import lru_cache
from datetime import datetime, timedelta
import aiomysql
from aiocache import Cache, cached
from pydantic import BaseModel, Field
import numpy as np
import faiss
from sqlalchemy import create_engine, text, MetaData, Table, Column, String, Integer
from sqlalchemy.ext.asyncio import create_async_engine
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseConfig(BaseModel):
    """Database configuration model"""
    host: str = Field(default="localhost")
    port: int = Field(default=3306)
    user: str = Field(default="root")
    password: str = Field(default="")
    database: str = Field(default="test")
    charset: str = Field(default="utf8mb4")
    autocommit: bool = Field(default=True)
    max_connections: int = Field(default=20)
    min_connections: int = Field(default=5)

class QueryResult(BaseModel):
    """Query result model"""
    rows: List[Dict[str, Any]]
    count: int
    execution_time: float
    query: str
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class SchemaInfo(BaseModel):
    """Database schema information model"""
    tables: Dict[str, Dict[str, Any]]
    relationships: Dict[str, List[str]]
    indexes: Dict[str, List[str]]
    last_updated: datetime = Field(default_factory=datetime.now)

class DatabaseManager:
    """Manages database connections, schema caching, and query execution"""
    
    def __init__(self):
        self.config = DatabaseConfig(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "3306")),
            user=os.getenv("DB_USER", "root"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "test"),
            max_connections=int(os.getenv("DB_MAX_CONNECTIONS", "20")),
            min_connections=int(os.getenv("DB_MIN_CONNECTIONS", "5"))
        )
        self.pool: Optional[aiomysql.Pool] = None
        self.schema_cache: Optional[SchemaInfo] = None
        self.embedding_index: Optional[faiss.IndexFlatIP] = None
        self.embedding_vectors: Dict[str, np.ndarray] = {}
        self.cache = Cache()
        self.query_history: List[Dict[str, Any]] = []
        self.metrics: Dict[str, Any] = {
            "total_queries": 0,
            "successful_queries": 0,
            "failed_queries": 0,
            "average_execution_time": 0.0,
            "cache_hits": 0,
            "cache_misses": 0
        }
    
    async def initialize(self):
        """Initialize database connection pool"""
        try:
            self.pool = await aiomysql.create_pool(
                host=self.config.host,
                port=self.config.port,
                user=self.config.user,
                password=self.config.password,
                db=self.config.database,
                charset=self.config.charset,
                autocommit=self.config.autocommit,
                minsize=self.config.min_connections,
                maxsize=self.config.max_connections
            )
            logger.info(f"Database pool initialized with {self.config.max_connections} max connections")
            await self.refresh_schema_cache()
            await self.initialize_embeddings()
        except Exception as e:
            logger.error(f"Failed to initialize database pool: {e}")
            raise
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()
            logger.info("Database pool closed")
    
    async def get_connection(self):
        """Get a database connection from the pool"""
        if not self.pool:
            await self.initialize()
        return self.pool.acquire()
    
    @cached(ttl=3600)  # Cache for 1 hour
    async def execute_query(self, query: str, params: Optional[Dict] = None) -> QueryResult:
        """Execute a SQL query and return results"""
        start_time = time.time()
        
        try:
            async with self.get_connection() as conn:
                async with conn.cursor(aiomysql.DictCursor) as cursor:
                    await cursor.execute(query, params)
                    
                    if query.strip().upper().startswith(('SELECT', 'SHOW', 'DESCRIBE', 'EXPLAIN')):
                        rows = await cursor.fetchall()
                        result = QueryResult(
                            rows=rows,
                            count=len(rows),
                            execution_time=time.time() - start_time,
                            query=query
                        )
                    else:
                        result = QueryResult(
                            rows=[],
                            count=cursor.rowcount,
                            execution_time=time.time() - start_time,
                            query=query
                        )
                    
                    # Update metrics
                    self.metrics["total_queries"] += 1
                    self.metrics["successful_queries"] += 1
                    self.metrics["average_execution_time"] = (
                        (self.metrics["average_execution_time"] * (self.metrics["successful_queries"] - 1) + 
                         result.execution_time) / self.metrics["successful_queries"]
                    )
                    
                    # Log query
                    self.query_history.append({
                        "query": query,
                        "execution_time": result.execution_time,
                        "timestamp": datetime.now(),
                        "success": True
                    })
                    
                    return result
                    
        except Exception as e:
            self.metrics["failed_queries"] += 1
            logger.error(f"Query execution failed: {e}")
            raise
    
    async def refresh_schema_cache(self):
        """Refresh the database schema cache"""
        try:
            # Get all tables
            tables_query = """
            SELECT TABLE_NAME, TABLE_TYPE, TABLE_COMMENT
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = %s
            """
            tables_result = await self.execute_query(tables_query, (self.config.database,))
            
            tables = {}
            for table in tables_result.rows:
                table_name = table['TABLE_NAME']
                
                # Get columns for each table
                columns_query = """
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_COMMENT
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
                ORDER BY ORDINAL_POSITION
                """
                columns_result = await self.execute_query(columns_query, (self.config.database, table_name))
                
                tables[table_name] = {
                    'type': table['TABLE_TYPE'],
                    'comment': table['TABLE_COMMENT'],
                    'columns': columns_result.rows
                }
            
            # Get relationships
            relationships_query = """
            SELECT 
                TABLE_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
            WHERE TABLE_SCHEMA = %s 
            AND REFERENCED_TABLE_NAME IS NOT NULL
            """
            relationships_result = await self.execute_query(relationships_query, (self.config.database,))
            
            relationships = {}
            for rel in relationships_result.rows:
                table = rel['TABLE_NAME']
                if table not in relationships:
                    relationships[table] = []
                relationships[table].append({
                    'column': rel['COLUMN_NAME'],
                    'referenced_table': rel['REFERENCED_TABLE_NAME'],
                    'referenced_column': rel['REFERENCED_COLUMN_NAME']
                })
            
            # Get indexes
            indexes_query = """
            SELECT TABLE_NAME, INDEX_NAME, COLUMN_NAME
            FROM INFORMATION_SCHEMA.STATISTICS 
            WHERE TABLE_SCHEMA = %s
            ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX
            """
            indexes_result = await self.execute_query(indexes_query, (self.config.database,))
            
            indexes = {}
            for idx in indexes_result.rows:
                table = idx['TABLE_NAME']
                if table not in indexes:
                    indexes[table] = []
                indexes[table].append({
                    'name': idx['INDEX_NAME'],
                    'column': idx['COLUMN_NAME']
                })
            
            self.schema_cache = SchemaInfo(
                tables=tables,
                relationships=relationships,
                indexes=indexes
            )
            
            logger.info(f"Schema cache refreshed with {len(tables)} tables")
            
        except Exception as e:
            logger.error(f"Failed to refresh schema cache: {e}")
            raise
    
    async def initialize_embeddings(self):
        """Initialize FAISS embedding index for schema terms"""
        try:
            if not self.schema_cache:
                await self.refresh_schema_cache()
            
            # Extract schema terms
            terms = []
            term_to_vector = {}
            
            for table_name, table_info in self.schema_cache.tables.items():
                terms.append(table_name)
                for column in table_info['columns']:
                    terms.append(f"{table_name}.{column['COLUMN_NAME']}")
            
            # Generate simple embeddings (in production, use proper embedding model)
            embedding_dim = 128
            vectors = np.random.rand(len(terms), embedding_dim).astype('float32')
            
            # Normalize vectors
            faiss.normalize_L2(vectors)
            
            # Create FAISS index
            self.embedding_index = faiss.IndexFlatIP(embedding_dim)
            self.embedding_index.add(vectors)
            
            # Store term mappings
            for i, term in enumerate(terms):
                self.embedding_vectors[term] = vectors[i]
            
            # Save embeddings
            with open('schema_embeddings.pkl', 'wb') as f:
                pickle.dump({
                    'terms': terms,
                    'vectors': vectors,
                    'index': self.embedding_index
                }, f)
            
            logger.info(f"Initialized embeddings for {len(terms)} schema terms")
            
        except Exception as e:
            logger.error(f"Failed to initialize embeddings: {e}")
            raise
    
    def get_schema_info(self) -> Optional[SchemaInfo]:
        """Get cached schema information"""
        return self.schema_cache
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        return self.metrics.copy()
    
    def get_query_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get query history"""
        return self.query_history[-limit:]
    
    async def clear_cache(self):
        """Clear all caches"""
        await self.cache.clear()
        self.schema_cache = None
        logger.info("All caches cleared")

# Global database manager instance
db_manager = DatabaseManager()
