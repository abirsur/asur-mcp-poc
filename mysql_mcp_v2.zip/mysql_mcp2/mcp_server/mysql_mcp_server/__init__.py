"""
MySQL MCP Server - Intelligent Database Query Processing
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
