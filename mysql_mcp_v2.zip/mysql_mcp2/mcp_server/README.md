# MySQL MCP Server

A comprehensive MySQL MCP (Multi-Agent Control Plane) server that provides intelligent database query processing through natural language interfaces. Built with FastMCP and designed for scalability and performance.

## 🚀 Features

### Core Capabilities
- **Natural Language Query Processing**: Convert natural language to SQL queries
- **Schema Intelligence**: Automatic schema discovery and relationship mapping
- **Query Optimization**: Built-in query optimization and performance analysis
- **Security**: Read-only enforcement and SQL injection protection
- **Caching**: Intelligent caching for schema and query results
- **Analytics**: Comprehensive logging and performance monitoring

### 30 Intelligent Tools
1. **nl_query_interpreter** - Converts NL queries to structured intent
2. **schema_scanner** - Scans database tables, columns, and relationships
3. **schema_cache_refresher** - Refreshes schema cache periodically
4. **embedding_manager** - Generates semantic embeddings for schema terms
5. **synonym_mapper** - Maps user terms to database schema synonyms
6. **table_selector** - Selects relevant tables for queries
7. **join_path_resolver** - Determines join paths based on relationships
8. **query_constructor** - Builds SQL from interpreted intent
9. **query_optimizer** - Optimizes SQL with index hints and LIMIT clauses
10. **plan_analyzer** - Analyzes EXPLAIN output for bottlenecks
11. **sql_sanitizer** - Sanitizes SQL against injection attacks
12. **query_executor** - Executes SQL asynchronously with pagination
13. **cache_manager** - Manages caching for schema and results
14. **partial_cache_executor** - Streams large results with partial caching
15. **result_formatter** - Formats results into JSON/tabular output
16. **response_ranker** - Ranks candidate SQL queries by confidence
17. **query_history_logger** - Logs all executed queries and metadata
18. **metrics_collector** - Collects performance metrics
19. **feedback_collector** - Captures user feedback for improvement
20. **prompt_tuner** - Dynamically adjusts prompt templates
21. **schema_drift_detector** - Detects database schema changes
22. **anomaly_detector** - Detects anomalies in query performance
23. **permission_checker** - Enforces read-only and access policies
24. **query_timeout_manager** - Manages query timeouts and cancellation
25. **retry_manager** - Handles transient errors with retries
26. **error_handler** - Centralized exception handling
27. **model_selector** - Chooses LLM endpoint by query complexity
28. **multi_query_orchestrator** - Handles multi-part questions
29. **view_explorer** - Uses database views and stored procedures
30. **analytics_logger** - Aggregates and logs analytics data

## 📋 Requirements

- Python 3.9+
- MySQL 5.7+ or 8.0+
- Poetry (for dependency management)

## 🛠️ Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd mysql_mcp_server
   ```

2. **Install dependencies with Poetry**:
   ```bash
   poetry install
   ```

3. **Set up environment variables**:
   ```bash
   cp env.example .env
   # Edit .env with your database credentials
   ```

4. **Configure your database**:
   ```env
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=your_username
   DB_PASSWORD=your_password
   DB_NAME=your_database
   ```

## 🚀 Usage

### Starting the Server

```bash
# Using Poetry
poetry run python -m mysql_mcp_server.main

# Or directly
python -m mysql_mcp_server.main
```

### Example Usage

The server provides 30 intelligent tools for database operations. Here are some examples:

#### Natural Language Query Processing
```python
# Convert natural language to SQL
result = await nl_query_interpreter("Show me all users from California")
```

#### Schema Analysis
```python
# Scan database schema
schema = await schema_scanner(include_row_counts=True)
```

#### Query Execution
```python
# Execute SQL with optimization
result = await query_executor(
    "SELECT * FROM users WHERE state = 'CA'",
    options={"timeout": 30, "max_rows": 1000}
)
```

#### Performance Analysis
```python
# Analyze query performance
analysis = await plan_analyzer("SELECT * FROM users JOIN orders ON users.id = orders.user_id")
```

## 🏗️ Architecture

### Project Structure
```
mysql_mcp_server/
├── main.py                 # Entry point and FastMCP server
├── db_utils.py            # Database utilities and connection management
├── tools/                 # Individual MCP tools
│   ├── nl_query_interpreter.py
│   ├── schema_scanner.py
│   ├── query_executor.py
│   └── ... (30 tools total)
├── .env                   # Environment configuration
├── pyproject.toml         # Poetry configuration
└── README.md              # This file
```

### Key Components

1. **Database Manager**: Handles connection pooling, schema caching, and query execution
2. **Tool System**: 30 specialized tools for different database operations
3. **FastMCP Integration**: Seamless integration with FastMCP framework
4. **Caching Layer**: Intelligent caching for performance optimization
5. **Security Layer**: SQL injection protection and access control

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DB_HOST` | MySQL host | localhost |
| `DB_PORT` | MySQL port | 3306 |
| `DB_USER` | Database user | root |
| `DB_PASSWORD` | Database password | (required) |
| `DB_NAME` | Database name | (required) |
| `DB_MAX_CONNECTIONS` | Max connections | 20 |
| `DB_MIN_CONNECTIONS` | Min connections | 5 |
| `QUERY_TIMEOUT` | Query timeout (seconds) | 30 |
| `ENFORCE_READ_ONLY` | Read-only mode | true |

### Performance Tuning

- **Connection Pooling**: Configure `DB_MAX_CONNECTIONS` and `DB_MIN_CONNECTIONS`
- **Query Timeout**: Set `QUERY_TIMEOUT` for long-running queries
- **Cache Settings**: Adjust cache TTL and size limits
- **Schema Refresh**: Configure automatic schema cache refresh intervals

## 🔒 Security

### Built-in Security Features

- **SQL Injection Protection**: Automatic query sanitization
- **Read-Only Enforcement**: Configurable read-only mode
- **Access Control**: User-based permission checking
- **Query Validation**: Comprehensive query validation and sanitization

### Security Best Practices

1. Use read-only database users when possible
2. Enable SSL/TLS for database connections
3. Regularly update dependencies
4. Monitor query logs for suspicious activity
5. Implement proper access controls

## 📊 Monitoring and Analytics

### Built-in Monitoring

- **Query Performance**: Track execution times and optimization opportunities
- **Schema Changes**: Monitor database schema drift
- **Anomaly Detection**: Identify performance anomalies
- **User Analytics**: Track user behavior and query patterns
- **System Metrics**: Monitor resource usage and performance

### Logging

The server provides comprehensive logging:
- Query execution logs
- Performance metrics
- Error tracking
- User activity logs
- System health monitoring

## 🚀 Performance

### Optimization Features

- **Connection Pooling**: Efficient database connection management
- **Query Caching**: Intelligent caching of query results
- **Schema Caching**: Cached schema information for fast access
- **Embedding Index**: FAISS-based semantic search for schema terms
- **Async Operations**: Non-blocking database operations

### Scalability

- Supports 100+ tables with 10k+ rows each
- Efficient memory usage with streaming results
- Horizontal scaling through connection pooling
- Optimized for high-concurrency scenarios

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Check the documentation
- Review the example configurations

## 🔮 Roadmap

- [ ] Additional database support (PostgreSQL, SQLite)
- [ ] Advanced query optimization
- [ ] Machine learning-based query suggestions
- [ ] Real-time collaboration features
- [ ] Advanced analytics dashboard
- [ ] API rate limiting and throttling
- [ ] Multi-tenant support
- [ ] Advanced security features

---

**Built with ❤️ using FastMCP, LangChain, and modern Python technologies.**
