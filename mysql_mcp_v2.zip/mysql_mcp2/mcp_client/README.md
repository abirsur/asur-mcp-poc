# MySQL MCP Client

A FastAPI-based MCP client that provides intelligent database query processing through natural language interfaces. This client connects to the MySQL MCP Server and supports multiple LLM providers including OpenAI GPT-4o, Google Gemini, and Azure OpenAI.

## 🚀 Features

### Core Capabilities
- **Single API Endpoint**: One endpoint that handles everything using React agent
- **Two-Step Process**: Query refinement followed by execution using React agent
- **Multi-LLM Support**: OpenAI GPT-4o, Google Gemini, Azure OpenAI
- **React Agent Integration**: LangGraph-based reasoning and tool usage
- **Intelligent Query Processing**: Automatic query refinement and optimization
- **Real-time Analytics**: Query performance monitoring and logging
- **Health Monitoring**: Service health checks and status reporting

### How It Works

1. **Query Refinement**: The React agent analyzes your natural language query and refines it to be more specific and actionable
2. **Query Execution**: The same React agent then executes the refined query using the available MCP tools
3. **Result Processing**: The agent formats and presents the results in a user-friendly way

This two-step approach ensures that your queries are properly understood and executed with maximum accuracy.

### API Endpoints
- `POST /query` - Process natural language database queries using React agent
- `GET /health` - Service health check

## 📋 Requirements

- Python 3.9+
- MySQL MCP Server running
- LLM API keys (OpenAI, Google, or Azure)
- Poetry (for dependency management)

## 🛠️ Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd mcp_client
   ```

2. **Install dependencies with Poetry**:
   ```bash
   poetry install
   ```

3. **Set up environment variables**:
   ```bash
   cp env.example .env
   # Edit .env with your API keys and configuration
   ```

4. **Configure your LLM providers**:
   ```env
   # OpenAI
   OPENAI_API_KEY=your_openai_api_key_here
   
   # Google Gemini
   GOOGLE_API_KEY=your_google_api_key_here
   
   # Azure OpenAI
   AZURE_OPENAI_API_KEY=your_azure_api_key_here
   AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
   ```

## 🚀 Usage

### Starting the Client Server

```bash
# Using Poetry
poetry run python -m mcp_client.main

# Or directly
python -m mcp_client.main
```

The server will start on `http://localhost:8001` by default.

### API Usage Examples

#### Process Natural Language Query
```bash
curl -X POST "http://localhost:8001/query" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Show me all users from California",
    "provider": "openai",
    "context": {
      "user_id": "user123",
      "session_id": "session456"
    }
  }'
```

#### Check Service Health
```bash
curl -X GET "http://localhost:8001/health"
```

### Python Client Usage

```python
import httpx
import asyncio

async def query_database():
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://localhost:8001/query",
            json={
                "query": "What are the top 10 customers by revenue?",
                "provider": "openai",
                "context": {
                    "user_id": "user123",
                    "preferences": {"format": "table"}
                }
            }
        )
        return response.json()

# Run the query
result = asyncio.run(query_database())
print(f"Refined Query: {result['refined_query']}")
print(f"Final Result: {result['final_result']}")
print(f"Tools Used: {result['tools_used']}")
print(f"Execution Time: {result['execution_time']:.2f}s")
```

### Example Usage Script

Run the included example script to test the API:

```bash
python mcp_client/example_usage.py
```

## 🏗️ Architecture

### Project Structure
```
mcp_client/
├── main.py                 # FastAPI application and endpoints
├── config.py              # Configuration management
├── mcp_client.py          # MCP server client
├── llm_adapters.py        # LLM provider adapters
├── prompt_generator.py    # Intelligent prompt generation
├── react_agent.py         # LangGraph React agent
├── env.example            # Environment configuration
├── pyproject.toml         # Poetry configuration
└── README.md              # This file
```

### Key Components

1. **FastAPI Application**: REST API server with comprehensive endpoints
2. **MCP Client**: Connection to MySQL MCP Server with tool discovery
3. **LLM Adapters**: Support for OpenAI, Google Gemini, and Azure OpenAI
4. **React Agent**: LangGraph-based reasoning and tool usage
5. **Prompt Generator**: Context-aware prompt optimization
6. **Health Monitoring**: Service health checks and status reporting

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MCP_SERVER_URL` | MCP server URL | http://localhost:8000/mcp |
| `SERVER_HOST` | FastAPI host | 0.0.0.0 |
| `SERVER_PORT` | FastAPI port | 8001 |
| `OPENAI_API_KEY` | OpenAI API key | (required) |
| `GOOGLE_API_KEY` | Google API key | (required) |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI API key | (required) |
| `DEFAULT_LLM_PROVIDER` | Default LLM provider | openai |

### LLM Provider Configuration

#### OpenAI
```env
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_ORGANIZATION=your_org_id_here
```

#### Google Gemini
```env
GOOGLE_API_KEY=your_api_key_here
```

#### Azure OpenAI
```env
AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

## 🔒 Security

### Built-in Security Features

- **API Key Management**: Secure storage and usage of LLM API keys
- **CORS Configuration**: Configurable cross-origin resource sharing
- **Input Validation**: Comprehensive request validation using Pydantic
- **Error Handling**: Secure error responses without sensitive information

### Security Best Practices

1. Use environment variables for API keys
2. Enable HTTPS in production
3. Implement rate limiting
4. Monitor API usage and costs
5. Regularly rotate API keys

## 📊 Monitoring and Analytics

### Built-in Monitoring

- **Health Checks**: Service status and connectivity
- **Performance Metrics**: Query execution times and success rates
- **LLM Usage**: Token usage and cost tracking
- **Error Tracking**: Comprehensive error logging and monitoring

### Analytics Features

- Query performance tracking
- LLM provider comparison
- User behavior analytics
- Cost monitoring and optimization

## 🚀 Performance

### Optimization Features

- **Async Operations**: Non-blocking database and LLM operations
- **Connection Pooling**: Efficient MCP server connections
- **Caching**: Intelligent caching of schema and query results
- **Load Balancing**: Support for multiple LLM providers

### Scalability

- Horizontal scaling through multiple instances
- Load balancing across LLM providers
- Efficient resource utilization
- Auto-scaling capabilities

## 🤝 Integration

### MCP Server Integration

The client seamlessly integrates with the MySQL MCP Server:
- Automatic tool discovery
- Real-time schema updates
- Performance monitoring
- Error handling and retry logic

### LLM Provider Integration

Supports multiple LLM providers with unified interface:
- OpenAI GPT-4o
- Google Gemini Pro
- Azure OpenAI GPT-4o

## 🔮 Advanced Features

### Intelligent Prompt Generation

- Context-aware prompt optimization
- Query complexity analysis
- Template selection based on intent
- Performance optimization

### React Agent Capabilities

- Tool selection and execution
- Multi-step reasoning
- Error handling and recovery
- Result interpretation and formatting

## 🆘 Troubleshooting

### Common Issues

1. **MCP Server Connection**: Ensure the MySQL MCP Server is running
2. **API Key Issues**: Verify LLM provider API keys are correct
3. **Tool Discovery**: Check MCP server health and tool availability
4. **Performance Issues**: Monitor query execution times and LLM usage

### Debug Mode

Enable debug mode for detailed logging:
```env
DEBUG=true
LOG_LEVEL=DEBUG
```

## 📝 API Documentation

### Interactive Documentation

- **Swagger UI**: http://localhost:8001/docs
- **ReDoc**: http://localhost:8001/redoc

### OpenAPI Specification

The API follows OpenAPI 3.0 specification with comprehensive schemas and examples.

## 🚀 Deployment

### Docker Deployment

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY . .

RUN pip install poetry
RUN poetry install --no-dev

EXPOSE 8001
CMD ["poetry", "run", "python", "-m", "mcp_client.main"]
```

### Production Considerations

- Use environment variables for configuration
- Enable HTTPS and security headers
- Implement rate limiting and monitoring
- Set up proper logging and alerting
- Monitor LLM usage and costs

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Check the API documentation
- Review the configuration examples

---

**Built with ❤️ using FastAPI, LangGraph, and modern Python technologies.**
