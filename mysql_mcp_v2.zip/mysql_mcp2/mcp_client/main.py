"""
FastAPI MCP Client Application
Main entry point for the MCP client server
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from datetime import datetime
import uvicorn

from .config import get_config, ServerConfig
from .mcp_client import get_mcp_client, MCPClient
from .react_agent import get_agent, ReactAgent
from .llm_adapters import LLMAdapterFactory

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="MySQL MCP Client",
    description="Intelligent database query processing with MCP integration",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request/Response Models
class QueryRequest(BaseModel):
    """Query request model"""
    query: str = Field(..., description="User query in natural language")
    provider: str = Field(default="openai", description="LLM provider (openai, google, azure)")
    context: Optional[Dict[str, Any]] = Field(default=None, description="Additional context")

class QueryResponse(BaseModel):
    """Query response model"""
    refined_query: str = Field(..., description="Refined query after analysis")
    final_result: str = Field(..., description="Final result from the database")
    tools_used: List[str] = Field(default_factory=list, description="Tools used in processing")
    execution_time: float = Field(..., description="Execution time in seconds")
    success: bool = Field(..., description="Whether the query was successful")
    error: Optional[str] = Field(default=None, description="Error message if any")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str = Field(..., description="Service status")
    healthy: bool = Field(..., description="Whether the service is healthy")
    mcp_connected: bool = Field(..., description="MCP server connection status")
    agents_available: Dict[str, bool] = Field(..., description="Available agents")
    timestamp: str = Field(..., description="Health check timestamp")

# Removed unused response models

# Dependency functions
async def get_mcp_client_dependency() -> MCPClient:
    """Get MCP client dependency"""
    return await get_mcp_client()

async def get_agent_dependency(provider: str = "openai") -> ReactAgent:
    """Get React agent dependency"""
    return await get_agent(provider)

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Initialize services on startup"""
    try:
        logger.info("Starting MCP Client server...")
        
        # Initialize MCP client
        mcp_client = await get_mcp_client()
        logger.info("MCP client initialized")
        
        # Initialize default agent
        agent = await get_agent("openai")
        logger.info("Default React agent initialized")
        
        logger.info("MCP Client server started successfully")
        
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    try:
        logger.info("Shutting down MCP Client server...")
        # Cleanup agents
        from .react_agent import cleanup_agents
        await cleanup_agents()
        logger.info("MCP Client server shutdown complete")
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")

# API Endpoints
@app.get("/", response_model=Dict[str, str])
async def root():
    """Root endpoint"""
    return {
        "message": "MySQL MCP Client API",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/health"
    }

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    try:
        # Check MCP client
        mcp_client = await get_mcp_client()
        mcp_health = await mcp_client.health_check()
        
        # Check available agents
        agents_available = {}
        for provider in ["openai", "google", "azure"]:
            try:
                agent = await get_agent(provider)
                agent_health = await agent.health_check()
                agents_available[provider] = agent_health.get("healthy", False)
            except Exception:
                agents_available[provider] = False
        
        return HealthResponse(
            status="healthy" if mcp_health.get("healthy", False) else "unhealthy",
            healthy=mcp_health.get("healthy", False),
            mcp_connected=mcp_health.get("healthy", False),
            agents_available=agents_available,
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="error",
            healthy=False,
            mcp_connected=False,
            agents_available={},
            timestamp=datetime.now().isoformat()
        )

@app.post("/query", response_model=QueryResponse)
async def process_query(
    request: QueryRequest,
    background_tasks: BackgroundTasks
):
    """Process natural language database query using React agent for both refinement and execution"""
    try:
        logger.info(f"Processing query with {request.provider} provider: {request.query[:100]}...")
        
        # Get agent for specified provider
        agent = await get_agent(request.provider)
        
        # Step 1: Use React agent to refine the query
        refinement_prompt = f"""
        You are a database query refinement expert. Your task is to analyze the user's natural language query and refine it to be more specific and actionable for database operations.

        User Query: {request.query}
        Context: {request.context or "No additional context provided"}

        Please refine this query to be more specific and clear for database operations. Consider:
        1. What specific data the user wants to retrieve
        2. What tables and columns might be involved
        3. Any filters or conditions that should be applied
        4. The expected output format

        Provide a refined, more specific version of the query that will be easier to execute against the database.
        """
        
        refinement_response = await agent.process_query(
            user_query=refinement_prompt,
            context=request.context
        )
        
        refined_query = refinement_response.content
        
        # Step 2: Use React agent to execute the refined query
        execution_prompt = f"""
        You are a database expert. Now execute the refined query to get the actual results from the database.

        Refined Query: {refined_query}
        Original User Query: {request.query}

        Use the available database tools to:
        1. Analyze the database schema if needed
        2. Construct and execute the appropriate SQL query
        3. Format and present the results in a user-friendly way

        Provide the final results from the database.
        """
        
        execution_response = await agent.process_query(
            user_query=execution_prompt,
            context=request.context
        )
        
        # Combine tools used from both steps
        all_tools_used = list(set(refinement_response.tools_used + execution_response.tools_used))
        
        # Calculate total execution time
        total_execution_time = refinement_response.execution_time + execution_response.execution_time
        
        # Log query for analytics
        background_tasks.add_task(
            log_query_analytics,
            request.query,
            request.provider,
            execution_response.success,
            total_execution_time
        )
        
        return QueryResponse(
            refined_query=refined_query,
            final_result=execution_response.content,
            tools_used=all_tools_used,
            execution_time=total_execution_time,
            success=execution_response.success,
            error=execution_response.error,
            metadata={
                "refinement_success": refinement_response.success,
                "execution_success": execution_response.success,
                "provider": request.provider,
                "original_query": request.query
            }
        )
        
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Additional endpoints removed - only keeping the main query endpoint

# Background tasks
async def log_query_analytics(query: str, provider: str, success: bool, execution_time: float):
    """Log query analytics"""
    try:
        # In production, this would log to a proper analytics system
        logger.info(f"Query analytics: {provider}, success: {success}, time: {execution_time:.2f}s")
    except Exception as e:
        logger.error(f"Error logging analytics: {e}")

# Main function
def main():
    """Main function to run the server"""
    config = get_config()
    server_config = config.server
    
    uvicorn.run(
        "mcp_client.main:app",
        host=server_config.host,
        port=server_config.port,
        reload=server_config.debug,
        log_level=server_config.log_level.lower()
    )

if __name__ == "__main__":
    main()
