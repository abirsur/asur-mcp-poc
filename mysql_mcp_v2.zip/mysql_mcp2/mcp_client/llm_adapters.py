"""
LLM Adapters for different providers (OpenAI, Google Gemini, Azure OpenAI)
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Union
from abc import ABC, abstractmethod
from pydantic import BaseModel, Field
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from .config import get_config

logger = logging.getLogger(__name__)

class LLMResponse(BaseModel):
    """Standardized LLM response model"""
    content: str
    model: str
    provider: str
    usage: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class BaseLLMAdapter(ABC):
    """Base class for LLM adapters"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.provider = config.get("provider", "unknown")
        self.model = config.get("model", "unknown")
    
    @abstractmethod
    async def generate_response(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """Generate response from LLM"""
        pass
    
    @abstractmethod
    async def generate_prompt(self, user_query: str, context: Dict[str, Any] = None) -> str:
        """Generate optimized prompt for the user query"""
        pass

class OpenAIAdapter(BaseLLMAdapter):
    """OpenAI GPT-4o adapter"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.base_url = config.get("base_url", "https://api.openai.com/v1")
        self.organization = config.get("organization")
        
        if not self.api_key:
            raise ValueError("OpenAI API key is required")
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def generate_response(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """Generate response using OpenAI API"""
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            if self.organization:
                headers["OpenAI-Organization"] = self.organization
            
            payload = {
                "model": self.model,
                "messages": messages,
                "temperature": kwargs.get("temperature", 0.1),
                "max_tokens": kwargs.get("max_tokens", 4000),
                "stream": False
            }
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{self.base_url}/chat/completions",
                    headers=headers,
                    json=payload
                )
                response.raise_for_status()
                data = response.json()
                
                return LLMResponse(
                    content=data["choices"][0]["message"]["content"],
                    model=self.model,
                    provider="openai",
                    usage=data.get("usage", {}),
                    metadata={"finish_reason": data["choices"][0].get("finish_reason")}
                )
                
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            raise
    
    async def generate_prompt(self, user_query: str, context: Dict[str, Any] = None) -> str:
        """Generate optimized prompt for OpenAI"""
        system_prompt = """You are an expert database analyst and SQL query generator. 
        Your task is to help users interact with a MySQL database through natural language queries.
        
        You have access to a comprehensive set of database tools including:
        - Natural language query interpretation
        - Schema analysis and table selection
        - SQL query construction and optimization
        - Query execution and result formatting
        - Performance analysis and monitoring
        
        Guidelines:
        1. Always analyze the user's intent carefully
        2. Use the available tools to understand the database schema
        3. Construct optimized SQL queries
        4. Provide clear explanations of your reasoning
        5. Handle errors gracefully and suggest alternatives
        
        Current context: {context}
        
        User query: {user_query}
        
        Please provide a comprehensive response that addresses the user's needs."""
        
        return system_prompt.format(
            context=context or "No additional context provided",
            user_query=user_query
        )

class GoogleGeminiAdapter(BaseLLMAdapter):
    """Google Gemini adapter"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        
        if not self.api_key:
            raise ValueError("Google API key is required")
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self.model_instance = genai.GenerativeModel(self.model)
        except ImportError:
            raise ImportError("google-generativeai package is required for Gemini adapter")
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def generate_response(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """Generate response using Google Gemini API"""
        try:
            import google.generativeai as genai
            
            # Convert messages to Gemini format
            prompt = "\n".join([f"{msg['role']}: {msg['content']}" for msg in messages])
            
            response = await asyncio.to_thread(
                self.model_instance.generate_content,
                prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=kwargs.get("temperature", 0.1),
                    max_output_tokens=kwargs.get("max_tokens", 4000)
                )
            )
            
            return LLMResponse(
                content=response.text,
                model=self.model,
                provider="google",
                usage={"prompt_tokens": len(prompt), "completion_tokens": len(response.text)},
                metadata={"finish_reason": "stop"}
            )
            
        except Exception as e:
            logger.error(f"Google Gemini API error: {e}")
            raise
    
    async def generate_prompt(self, user_query: str, context: Dict[str, Any] = None) -> str:
        """Generate optimized prompt for Google Gemini"""
        system_prompt = """You are a specialized database assistant with advanced SQL capabilities.
        
        Your expertise includes:
        - Natural language to SQL translation
        - Database schema analysis and optimization
        - Query performance tuning
        - Data analysis and reporting
        
        You have access to comprehensive database tools for:
        - Schema discovery and relationship mapping
        - Query construction and optimization
        - Result formatting and analysis
        - Performance monitoring and troubleshooting
        
        Context: {context}
        
        User request: {user_query}
        
        Provide a detailed, helpful response that addresses the user's database needs."""
        
        return system_prompt.format(
            context=context or "No additional context",
            user_query=user_query
        )

class AzureOpenAIAdapter(BaseLLMAdapter):
    """Azure OpenAI adapter"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.endpoint = config.get("endpoint")
        self.api_version = config.get("api_version", "2024-02-15-preview")
        self.deployment_name = config.get("deployment_name")
        
        if not all([self.api_key, self.endpoint, self.deployment_name]):
            raise ValueError("Azure OpenAI API key, endpoint, and deployment name are required")
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def generate_response(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """Generate response using Azure OpenAI API"""
        try:
            headers = {
                "api-key": self.api_key,
                "Content-Type": "application/json"
            }
            
            payload = {
                "messages": messages,
                "temperature": kwargs.get("temperature", 0.1),
                "max_tokens": kwargs.get("max_tokens", 4000),
                "stream": False
            }
            
            url = f"{self.endpoint}/openai/deployments/{self.deployment_name}/chat/completions"
            params = {"api-version": self.api_version}
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    url,
                    headers=headers,
                    params=params,
                    json=payload
                )
                response.raise_for_status()
                data = response.json()
                
                return LLMResponse(
                    content=data["choices"][0]["message"]["content"],
                    model=self.deployment_name,
                    provider="azure",
                    usage=data.get("usage", {}),
                    metadata={"finish_reason": data["choices"][0].get("finish_reason")}
                )
                
        except Exception as e:
            logger.error(f"Azure OpenAI API error: {e}")
            raise
    
    async def generate_prompt(self, user_query: str, context: Dict[str, Any] = None) -> str:
        """Generate optimized prompt for Azure OpenAI"""
        system_prompt = """You are an advanced database intelligence system with comprehensive MySQL expertise.
        
        Your capabilities include:
        - Advanced SQL query generation and optimization
        - Database schema analysis and relationship mapping
        - Performance tuning and bottleneck identification
        - Data analysis and business intelligence
        - Query security and best practices
        
        Available tools:
        - Schema discovery and analysis
        - Query construction and optimization
        - Execution planning and monitoring
        - Result formatting and visualization
        - Performance analytics and reporting
        
        Context: {context}
        
        User query: {user_query}
        
        Deliver a comprehensive, accurate response that fully addresses the user's database requirements."""
        
        return system_prompt.format(
            context=context or "No additional context",
            user_query=user_query
        )

class LLMAdapterFactory:
    """Factory for creating LLM adapters"""
    
    @staticmethod
    def create_adapter(provider: str, config: Dict[str, Any]) -> BaseLLMAdapter:
        """Create LLM adapter based on provider"""
        if provider.lower() == "openai":
            return OpenAIAdapter(config)
        elif provider.lower() == "google":
            return GoogleGeminiAdapter(config)
        elif provider.lower() == "azure":
            return AzureOpenAIAdapter(config)
        else:
            raise ValueError(f"Unsupported LLM provider: {provider}")
    
    @staticmethod
    def get_available_providers() -> List[str]:
        """Get list of available LLM providers"""
        return ["openai", "google", "azure"]
