"""
Intelligent Prompt Generation for Database Queries
"""

import logging
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
from datetime import datetime

logger = logging.getLogger(__name__)

class PromptContext(BaseModel):
    """Context for prompt generation"""
    user_query: str
    database_schema: Optional[Dict[str, Any]] = None
    query_history: Optional[List[Dict[str, Any]]] = None
    user_preferences: Optional[Dict[str, Any]] = None
    session_context: Optional[Dict[str, Any]] = None

class GeneratedPrompt(BaseModel):
    """Generated prompt model"""
    system_prompt: str
    user_prompt: str
    context: Dict[str, Any]
    metadata: Dict[str, Any] = Field(default_factory=dict)

class PromptGenerator:
    """Intelligent prompt generator for database queries"""
    
    def __init__(self):
        self.templates = {
            "basic_query": self._get_basic_query_template(),
            "complex_analysis": self._get_complex_analysis_template(),
            "schema_exploration": self._get_schema_exploration_template(),
            "performance_optimization": self._get_performance_optimization_template(),
            "data_analysis": self._get_data_analysis_template()
        }
    
    def generate_prompt(self, context: PromptContext) -> GeneratedPrompt:
        """Generate optimized prompt based on context"""
        try:
            # Analyze query complexity and intent
            query_analysis = self._analyze_query(context.user_query)
            
            # Select appropriate template
            template_type = self._select_template(query_analysis)
            template = self.templates[template_type]
            
            # Generate system prompt
            system_prompt = self._generate_system_prompt(template, context, query_analysis)
            
            # Generate user prompt
            user_prompt = self._generate_user_prompt(context, query_analysis)
            
            # Prepare context
            prompt_context = {
                "query_type": query_analysis["type"],
                "complexity": query_analysis["complexity"],
                "intent": query_analysis["intent"],
                "template_used": template_type,
                "schema_available": context.database_schema is not None,
                "history_available": context.query_history is not None
            }
            
            return GeneratedPrompt(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                context=prompt_context,
                metadata={
                    "generated_at": datetime.now().isoformat(),
                    "query_analysis": query_analysis
                }
            )
            
        except Exception as e:
            logger.error(f"Error generating prompt: {e}")
            # Fallback to basic template
            return self._generate_fallback_prompt(context)
    
    def _analyze_query(self, query: str) -> Dict[str, Any]:
        """Analyze user query to determine intent and complexity"""
        query_lower = query.lower()
        
        # Determine query type
        query_type = "unknown"
        if any(word in query_lower for word in ["show", "list", "get", "find", "search", "display"]):
            query_type = "select"
        elif any(word in query_lower for word in ["count", "sum", "average", "total", "statistics"]):
            query_type = "aggregation"
        elif any(word in query_lower for word in ["join", "relationship", "connect"]):
            query_type = "join"
        elif any(word in query_lower for word in ["analyze", "performance", "optimize"]):
            query_type = "analysis"
        elif any(word in query_lower for word in ["schema", "structure", "tables", "columns"]):
            query_type = "schema"
        
        # Determine complexity
        complexity = "simple"
        if len(query.split()) > 20:
            complexity = "complex"
        elif any(word in query_lower for word in ["join", "group by", "having", "subquery"]):
            complexity = "medium"
        
        # Determine intent
        intent = "data_retrieval"
        if query_type == "analysis":
            intent = "performance_analysis"
        elif query_type == "schema":
            intent = "schema_exploration"
        elif query_type == "aggregation":
            intent = "data_analysis"
        
        return {
            "type": query_type,
            "complexity": complexity,
            "intent": intent,
            "keywords": self._extract_keywords(query),
            "entities": self._extract_entities(query)
        }
    
    def _select_template(self, analysis: Dict[str, Any]) -> str:
        """Select appropriate template based on query analysis"""
        if analysis["intent"] == "schema_exploration":
            return "schema_exploration"
        elif analysis["intent"] == "performance_analysis":
            return "performance_optimization"
        elif analysis["intent"] == "data_analysis":
            return "data_analysis"
        elif analysis["complexity"] == "complex":
            return "complex_analysis"
        else:
            return "basic_query"
    
    def _generate_system_prompt(self, template: str, context: PromptContext, analysis: Dict[str, Any]) -> str:
        """Generate system prompt using template"""
        base_prompt = template.format(
            schema_info=context.database_schema or "No schema information available",
            user_preferences=context.user_preferences or {},
            session_context=context.session_context or {}
        )
        
        # Add context-specific instructions
        if analysis["intent"] == "performance_analysis":
            base_prompt += "\n\nFocus on query performance, optimization opportunities, and bottleneck identification."
        elif analysis["intent"] == "data_analysis":
            base_prompt += "\n\nProvide comprehensive data analysis with insights and recommendations."
        elif analysis["intent"] == "schema_exploration":
            base_prompt += "\n\nFocus on database structure, relationships, and schema understanding."
        
        return base_prompt
    
    def _generate_user_prompt(self, context: PromptContext, analysis: Dict[str, Any]) -> str:
        """Generate user prompt"""
        user_prompt = f"User Query: {context.user_query}"
        
        # Add context if available
        if context.query_history:
            user_prompt += f"\n\nPrevious queries: {len(context.query_history)} queries executed"
        
        # Add specific instructions based on analysis
        if analysis["complexity"] == "complex":
            user_prompt += "\n\nPlease break down this complex query into manageable steps."
        elif analysis["intent"] == "performance_analysis":
            user_prompt += "\n\nAnalyze the performance implications and suggest optimizations."
        
        return user_prompt
    
    def _extract_keywords(self, query: str) -> List[str]:
        """Extract keywords from query"""
        # Simple keyword extraction
        keywords = []
        query_lower = query.lower()
        
        # Database-related keywords
        db_keywords = ["table", "column", "row", "data", "query", "sql", "database"]
        for keyword in db_keywords:
            if keyword in query_lower:
                keywords.append(keyword)
        
        return keywords
    
    def _extract_entities(self, query: str) -> List[str]:
        """Extract potential entities from query"""
        # Simple entity extraction (in production, use NER)
        entities = []
        words = query.split()
        
        # Look for capitalized words (potential table/column names)
        for word in words:
            if word[0].isupper() and len(word) > 2:
                entities.append(word)
        
        return entities
    
    def _generate_fallback_prompt(self, context: PromptContext) -> GeneratedPrompt:
        """Generate fallback prompt when analysis fails"""
        system_prompt = """You are a helpful database assistant. Help the user with their database query needs."""
        user_prompt = f"User Query: {context.user_query}"
        
        return GeneratedPrompt(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            context={"fallback": True},
            metadata={"generated_at": datetime.now().isoformat()}
        )
    
    def _get_basic_query_template(self) -> str:
        """Basic query template"""
        return """You are an expert database assistant specializing in MySQL queries.

Available tools:
- Schema analysis and table discovery
- Query construction and optimization
- Result formatting and analysis
- Performance monitoring

Schema Information: {schema_info}
User Preferences: {user_preferences}
Session Context: {session_context}

Guidelines:
1. Understand the user's intent clearly
2. Use appropriate database tools
3. Provide accurate SQL queries
4. Explain your reasoning
5. Handle errors gracefully"""
    
    def _get_complex_analysis_template(self) -> str:
        """Complex analysis template"""
        return """You are an advanced database analyst with expertise in complex MySQL operations.

Available tools:
- Multi-table join analysis
- Query optimization and performance tuning
- Advanced SQL construction
- Execution plan analysis
- Result interpretation and insights

Schema Information: {schema_info}
User Preferences: {user_preferences}
Session Context: {session_context}

Guidelines:
1. Break down complex queries into logical steps
2. Analyze relationships between tables
3. Optimize for performance
4. Provide detailed explanations
5. Suggest alternative approaches"""
    
    def _get_schema_exploration_template(self) -> str:
        """Schema exploration template"""
        return """You are a database schema expert specializing in MySQL database structure analysis.

Available tools:
- Comprehensive schema scanning
- Relationship mapping
- Table and column analysis
- Index and constraint discovery
- Schema visualization

Schema Information: {schema_info}
User Preferences: {user_preferences}
Session Context: {session_context}

Guidelines:
1. Provide detailed schema information
2. Explain table relationships
3. Identify key constraints and indexes
4. Suggest schema improvements
5. Help with data modeling questions"""
    
    def _get_performance_optimization_template(self) -> str:
        """Performance optimization template"""
        return """You are a MySQL performance optimization expert.

Available tools:
- Query execution plan analysis
- Performance metrics collection
- Index optimization
- Query rewriting
- Bottleneck identification

Schema Information: {schema_info}
User Preferences: {user_preferences}
Session Context: {session_context}

Guidelines:
1. Analyze query performance
2. Identify optimization opportunities
3. Suggest index improvements
4. Recommend query rewrites
5. Provide performance benchmarks"""
    
    def _get_data_analysis_template(self) -> str:
        """Data analysis template"""
        return """You are a data analyst specializing in MySQL data exploration and insights.

Available tools:
- Data aggregation and grouping
- Statistical analysis
- Trend identification
- Data visualization preparation
- Business intelligence queries

Schema Information: {schema_info}
User Preferences: {user_preferences}
Session Context: {session_context}

Guidelines:
1. Focus on data insights
2. Use appropriate aggregations
3. Identify patterns and trends
4. Provide actionable recommendations
5. Present results clearly"""
