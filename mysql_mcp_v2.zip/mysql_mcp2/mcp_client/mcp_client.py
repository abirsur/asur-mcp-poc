"""
MCP Client for connecting to MySQL MCP Server
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from .config import get_config

logger = logging.getLogger(__name__)

class MCPConnectionError(Exception):
    """MCP connection error"""
    pass

class MCPClient:
    """MCP Client for connecting to MySQL MCP Server"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config().mcp.dict()
        self.client: Optional[MultiServerMCPClient] = None
        self.tools: List[BaseTool] = []
        self.connected = False
    
    async def connect(self) -> bool:
        """Connect to MCP server and initialize tools"""
        try:
            logger.info(f"Connecting to MCP server at {self.config['url']}")
            
            # Create MCP client configuration
            mcp_config = {
                "mysql_server": {
                    "transport": "streamable_http",
                    "url": self.config["url"],
                    "headers": self.config.get("headers", {}),
                    "timeout": self.config.get("timeout", 30)
                }
            }
            
            # Initialize MCP client
            self.client = MultiServerMCPClient(mcp_config)
            
            # Get available tools
            self.tools = await self.client.get_tools()
            
            self.connected = True
            logger.info(f"Successfully connected to MCP server with {len(self.tools)} tools")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            self.connected = False
            raise MCPConnectionError(f"Failed to connect to MCP server: {e}")
    
    async def disconnect(self):
        """Disconnect from MCP server"""
        try:
            if self.client:
                # Close any open connections
                await self.client.close()
            self.connected = False
            logger.info("Disconnected from MCP server")
        except Exception as e:
            logger.error(f"Error disconnecting from MCP server: {e}")
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def execute_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """Execute a specific tool on the MCP server"""
        if not self.connected or not self.client:
            raise MCPConnectionError("Not connected to MCP server")
        
        try:
            # Find the tool by name
            tool = None
            for t in self.tools:
                if t.name == tool_name:
                    tool = t
                    break
            
            if not tool:
                raise ValueError(f"Tool '{tool_name}' not found")
            
            # Execute the tool
            result = await tool.ainvoke(kwargs)
            
            logger.info(f"Executed tool '{tool_name}' successfully")
            return result
            
        except Exception as e:
            logger.error(f"Error executing tool '{tool_name}': {e}")
            raise
    
    async def get_available_tools(self) -> List[Dict[str, Any]]:
        """Get list of available tools"""
        if not self.connected:
            return []
        
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "args_schema": tool.args_schema
            }
            for tool in self.tools
        ]
    
    async def health_check(self) -> Dict[str, Any]:
        """Check MCP server health"""
        try:
            if not self.connected:
                return {"status": "disconnected", "healthy": False}
            
            # Try to execute a simple tool to check connectivity
            result = await self.execute_tool("schema_scanner", include_row_counts=False)
            
            return {
                "status": "connected",
                "healthy": True,
                "tools_available": len(self.tools),
                "server_response": "ok"
            }
            
        except Exception as e:
            return {
                "status": "error",
                "healthy": False,
                "error": str(e)
            }
    
    async def get_schema_info(self) -> Dict[str, Any]:
        """Get database schema information"""
        try:
            result = await self.execute_tool("schema_scanner", include_row_counts=True)
            return result
        except Exception as e:
            logger.error(f"Error getting schema info: {e}")
            raise
    
    async def execute_query(self, query: str, **kwargs) -> Dict[str, Any]:
        """Execute a SQL query"""
        try:
            result = await self.execute_tool("query_executor", query=query, **kwargs)
            return result
        except Exception as e:
            logger.error(f"Error executing query: {e}")
            raise
    
    async def interpret_nl_query(self, query: str) -> Dict[str, Any]:
        """Interpret natural language query"""
        try:
            result = await self.execute_tool("nl_query_interpreter", query=query)
            return result
        except Exception as e:
            logger.error(f"Error interpreting NL query: {e}")
            raise
    
    async def optimize_query(self, query: str, **kwargs) -> Dict[str, Any]:
        """Optimize a SQL query"""
        try:
            result = await self.execute_tool("query_optimizer", query=query, **kwargs)
            return result
        except Exception as e:
            logger.error(f"Error optimizing query: {e}")
            raise
    
    async def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        try:
            result = await self.execute_tool("metrics_collector", metric_types=["all"])
            return result
        except Exception as e:
            logger.error(f"Error getting metrics: {e}")
            raise

# Global MCP client instance
mcp_client = MCPClient()

async def get_mcp_client() -> MCPClient:
    """Get the global MCP client instance"""
    if not mcp_client.connected:
        await mcp_client.connect()
    return mcp_client
