"""
Example usage of the MCP Client API
Demonstrates how to use the single query endpoint with React agent
"""

import asyncio
import httpx
import json
from typing import Dict, Any

class MCPClientExample:
    """Example client for MCP API"""
    
    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
    
    async def query_database(self, query: str, provider: str = "openai", context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Query the database using natural language
        
        Args:
            query: Natural language query
            provider: LLM provider (openai, google, azure)
            context: Additional context
            
        Returns:
            Query response with refined query and final result
        """
        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/query",
                    json={
                        "query": query,
                        "provider": provider,
                        "context": context or {}
                    }
                )
                response.raise_for_status()
                return response.json()
                
            except httpx.HTTPError as e:
                return {"error": f"HTTP error: {e}", "success": False}
            except Exception as e:
                return {"error": f"Unexpected error: {e}", "success": False}
    
    async def health_check(self) -> Dict[str, Any]:
        """Check service health"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(f"{self.base_url}/health")
                response.raise_for_status()
                return response.json()
            except Exception as e:
                return {"error": str(e), "healthy": False}

async def main():
    """Main example function"""
    client = MCPClientExample()
    
    print("🔍 Checking service health...")
    health = await client.health_check()
    print(f"Health Status: {health.get('status', 'unknown')}")
    print(f"Healthy: {health.get('healthy', False)}")
    print(f"MCP Connected: {health.get('mcp_connected', False)}")
    print(f"Available Agents: {health.get('agents_available', {})}")
    print()
    
    if not health.get('healthy', False):
        print("❌ Service is not healthy. Please check the MCP server and configuration.")
        return
    
    # Example queries
    example_queries = [
        {
            "query": "Show me all users from California",
            "provider": "openai",
            "context": {"user_id": "demo_user", "session_id": "demo_session"}
        },
        {
            "query": "What are the top 10 customers by revenue?",
            "provider": "openai",
            "context": {"format": "table", "limit": 10}
        },
        {
            "query": "Analyze the performance of our database queries",
            "provider": "openai",
            "context": {"analysis_type": "performance"}
        }
    ]
    
    for i, example in enumerate(example_queries, 1):
        print(f"📝 Example {i}: {example['query']}")
        print(f"Provider: {example['provider']}")
        print(f"Context: {example['context']}")
        print()
        
        result = await client.query_database(
            query=example['query'],
            provider=example['provider'],
            context=example['context']
        )
        
        if result.get('success', False):
            print("✅ Query processed successfully!")
            print(f"Refined Query: {result.get('refined_query', 'N/A')}")
            print(f"Final Result: {result.get('final_result', 'N/A')}")
            print(f"Tools Used: {result.get('tools_used', [])}")
            print(f"Execution Time: {result.get('execution_time', 0):.2f}s")
        else:
            print("❌ Query failed!")
            print(f"Error: {result.get('error', 'Unknown error')}")
        
        print("-" * 80)
        print()

if __name__ == "__main__":
    asyncio.run(main())
