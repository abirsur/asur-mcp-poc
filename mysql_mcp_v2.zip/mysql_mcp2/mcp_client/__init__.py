"""
MCP Client for MySQL Database Query Processing
FastAPI application with intelligent query processing capabilities
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
