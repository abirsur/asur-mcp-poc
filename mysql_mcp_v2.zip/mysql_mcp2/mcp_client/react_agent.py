"""
LangGraph React Agent for Database Query Processing
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional, Union
from langgraph.prebuilt import create_react_agent
from langchain_core.tools import BaseTool
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from pydantic import BaseModel, Field
from datetime import datetime

from .mcp_client import get_mcp_client
from .llm_adapters import LLMAdapterFactory, BaseLLMAdapter
from .prompt_generator import PromptGenerator, PromptContext
from .config import get_config

logger = logging.getLogger(__name__)

class AgentResponse(BaseModel):
    """Agent response model"""
    content: str
    tools_used: List[str] = Field(default_factory=list)
    execution_time: float
    metadata: Dict[str, Any] = Field(default_factory=dict)
    success: bool = True
    error: Optional[str] = None

class ReactAgent:
    """React Agent for database query processing"""
    
    def __init__(self, llm_provider: str = "openai", llm_config: Dict[str, Any] = None):
        self.llm_provider = llm_provider
        self.llm_config = llm_config or {}
        self.llm_adapter: Optional[BaseLLMAdapter] = None
        self.agent = None
        self.tools: List[BaseTool] = []
        self.prompt_generator = PromptGenerator()
        self.initialized = False
    
    async def initialize(self):
        """Initialize the React agent"""
        try:
            logger.info(f"Initializing React agent with {self.llm_provider} provider")
            
            # Get MCP client and tools
            mcp_client = await get_mcp_client()
            self.tools = await mcp_client.get_available_tools()
            
            if not self.tools:
                raise ValueError("No tools available from MCP server")
            
            # Initialize LLM adapter
            config = get_config()
            if self.llm_provider.lower() == "openai":
                self.llm_config = config.openai.dict()
            elif self.llm_provider.lower() == "google":
                self.llm_config = config.google.dict()
            elif self.llm_provider.lower() == "azure":
                self.llm_config = config.azure.dict()
            
            self.llm_adapter = LLMAdapterFactory.create_adapter(
                self.llm_provider, 
                self.llm_config
            )
            
            # Create React agent
            self.agent = create_react_agent(
                self.llm_adapter,
                self.tools
            )
            
            self.initialized = True
            logger.info(f"React agent initialized with {len(self.tools)} tools")
            
        except Exception as e:
            logger.error(f"Failed to initialize React agent: {e}")
            raise
    
    async def process_query(self, user_query: str, context: Dict[str, Any] = None) -> AgentResponse:
        """Process user query using React agent"""
        if not self.initialized:
            await self.initialize()
        
        start_time = datetime.now()
        tools_used = []
        
        try:
            logger.info(f"Processing query: {user_query[:100]}...")
            
            # Generate optimized prompt
            prompt_context = PromptContext(
                user_query=user_query,
                database_schema=context.get("schema") if context else None,
                query_history=context.get("history") if context else None,
                user_preferences=context.get("preferences") if context else None,
                session_context=context.get("session") if context else None
            )
            
            generated_prompt = self.prompt_generator.generate_prompt(prompt_context)
            
            # Prepare messages for the agent
            messages = [
                SystemMessage(content=generated_prompt.system_prompt),
                HumanMessage(content=generated_prompt.user_prompt)
            ]
            
            # Execute with React agent
            response = await self.agent.ainvoke({"messages": messages})
            
            # Extract tools used from the response
            if hasattr(response, "messages"):
                for message in response.messages:
                    if hasattr(message, "tool_calls") and message.tool_calls:
                        for tool_call in message.tool_calls:
                            tools_used.append(tool_call.get("name", "unknown"))
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            # Extract content from response
            content = ""
            if hasattr(response, "messages") and response.messages:
                last_message = response.messages[-1]
                if hasattr(last_message, "content"):
                    content = last_message.content
                elif hasattr(last_message, "text"):
                    content = last_message.text
            
            return AgentResponse(
                content=content,
                tools_used=tools_used,
                execution_time=execution_time,
                metadata={
                    "llm_provider": self.llm_provider,
                    "prompt_generated": True,
                    "context_used": context is not None
                },
                success=True
            )
            
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            execution_time = (datetime.now() - start_time).total_seconds()
            
            return AgentResponse(
                content=f"Error processing query: {str(e)}",
                tools_used=tools_used,
                execution_time=execution_time,
                metadata={"error": str(e)},
                success=False,
                error=str(e)
            )
    
    async def get_available_tools(self) -> List[Dict[str, Any]]:
        """Get list of available tools"""
        if not self.initialized:
            await self.initialize()
        
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "args_schema": tool.args_schema
            }
            for tool in self.tools
        ]
    
    async def health_check(self) -> Dict[str, Any]:
        """Check agent health"""
        try:
            if not self.initialized:
                return {"status": "not_initialized", "healthy": False}
            
            # Test with a simple query
            test_response = await self.process_query("What tables are available?")
            
            return {
                "status": "initialized",
                "healthy": test_response.success,
                "tools_available": len(self.tools),
                "llm_provider": self.llm_provider,
                "test_response": test_response.content[:100] if test_response.success else None
            }
            
        except Exception as e:
            return {
                "status": "error",
                "healthy": False,
                "error": str(e)
            }

# Global agent instances
agents = {}

async def get_agent(provider: str = "openai", config: Dict[str, Any] = None) -> ReactAgent:
    """Get or create React agent for specified provider"""
    if provider not in agents:
        agent = ReactAgent(provider, config)
        await agent.initialize()
        agents[provider] = agent
    
    return agents[provider]

async def cleanup_agents():
    """Cleanup all agent instances"""
    for agent in agents.values():
        if hasattr(agent, 'cleanup'):
            await agent.cleanup()
    agents.clear()
