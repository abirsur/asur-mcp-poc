"""
Configuration management for MCP Client
"""

import os
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class MCPConfig(BaseModel):
    """MCP Server configuration"""
    url: str = Field(default="http://localhost:8000/mcp")
    timeout: int = Field(default=30)
    max_retries: int = Field(default=3)
    headers: Dict[str, str] = Field(default_factory=dict)

class LLMConfig(BaseModel):
    """LLM configuration"""
    provider: str = Field(default="openai")  # "openai", "google", "azure"
    model: str = Field(default="gpt-4o")
    temperature: float = Field(default=0.1)
    max_tokens: int = Field(default=4000)
    timeout: int = Field(default=60)

class OpenAIConfig(LLMConfig):
    """OpenAI specific configuration"""
    api_key: str = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    base_url: Optional[str] = Field(default=None)
    organization: Optional[str] = Field(default=None)

class GoogleConfig(LLMConfig):
    """Google Gemini specific configuration"""
    api_key: str = Field(default_factory=lambda: os.getenv("GOOGLE_API_KEY", ""))
    model: str = Field(default="gemini-pro")

class AzureConfig(LLMConfig):
    """Azure OpenAI specific configuration"""
    api_key: str = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_API_KEY", ""))
    endpoint: str = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_ENDPOINT", ""))
    api_version: str = Field(default="2024-02-15-preview")
    deployment_name: str = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"))

class ServerConfig(BaseModel):
    """FastAPI server configuration"""
    host: str = Field(default="0.0.0.0")
    port: int = Field(default=8001)
    debug: bool = Field(default=False)
    log_level: str = Field(default="INFO")

class ClientConfig(BaseModel):
    """Main client configuration"""
    mcp: MCPConfig = Field(default_factory=MCPConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
    
    # Provider-specific configs
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    google: GoogleConfig = Field(default_factory=GoogleConfig)
    azure: AzureConfig = Field(default_factory=AzureConfig)

# Global configuration instance
config = ClientConfig()

def get_config() -> ClientConfig:
    """Get the global configuration"""
    return config

def update_config(**kwargs) -> None:
    """Update configuration with new values"""
    global config
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)
