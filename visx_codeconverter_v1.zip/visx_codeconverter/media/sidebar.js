(function () {
  const vscode = acquireVsCodeApi();

  function createInitialState() {
    return {
      currentStep: 'START',
      logs: [],
      suggestions: ['Hi'],
      messages: [
        { role: 'system', text: 'Welcome to ltm-dct assistant.' },
        { role: 'system', text: 'Everything happens in this chat. Each message is sent to the local MCP server.' }
      ],
      forms: {
        selectedOperation: '',
        repoUrl: 'https://github.com/sample-org/claims-modernization.git',
        branchName: 'main',
        authType: 'PAT',
        username: 'demo.user',
        secret: 'demo-token',
        aiProvider: 'OpenAI',
        aiModel: 'gpt-4.1',
        aiEndpoint: 'https://api.openai.com/v1',
        aiDeployment: 'conversion-demo',
        kbFiles: 'claims-guide.pdf, api-map.yaml, architecture.md',
        dotnetVersion: '.NET 8',
        architectureType: 'Clean Architecture',
        loggingPattern: 'Serilog',
        errorHandlingPattern: 'Global middleware + try/catch',
        namingStandards: 'REST + PascalCase DTOs',
        duckCreekVersion: 'v12',
        productType: 'Claims',
        configurationTemplates: 'Enterprise Template',
        outputFolder: 'converted-claims-api',
        deploymentPlatform: 'GitHub Actions',
        dockerEnabled: 'Yes',
        kubernetesEnabled: 'No',
        environmentVariables: 'ASPNETCORE_ENVIRONMENT=Development'
      },
      status: 'Ready'
    };
  }

  const state = createInitialState();

  const messagesEl = document.getElementById('messages');
  const suggestionsEl = document.getElementById('suggestions');
  const formTitleEl = document.getElementById('form-title');
  const formSubtitleEl = document.getElementById('form-subtitle');
  const formFieldsEl = document.getElementById('form-fields');
  const logStreamEl = document.getElementById('log-stream');
  const statusEl = document.getElementById('status');
  const currentStepEl = document.getElementById('current-step');
  const suggestionCountEl = document.getElementById('suggestion-count');
  const logCountEl = document.getElementById('log-count');
  const chatInputEl = document.getElementById('chat-input');
  const sendButtonEl = document.getElementById('send-message');
  const resetButtonEl = document.getElementById('reset-workflow');

  function addMessage(role, text) {
    state.messages.push({ role, text });
  }

  function field(name, label, type) {
    const value = state.forms[name] || '';
    if (type === 'textarea') {
      return `
        <div class="field">
          <label for="${name}">${label}</label>
          <textarea id="${name}" data-field="${name}">${value}</textarea>
        </div>
      `;
    }
    return `
      <div class="field">
        <label for="${name}">${label}</label>
        <input id="${name}" data-field="${name}" value="${value}" />
      </div>
    `;
  }

  function renderMessages() {
    messagesEl.innerHTML = state.messages.map((message) => `
      <div class="message ${message.role}">${message.text}</div>
    `).join('');
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function renderSuggestions() {
    suggestionCountEl.textContent = `${state.suggestions.length} ready`;
    suggestionsEl.innerHTML = state.suggestions.map((suggestion) => `
      <button data-suggestion="${suggestion}">${suggestion}</button>
    `).join('');
  }

  function renderForm() {
    const configs = {
      START: ['Conversation', 'Type "Hi" to begin, then choose an operation in chat.', []],
      REPO_INPUT: ['Repository', 'Fill the fields, then type "next".', [
        field('repoUrl', 'Repository URL', 'text'),
        field('branchName', 'Branch Name', 'text'),
        field('authType', 'Authentication Type', 'text'),
        field('username', 'Username', 'text'),
        field('secret', 'Username / PAT', 'text')
      ]],
      AI_CONFIG: ['AI Configuration', 'Fill the fields, then type "next".', [
        field('aiProvider', 'Provider', 'text'),
        field('aiModel', 'Model', 'text'),
        field('aiEndpoint', 'Endpoint', 'text'),
        field('aiDeployment', 'Deployment Name', 'text')
      ]],
      KB_INPUT: ['Knowledge Source', 'Fill the field, then type "next".', [
        field('kbFiles', 'Knowledge Files', 'textarea')
      ]],
      CODING_STANDARD: ['Best Practices', 'Fill the fields, then type "next".', [
        field('dotnetVersion', '.NET Version', 'text'),
        field('architectureType', 'Architecture Type', 'text'),
        field('loggingPattern', 'Logging Pattern', 'text'),
        field('errorHandlingPattern', 'Error Handling Pattern', 'text'),
        field('namingStandards', 'Naming Standards', 'text')
      ]],
      DUCKCREEK_CONFIG: ['Duck Creek Config', 'Fill the fields, then type "next".', [
        field('duckCreekVersion', 'Duck Creek Version', 'text'),
        field('productType', 'Product Type', 'text'),
        field('configurationTemplates', 'Configuration Templates', 'text')
      ]],
      OUTPUT_FOLDER: ['Output Folder', 'Set the folder, then type "next".', [
        field('outputFolder', 'Folder Name', 'text')
      ]],
      CONVERSION: ['Conversion', 'Type "start conversion" in chat.', []],
      DEPLOYMENT: ['Deployment', 'Fill the fields, then type "next".', [
        field('deploymentPlatform', 'Platform', 'text'),
        field('dockerEnabled', 'Docker Enabled', 'text'),
        field('kubernetesEnabled', 'Kubernetes Enabled', 'text'),
        field('environmentVariables', 'Environment Variables', 'textarea')
      ]],
      COMPLETE: ['Review', 'Type "open folder" in chat.', []]
    };

    const [title, subtitle, fields] = configs[state.currentStep] || configs.START;
    formTitleEl.textContent = title;
    formSubtitleEl.textContent = subtitle;
    formFieldsEl.innerHTML = fields.join('');
  }

  function renderLogs() {
    logCountEl.textContent = `${state.logs.length} events`;
    if (!state.logs.length) {
      logStreamEl.innerHTML = '<div class="log-line empty">Waiting for workflow activity. Messages, validation, and conversion updates will appear here.</div>';
      return;
    }

    logStreamEl.innerHTML = state.logs.map((line) => `
      <div class="log-line ${line.includes('complete') || line.includes('validated') || line.includes('created') ? 'success' : ''}">${line}</div>
    `).join('');
  }

  function bindListeners() {
    document.querySelectorAll('[data-field]').forEach((element) => {
      element.addEventListener('input', (event) => {
        const target = event.target;
        state.forms[target.getAttribute('data-field')] = target.value;
      });
    });

    document.querySelectorAll('[data-suggestion]').forEach((button) => {
      button.addEventListener('click', () => {
        const suggestion = button.getAttribute('data-suggestion');
        if (suggestion) {
          sendMessage(suggestion);
        }
      });
    });
  }

  function render() {
    statusEl.textContent = state.status;
    currentStepEl.textContent = state.currentStep.replaceAll('_', ' ');
    renderMessages();
    renderSuggestions();
    renderForm();
    renderLogs();
    bindListeners();
  }

  function resetWorkflow() {
    Object.assign(state, createInitialState());
    chatInputEl.value = '';
    render();
  }

  function sendMessage(rawMessage) {
    const message = rawMessage.trim();
    if (!message) {
      return;
    }

    addMessage('user', message);
    state.status = 'Sending to MCP...';
    vscode.postMessage({
      type: 'chatTurn',
      payload: {
        ...state.forms,
        currentStep: state.currentStep,
        userMessage: message
      }
    });
    chatInputEl.value = '';
    render();
  }

  sendButtonEl.addEventListener('click', () => {
    sendMessage(chatInputEl.value);
  });

  resetButtonEl.addEventListener('click', () => {
    resetWorkflow();
  });

  chatInputEl.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendMessage(chatInputEl.value);
    }
  });

  window.addEventListener('message', (event) => {
    const message = event.data;
    if (message.type !== 'workflowResult') {
      return;
    }

    state.status = message.payload.status || 'Ready';
    state.logs = message.payload.logs || [];
    if (message.payload.nextStep) {
      state.currentStep = message.payload.nextStep;
    }
    if (message.payload.formUpdates) {
      state.forms = { ...state.forms, ...message.payload.formUpdates };
    }
    if (message.payload.suggestions) {
      state.suggestions = message.payload.suggestions;
    }
    if (message.payload.chatMessage) {
      addMessage('system', message.payload.chatMessage);
    }
    render();
  });

  render();
}());
