# ltm-dct assistant

This repository contains a buildable VS Code extension implemented in TypeScript with:

- a sidebar-first chat UI
- a local FastMCP server with sample tools
- automatic local Python environment bootstrap on first activation

## Run locally

1. Install Node dependencies:

   ```powershell
   npm install
   ```

2. Build the extension:

   ```powershell
   npm run build
   ```

3. Open this folder in VS Code and press `F5`.

4. Use the activity bar item `ltm-dct assistant`.

## Runtime bootstrap

On first activation, the extension will:

- create a private virtual environment in VS Code extension storage
- install bundled Python dependencies automatically
- start the local MCP server automatically

Constraint:

- Python 3 must already exist on the machine
- VS Code extensions cannot reliably install the Python runtime itself during extension installation
- the extension auto-installs its local Python packages and bundled services after activation, not at marketplace install time

## Package as VSIX

```powershell
npm run package
```
