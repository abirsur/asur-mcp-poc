import json
from typing import Any, Optional

from fastmcp import FastMCP


mcp = FastMCP("ltm-dct assistant MCP")


def workflow_result(
    status: str,
    logs: list[str],
    next_step: Optional[str] = None,
    chat_message: Optional[str] = None,
    form_updates: Optional[dict[str, str]] = None,
    suggestions: Optional[list[str]] = None,
    ui_action: Optional[str] = None,
) -> dict[str, object]:
    return {
        "status": status,
        "logs": logs,
        "nextStep": next_step,
        "chatMessage": chat_message,
        "formUpdates": form_updates or {},
        "suggestions": suggestions or [],
        "uiAction": ui_action,
    }


def repo_clone_impl(repo_url: str, branch_name: str, auth_type: str, username: str) -> dict[str, object]:
    logs = [
        "[MCP] repo_clone invoked",
        f"[MCP] repository url: {repo_url}",
        f"[MCP] branch found: {branch_name}",
        f"[MCP] auth type: {auth_type}",
        f"[MCP] identity accepted: {username}",
        "[MCP] repository operation complete",
    ]
    return workflow_result(
        "Repository validated and branch exists.",
        logs,
        "AI_CONFIG",
        "Repository operation complete. Please review AI configuration and type next when ready.",
        suggestions=["next", "show ai config"],
    )


def ai_configuration_impl(provider: str, model: str, endpoint: str, deployment_name: str) -> dict[str, object]:
    logs = [
        "[MCP] ai_configuration invoked",
        f"[MCP] provider selected: {provider}",
        f"[MCP] model selected: {model}",
        f"[MCP] endpoint: {endpoint}",
        f"[MCP] deployment: {deployment_name}",
        "[MCP] AI configuration complete",
    ]
    return workflow_result(
        "AI configuration saved.",
        logs,
        "KB_INPUT",
        "AI configuration complete. Fill the knowledge source details and type next.",
        suggestions=["next"],
    )


def knowledge_source_impl(kb_files: str) -> dict[str, object]:
    accepted_files = [item.strip() for item in kb_files.split(",") if item.strip()]
    logs = [
        "[MCP] knowledge_source invoked",
        "[MCP] checking knowledge templates",
        "[MCP] validating mappings",
        *[f"[MCP] accepted: {item}" for item in accepted_files],
        "[MCP] knowledge source complete",
    ]
    return workflow_result(
        "Knowledge base validated.",
        logs,
        "CODING_STANDARD",
        "Knowledge source complete. Provide coding standards and type next.",
        suggestions=["next"],
    )


def best_practice_engine_impl(
    dotnet_version: str,
    architecture_type: str,
    logging_pattern: str,
    error_handling_pattern: str,
    naming_standards: str,
) -> dict[str, object]:
    logs = [
        "[MCP] best_practice_engine invoked",
        f"[MCP] target runtime: {dotnet_version}",
        f"[MCP] architecture: {architecture_type}",
        f"[MCP] logging pattern: {logging_pattern}",
        f"[MCP] error handling: {error_handling_pattern}",
        f"[MCP] naming standards: {naming_standards}",
        "[MCP] best practice review complete",
    ]
    return workflow_result(
        "Coding standards validated.",
        logs,
        "DUCKCREEK_CONFIG",
        "Best practice step complete. Fill Duck Creek configuration and type next.",
        suggestions=["next"],
    )


def duck_creek_config_impl(duck_creek_version: str, product_type: str, configuration_templates: str) -> dict[str, object]:
    logs = [
        "[MCP] duck_creek_config invoked",
        f"[MCP] version: {duck_creek_version}",
        f"[MCP] product type: {product_type}",
        f"[MCP] template: {configuration_templates}",
        "[MCP] Duck Creek step complete",
    ]
    return workflow_result(
        "Duck Creek configuration validated.",
        logs,
        "OUTPUT_FOLDER",
        "Duck Creek step complete. Provide the output folder and type next.",
        suggestions=["next"],
    )


def output_preparation_impl(output_folder: str) -> dict[str, object]:
    logs = [
        "[MCP] output_preparation invoked",
        f"[MCP] preparing output folder: {output_folder}",
        "[MCP] folder created",
        "[MCP] workspace ready",
        "[MCP] output preparation complete",
    ]
    return workflow_result(
        "Output folder created.",
        logs,
        "CONVERSION",
        "Output preparation complete. Type start conversion to run the sample conversion.",
        suggestions=["start conversion"],
    )


def conversion_engine_impl(selected_operation: str, output_folder: str) -> dict[str, object]:
    logs = [
        "[MCP] conversion_engine invoked",
        f"[MCP] operation: {selected_operation}",
        f"[MCP] target folder: {output_folder}",
        "[MCP] repository analyzed",
        "[MCP] knowledge source loaded",
        "[MCP] best practices applied",
        "[MCP] conversion operation complete",
    ]
    return workflow_result(
        "Conversion process completed for sample flow.",
        logs,
        "DEPLOYMENT",
        "Conversion operation complete. Provide deployment inputs and type next.",
        suggestions=["next"],
    )


def pipeline_generator_impl(
    deployment_platform: str,
    docker_enabled: str,
    kubernetes_enabled: str,
    environment_variables: str,
) -> dict[str, object]:
    logs = [
        "[MCP] pipeline_generator invoked",
        f"[MCP] selected platform: {deployment_platform}",
        f"[MCP] docker enabled: {docker_enabled}",
        f"[MCP] kubernetes enabled: {kubernetes_enabled}",
        f"[MCP] environment variables: {environment_variables}",
        "[MCP] pipeline generation complete",
    ]
    return workflow_result(
        "Pipeline generated.",
        logs,
        "COMPLETE",
        "Pipeline generation complete. Type open folder to review the generated sample output.",
        suggestions=["open folder"],
    )


@mcp.tool()
def repo_clone(repo_url: str, branch_name: str, auth_type: str, username: str) -> dict[str, object]:
    return repo_clone_impl(repo_url, branch_name, auth_type, username)


@mcp.tool()
def ai_configuration(provider: str, model: str, endpoint: str, deployment_name: str) -> dict[str, object]:
    return ai_configuration_impl(provider, model, endpoint, deployment_name)


@mcp.tool()
def knowledge_source(kb_files: str) -> dict[str, object]:
    return knowledge_source_impl(kb_files)


@mcp.tool()
def best_practice_engine(
    dotnet_version: str,
    architecture_type: str,
    logging_pattern: str,
    error_handling_pattern: str,
    naming_standards: str,
) -> dict[str, object]:
    return best_practice_engine_impl(
        dotnet_version,
        architecture_type,
        logging_pattern,
        error_handling_pattern,
        naming_standards,
    )


@mcp.tool()
def duck_creek_config(duck_creek_version: str, product_type: str, configuration_templates: str) -> dict[str, object]:
    return duck_creek_config_impl(duck_creek_version, product_type, configuration_templates)


@mcp.tool()
def output_preparation(output_folder: str) -> dict[str, object]:
    return output_preparation_impl(output_folder)


@mcp.tool()
def conversion_engine(selected_operation: str, output_folder: str) -> dict[str, object]:
    return conversion_engine_impl(selected_operation, output_folder)


@mcp.tool()
def pipeline_generator(
    deployment_platform: str,
    docker_enabled: str,
    kubernetes_enabled: str,
    environment_variables: str,
) -> dict[str, object]:
    return pipeline_generator_impl(
        deployment_platform,
        docker_enabled,
        kubernetes_enabled,
        environment_variables,
    )


@mcp.tool()
def chat_workflow_turn(message: str, current_step: str, form_state_json: str) -> dict[str, object]:
    """Handle one interactive chat turn and route to the sample step logic."""
    normalized = message.strip().lower()
    try:
        form_state = json.loads(form_state_json) if form_state_json else {}
    except json.JSONDecodeError:
        form_state = {}

    if current_step == "START":
        if normalized in {"hi", "hello", "start", "begin"}:
            return workflow_result(
                "Conversation started.",
                ["[MCP] chat workflow started"],
                "START",
                "Choose an operation by typing: CBO to API, Claims Activity to API, or Database Migration.",
                suggestions=["CBO to API", "Claims Activity to API", "Database Migration"],
            )
        if "cbo" in normalized:
            return workflow_result(
                "Operation selected.",
                ["[MCP] operation selected: CBO to API Conversion"],
                "REPO_INPUT",
                "CBO to API selected. Fill the repository fields and type next.",
                form_updates={"selectedOperation": "CBO to API Conversion"},
                suggestions=["next"],
            )
        if "claims" in normalized:
            return workflow_result(
                "Operation selected.",
                ["[MCP] operation selected: Claims Custom Activity to API Conversion"],
                "REPO_INPUT",
                "Claims Activity to API selected. Fill the repository fields and type next.",
                form_updates={"selectedOperation": "Claims Custom Activity to API Conversion"},
                suggestions=["next"],
            )
        if "database" in normalized or "migration" in normalized:
            return workflow_result(
                "Operation selected.",
                ["[MCP] operation selected: Database Migration"],
                "REPO_INPUT",
                "Database Migration selected. Fill the repository fields and type next.",
                form_updates={"selectedOperation": "Database Migration"},
                suggestions=["next"],
            )
        return workflow_result(
            "Awaiting greeting.",
            ["[MCP] awaiting greeting or operation selection"],
            "START",
            'Type "Hi" to begin, then type the operation name you want.',
            suggestions=["Hi"],
        )

    if current_step == "REPO_INPUT" and normalized in {"next", "validate", "submit", "done"}:
        return repo_clone_impl(
            form_state.get("repoUrl", ""),
            form_state.get("branchName", "main"),
            form_state.get("authType", "PAT"),
            form_state.get("username", "demo.user"),
        )

    if current_step == "AI_CONFIG" and normalized in {"next", "validate", "submit", "done"}:
        return ai_configuration_impl(
            form_state.get("aiProvider", "OpenAI"),
            form_state.get("aiModel", "gpt-4.1"),
            form_state.get("aiEndpoint", ""),
            form_state.get("aiDeployment", ""),
        )

    if current_step == "KB_INPUT" and normalized in {"next", "validate", "submit", "done"}:
        return knowledge_source_impl(form_state.get("kbFiles", ""))

    if current_step == "CODING_STANDARD" and normalized in {"next", "validate", "submit", "done"}:
        return best_practice_engine_impl(
            form_state.get("dotnetVersion", ".NET 8"),
            form_state.get("architectureType", "Clean Architecture"),
            form_state.get("loggingPattern", "Serilog"),
            form_state.get("errorHandlingPattern", ""),
            form_state.get("namingStandards", ""),
        )

    if current_step == "DUCKCREEK_CONFIG" and normalized in {"next", "validate", "submit", "done"}:
        return duck_creek_config_impl(
            form_state.get("duckCreekVersion", "v12"),
            form_state.get("productType", "Claims"),
            form_state.get("configurationTemplates", ""),
        )

    if current_step == "OUTPUT_FOLDER" and normalized in {"next", "validate", "submit", "done"}:
        return output_preparation_impl(form_state.get("outputFolder", "converted-output"))

    if current_step == "CONVERSION" and (
        normalized in {"start", "start conversion", "run conversion", "convert"}
        or "convert" in normalized
    ):
        return conversion_engine_impl(
            form_state.get("selectedOperation", "CBO to API Conversion"),
            form_state.get("outputFolder", "converted-output"),
        )

    if current_step == "DEPLOYMENT" and normalized in {"next", "validate", "submit", "done"}:
        return pipeline_generator_impl(
            form_state.get("deploymentPlatform", "GitHub Actions"),
            form_state.get("dockerEnabled", "Yes"),
            form_state.get("kubernetesEnabled", "No"),
            form_state.get("environmentVariables", ""),
        )

    if current_step == "COMPLETE" and "open" in normalized and "folder" in normalized:
        return workflow_result(
            "Opening generated folder.",
            ["[MCP] review request acknowledged"],
            "COMPLETE",
            "Opening the generated folder.",
            ui_action="openOutputFolder",
        )

    return workflow_result(
        "Waiting for next step command.",
        [f"[MCP] message received at step {current_step}: {message}"],
        current_step,
        'Update the fields if needed, then type "next" to continue.',
        suggestions=["next"],
    )


if __name__ == "__main__":
    mcp.run()
