import * as vscode from 'vscode';
import * as path from 'path';
import { ChildProcessWithoutNullStreams, spawn } from 'child_process';
import { PythonRuntimeManager } from './pythonRuntime';

export type WorkflowAction =
  | 'validateRepo'
  | 'saveAiConfig'
  | 'validateKb'
  | 'validateCoding'
  | 'validateDuck'
  | 'createOutput'
  | 'startConversion'
  | 'generatePipeline';

export interface WorkflowResult {
  status: string;
  logs: string[];
  nextStep?: string;
  chatMessage?: string;
  formUpdates?: Record<string, string>;
  suggestions?: string[];
  uiAction?: string;
}

interface JsonRpcMessage {
  jsonrpc: '2.0';
  id?: number;
  method?: string;
  params?: unknown;
  result?: unknown;
  error?: {
    code: number;
    message: string;
  };
}

interface McpToolResponse {
  content?: Array<{ type: string; text?: string }>;
  structuredContent?: Record<string, unknown>;
  isError?: boolean;
}

export class McpClient implements vscode.Disposable {
  private readonly outputChannel = vscode.window.createOutputChannel('ltm-dct assistant MCP');
  private process: ChildProcessWithoutNullStreams | undefined;
  private startupPromise: Promise<void> | undefined;
  private messageId = 1;
  private buffer = '';
  private pending = new Map<number, { resolve: (value: unknown) => void; reject: (error: Error) => void }>();

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly runtimeManager: PythonRuntimeManager
  ) {}

  async start(): Promise<void> {
    if (!this.startupPromise) {
      this.startupPromise = this.startInternal();
    }
    return this.startupPromise;
  }

  async invokeWorkflowAction(action: WorkflowAction, payload: Record<string, string>): Promise<WorkflowResult> {
    await this.start();
    const mapping = this.getToolMapping(action, payload);
    const result = await this.sendRequest<McpToolResponse>('tools/call', {
      name: mapping.name,
      arguments: mapping.arguments
    });

    if (result.isError) {
      throw new Error('MCP workflow tool returned an error.');
    }

    const structured = this.extractStructuredContent(result);
    return {
      status: typeof structured.status === 'string' ? structured.status : 'Step completed.',
      logs: Array.isArray(structured.logs)
        ? structured.logs.filter((entry): entry is string => typeof entry === 'string')
        : [],
      nextStep: typeof structured.nextStep === 'string' ? structured.nextStep : undefined,
      chatMessage: typeof structured.chatMessage === 'string' ? structured.chatMessage : undefined,
      formUpdates: this.extractStringMap(structured.formUpdates),
      suggestions: Array.isArray(structured.suggestions)
        ? structured.suggestions.filter((entry): entry is string => typeof entry === 'string')
        : [],
      uiAction: typeof structured.uiAction === 'string' ? structured.uiAction : undefined
    };
  }

  async chatTurn(message: string, currentStep: string, formState: Record<string, string>): Promise<WorkflowResult> {
    await this.start();
    const result = await this.sendRequest<McpToolResponse>('tools/call', {
      name: 'chat_workflow_turn',
      arguments: {
        message,
        current_step: currentStep,
        form_state_json: JSON.stringify(formState)
      }
    });

    if (result.isError) {
      throw new Error('MCP chat workflow returned an error.');
    }

    const structured = this.extractStructuredContent(result);
    return {
      status: typeof structured.status === 'string' ? structured.status : 'Message processed.',
      logs: Array.isArray(structured.logs)
        ? structured.logs.filter((entry): entry is string => typeof entry === 'string')
        : [],
      nextStep: typeof structured.nextStep === 'string' ? structured.nextStep : undefined,
      chatMessage: typeof structured.chatMessage === 'string' ? structured.chatMessage : undefined,
      formUpdates: this.extractStringMap(structured.formUpdates),
      suggestions: Array.isArray(structured.suggestions)
        ? structured.suggestions.filter((entry): entry is string => typeof entry === 'string')
        : [],
      uiAction: typeof structured.uiAction === 'string' ? structured.uiAction : undefined
    };
  }

  dispose(): void {
    this.outputChannel.dispose();
    if (this.process && !this.process.killed) {
      this.process.kill();
    }
  }

  private async startInternal(): Promise<void> {
    const pythonPath = await this.runtimeManager.ensureReady();
    const serverPath = path.join(this.context.extensionPath, 'backend', 'mcp_server.py');

    this.process = spawn(pythonPath, [serverPath], {
      cwd: this.context.extensionPath,
      env: { ...process.env, PYTHONUNBUFFERED: '1' }
    });

    this.process.stdout.on('data', (chunk) => {
      this.handleStdout(chunk.toString());
    });
    this.process.stderr.on('data', (chunk) => {
      this.outputChannel.append(chunk.toString());
    });
    this.process.on('error', (error) => {
      this.outputChannel.appendLine(error.message);
    });
    this.process.on('exit', (code) => {
      this.outputChannel.appendLine(`MCP server exited with code ${code ?? -1}.`);
    });

    await this.sendRequest('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: {
        name: 'ltm-dct-assistant',
        version: '0.0.5'
      }
    });

    this.sendNotification('notifications/initialized', {});
  }

  private sendRequest<T>(method: string, params: unknown): Promise<T> {
    const id = this.messageId++;
    const payload: JsonRpcMessage = {
      jsonrpc: '2.0',
      id,
      method,
      params
    };

    return new Promise<T>((resolve, reject) => {
      this.pending.set(id, {
        resolve: (value: unknown) => {
          resolve(value as T);
        },
        reject
      });
      this.writeMessage(payload);
    });
  }

  private sendNotification(method: string, params: unknown): void {
    this.writeMessage({
      jsonrpc: '2.0',
      method,
      params
    });
  }

  private writeMessage(message: JsonRpcMessage): void {
    if (!this.process) {
      throw new Error('MCP server is not running.');
    }

    this.process.stdin.write(`${JSON.stringify(message)}\n`);
  }

  private handleStdout(chunk: string): void {
    this.buffer += chunk;

    while (true) {
      const newlineIndex = this.buffer.indexOf('\n');
      if (newlineIndex === -1) {
        return;
      }

      const line = this.buffer.slice(0, newlineIndex).trim();
      this.buffer = this.buffer.slice(newlineIndex + 1);
      if (!line) {
        continue;
      }
      this.handleMessage(JSON.parse(line) as JsonRpcMessage);
    }
  }

  private handleMessage(message: JsonRpcMessage): void {
    if (message.method === 'notifications/message') {
      return;
    }

    if (typeof message.id !== 'number') {
      return;
    }

    const pending = this.pending.get(message.id);
    if (!pending) {
      return;
    }

    this.pending.delete(message.id);
    if (message.error) {
      pending.reject(new Error(message.error.message));
      return;
    }
    pending.resolve(message.result);
  }

  private extractStructuredContent(result: McpToolResponse): Record<string, unknown> {
    if (result.structuredContent) {
      return result.structuredContent;
    }

    const firstContent = result.content?.[0]?.text;
    if (!firstContent) {
      return {};
    }

    try {
      return JSON.parse(firstContent) as Record<string, unknown>;
    } catch {
      return {};
    }
  }

  private extractStringMap(value: unknown): Record<string, string> {
    if (!value || typeof value !== 'object') {
      return {};
    }

    return Object.fromEntries(
      Object.entries(value).filter((entry): entry is [string, string] => typeof entry[1] === 'string')
    );
  }

  private getToolMapping(action: WorkflowAction, payload: Record<string, string>): { name: string; arguments: Record<string, string> } {
    switch (action) {
      case 'validateRepo':
        return {
          name: 'repo_clone',
          arguments: {
            repo_url: payload.repoUrl ?? '',
            branch_name: payload.branchName ?? 'main',
            auth_type: payload.authType ?? 'PAT',
            username: payload.username ?? 'demo.user'
          }
        };
      case 'saveAiConfig':
        return {
          name: 'ai_configuration',
          arguments: {
            provider: payload.aiProvider ?? 'OpenAI',
            model: payload.aiModel ?? 'gpt-4.1',
            endpoint: payload.aiEndpoint ?? '',
            deployment_name: payload.aiDeployment ?? ''
          }
        };
      case 'validateKb':
        return {
          name: 'knowledge_source',
          arguments: {
            kb_files: payload.kbFiles ?? ''
          }
        };
      case 'validateCoding':
        return {
          name: 'best_practice_engine',
          arguments: {
            dotnet_version: payload.dotnetVersion ?? '.NET 8',
            architecture_type: payload.architectureType ?? 'Clean Architecture',
            logging_pattern: payload.loggingPattern ?? 'Serilog',
            error_handling_pattern: payload.errorHandlingPattern ?? '',
            naming_standards: payload.namingStandards ?? ''
          }
        };
      case 'validateDuck':
        return {
          name: 'duck_creek_config',
          arguments: {
            duck_creek_version: payload.duckCreekVersion ?? 'v12',
            product_type: payload.productType ?? 'Claims',
            configuration_templates: payload.configurationTemplates ?? ''
          }
        };
      case 'createOutput':
        return {
          name: 'output_preparation',
          arguments: {
            output_folder: payload.outputFolder ?? 'converted-output'
          }
        };
      case 'startConversion':
        return {
          name: 'conversion_engine',
          arguments: {
            selected_operation: payload.selectedOperation ?? 'CBO to API Conversion',
            output_folder: payload.outputFolder ?? 'converted-output'
          }
        };
      case 'generatePipeline':
        return {
          name: 'pipeline_generator',
          arguments: {
            deployment_platform: payload.deploymentPlatform ?? 'GitHub Actions',
            docker_enabled: payload.dockerEnabled ?? 'Yes',
            kubernetes_enabled: payload.kubernetesEnabled ?? 'No',
            environment_variables: payload.environmentVariables ?? ''
          }
        };
      default:
        throw new Error(`Unsupported workflow action: ${action satisfies never}`);
    }
  }
}
