import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { spawn } from 'child_process';

export class PythonRuntimeManager {
  private readonly outputChannel = vscode.window.createOutputChannel('ltm-dct assistant Runtime');
  private setupPromise: Promise<string> | undefined;

  constructor(private readonly context: vscode.ExtensionContext) {}

  async ensureReady(): Promise<string> {
    if (!this.setupPromise) {
      this.setupPromise = this.bootstrap();
    }
    return this.setupPromise;
  }

  dispose(): void {
    this.outputChannel.dispose();
  }

  private async bootstrap(): Promise<string> {
    const basePython = await this.resolveBasePython();
    const runtimeDir = this.context.globalStorageUri.fsPath;
    const venvDir = path.join(runtimeDir, 'python-env');
    const stampPath = path.join(venvDir, '.requirements-stamp');
    const requirementsPath = path.join(this.context.extensionPath, 'requirements.txt');
    const venvPython = this.getVenvPythonPath(venvDir);

    fs.mkdirSync(runtimeDir, { recursive: true });

    if (!fs.existsSync(venvPython)) {
      this.outputChannel.appendLine(`Creating virtual environment at ${venvDir}`);
      await this.run(basePython, ['-m', 'venv', venvDir], this.context.extensionPath);
    }

    const requirementsStamp = fs.readFileSync(requirementsPath, 'utf8');
    const currentStamp = fs.existsSync(stampPath) ? fs.readFileSync(stampPath, 'utf8') : '';
    if (currentStamp !== requirementsStamp) {
      this.outputChannel.appendLine('Installing bundled Python dependencies.');
      await this.run(venvPython, ['-m', 'pip', 'install', '--upgrade', 'pip'], this.context.extensionPath);
      await this.run(venvPython, ['-m', 'pip', 'install', '-r', requirementsPath], this.context.extensionPath);
      fs.writeFileSync(stampPath, requirementsStamp, 'utf8');
    }

    return venvPython;
  }

  private async resolveBasePython(): Promise<string> {
    const configured = vscode.workspace.getConfiguration('python').get<string>('defaultInterpreterPath');
    const candidates = configured
      ? [configured]
      : process.platform === 'win32'
        ? ['py', 'python']
        : ['python3', 'python'];

    for (const candidate of candidates) {
      try {
        await this.run(candidate, ['--version'], this.context.extensionPath);
        return candidate;
      } catch {
        // Try the next candidate.
      }
    }

    throw new Error(
      'Python 3 is required. The extension can auto-install its local runtime and MCP dependencies, but it cannot install Python itself.'
    );
  }

  private getVenvPythonPath(venvDir: string): string {
    return process.platform === 'win32'
      ? path.join(venvDir, 'Scripts', 'python.exe')
      : path.join(venvDir, 'bin', 'python');
  }

  private run(command: string, args: string[], cwd: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      const processHandle = spawn(command, args, {
        cwd,
        env: { ...process.env, PYTHONUNBUFFERED: '1' }
      });

      let stderr = '';
      processHandle.stdout.on('data', (chunk) => {
        this.outputChannel.append(chunk.toString());
      });
      processHandle.stderr.on('data', (chunk) => {
        const text = chunk.toString();
        stderr += text;
        this.outputChannel.append(text);
      });
      processHandle.on('error', (error) => {
        reject(error);
      });
      processHandle.on('exit', (code) => {
        if (code === 0) {
          resolve();
          return;
        }
        reject(new Error(stderr.trim() || `Command failed: ${command} ${args.join(' ')}`));
      });
    });
  }
}
