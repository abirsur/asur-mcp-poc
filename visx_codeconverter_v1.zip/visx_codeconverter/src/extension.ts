import * as vscode from 'vscode';
import { McpClient } from './mcpClient';
import { PythonRuntimeManager } from './pythonRuntime';
import { SidebarViewProvider } from './sidebar/SidebarViewProvider';

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  const runtimeManager = new PythonRuntimeManager(context);
  const mcpClient = new McpClient(context, runtimeManager);
  const sidebarViewProvider = new SidebarViewProvider(context, mcpClient);

  context.subscriptions.push(
    runtimeManager,
    mcpClient,
    vscode.window.registerWebviewViewProvider('ltmDctAssistant.sidebarView', sidebarViewProvider),
    vscode.commands.registerCommand('ltmDctAssistant.focusChat', async () => {
      await vscode.commands.executeCommand('workbench.view.extension.ltmDctAssistant');
    })
  );

  void mcpClient.start().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    void vscode.window.showWarningMessage(`ltm-dct assistant MCP server failed to start: ${message}`);
  });
}

export function deactivate(): void {
  // Backend process disposal is handled by the subscription lifecycle.
}
