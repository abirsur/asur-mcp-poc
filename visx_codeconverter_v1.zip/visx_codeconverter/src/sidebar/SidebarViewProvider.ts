import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { McpClient } from '../mcpClient';

export class SidebarViewProvider implements vscode.WebviewViewProvider {
  private webviewView: vscode.WebviewView | undefined;

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly mcpClient: McpClient
  ) {}

  resolveWebviewView(webviewView: vscode.WebviewView): void {
    this.webviewView = webviewView;
    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.joinPath(this.context.extensionUri, 'media')]
    };
    webviewView.webview.html = this.getHtml(webviewView.webview);
    webviewView.webview.onDidReceiveMessage((message) => {
      void this.handleMessage(message);
    });
  }

  private async handleMessage(message: { type: string; payload?: Record<string, string> }): Promise<void> {
    if (!this.webviewView) {
      return;
    }

    if (message.type === 'openOutputFolder') {
      await this.openOutputFolder(message.payload?.outputFolder ?? 'converted-output');
      return;
    }

    if (message.type !== 'chatTurn') {
      return;
    }

    const payload = message.payload ?? {};
    if (payload.secret) {
      await this.context.secrets.store('ltmDctAssistant.aiSecret', payload.secret);
    }

    try {
      const currentStep = payload.currentStep ?? 'START';
      const userMessage = payload.userMessage ?? '';
      const result = await this.mcpClient.chatTurn(userMessage, currentStep, payload);

      if (result.nextStep === 'DEPLOYMENT' || result.nextStep === 'COMPLETE') {
        this.ensureDemoFiles(payload.outputFolder ?? 'converted-output');
      }

      if (result.uiAction === 'openOutputFolder') {
        await this.openOutputFolder(payload.outputFolder ?? 'converted-output');
      }

      this.webviewView.webview.postMessage({
        type: 'workflowResult',
        payload: result
      });
    } catch (error) {
      const messageText = error instanceof Error ? error.message : String(error);
      void vscode.window.showErrorMessage(`ltm-dct assistant request failed: ${messageText}`);
      this.webviewView.webview.postMessage({
        type: 'workflowResult',
        payload: {
          status: 'MCP workflow unavailable.',
          logs: ['[ERROR] MCP workflow request failed', `[ERROR] ${messageText}`],
          chatMessage: 'The MCP workflow server is not available. Check the runtime bootstrap output and restart the extension host.'
        }
      });
    }
  }

  private async openOutputFolder(folderName: string): Promise<void> {
    const rootPath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? this.context.extensionPath;
    const folderPath = path.join(rootPath, folderName);
    await vscode.commands.executeCommand('revealFileInOS', vscode.Uri.file(folderPath));
  }

  private ensureDemoFiles(folderName: string): void {
    const rootPath = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? this.context.extensionPath;
    const outputRoot = path.join(rootPath, folderName);
    const controllersDir = path.join(outputRoot, 'controllers');
    const servicesDir = path.join(outputRoot, 'services');
    const dtoDir = path.join(outputRoot, 'dto');

    fs.mkdirSync(controllersDir, { recursive: true });
    fs.mkdirSync(servicesDir, { recursive: true });
    fs.mkdirSync(dtoDir, { recursive: true });

    const files: Array<{ filePath: string; contents: string }> = [
      {
        filePath: path.join(controllersDir, 'CustomerController.cs'),
        contents: `using Microsoft.AspNetCore.Mvc;

namespace Converted.Claims.Api.Controllers;

[ApiController]
[Route("api/customers")]
public class CustomerController : ControllerBase
{
    [HttpGet("{id}")]
    public IActionResult GetCustomer(string id)
    {
        return Ok(new { Id = id, Status = "MockConverted" });
    }
}
`
      },
      {
        filePath: path.join(servicesDir, 'CustomerService.cs'),
        contents: `namespace Converted.Claims.Api.Services;

public class CustomerService
{
    public string Convert()
    {
        return "Simulated conversion service";
    }
}
`
      },
      {
        filePath: path.join(dtoDir, 'CustomerDto.cs'),
        contents: `namespace Converted.Claims.Api.Dto;

public record CustomerDto(string Id, string Status);
`
      },
      {
        filePath: path.join(outputRoot, 'conversion-log.txt'),
        contents: `[INFO] Repository cloned
[INFO] Knowledge base loaded
[INFO] Validated coding standards
[INFO] Generating controllers
[INFO] Generating services
[INFO] Conversion completed successfully
`
      },
      {
        filePath: path.join(outputRoot, 'pipeline.yml'),
        contents: `name: conversion-demo

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build
        run: dotnet build
`
      }
    ];

    for (const file of files) {
      if (!fs.existsSync(file.filePath)) {
        fs.writeFileSync(file.filePath, file.contents, 'utf8');
      }
    }
  }

  private getHtml(webview: vscode.Webview): string {
    const cssUri = webview.asWebviewUri(vscode.Uri.joinPath(this.context.extensionUri, 'media', 'sidebar.css'));
    const jsUri = webview.asWebviewUri(vscode.Uri.joinPath(this.context.extensionUri, 'media', 'sidebar.js'));
    const nonce = Date.now().toString();

    return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      http-equiv="Content-Security-Policy"
      content="default-src 'none'; style-src ${webview.cspSource}; script-src 'nonce-${nonce}';"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="${cssUri}" />
  </head>
  <body>
    <div class="chat-shell">
      <div class="hero-card">
        <div class="chat-header">
          <div>
            <div class="eyebrow">Workflow Chat</div>
            <h2>ltm-dct assistant</h2>
            <p class="hero-copy">Guide the repo conversion step by step, review generated inputs, and keep the MCP-driven workflow moving from one place.</p>
          </div>
          <div id="status" class="status-pill">Ready</div>
        </div>

        <div class="hero-metrics">
          <div class="metric">
            <span class="metric-label">Current Step</span>
            <span id="current-step" class="metric-value">START</span>
          </div>
          <div class="metric">
            <span class="metric-label">Suggestions</span>
            <span id="suggestion-count" class="metric-value">1 ready</span>
          </div>
          <div class="metric">
            <span class="metric-label">Log Stream</span>
            <span id="log-count" class="metric-value">0 events</span>
          </div>
        </div>
      </div>

      <div class="messages-card">
        <div class="section-head">
          <h3>Conversation</h3>
          <p class="section-caption">Every prompt is sent to the local MCP server.</p>
        </div>
        <div id="messages" class="messages"></div>
      </div>

      <div class="suggestions-wrap">
        <p class="suggestions-title">Quick prompts</p>
        <div id="suggestions" class="suggestions"></div>
      </div>

      <div class="step-card">
        <div class="step-header">
          <h3 id="form-title">Conversation</h3>
          <p id="form-subtitle">Type "Hi" to begin.</p>
        </div>
        <div id="form-fields" class="form-fields"></div>
      </div>

      <div class="logs-card">
        <div class="logs-topline">
          <div class="logs-title">Latest Logs</div>
          <div class="logs-badge">Live activity</div>
        </div>
        <div id="log-stream" class="log-stream"></div>
      </div>

      <div class="composer">
        <textarea id="chat-input" placeholder="Describe what to build next"></textarea>
        <div class="composer-footer">
          <div class="composer-hint">Press Enter to send, Shift+Enter for a new line.</div>
          <div class="composer-actions">
            <button id="reset-workflow" class="secondary-button" type="button">Reset</button>
            <button id="send-message" type="button">Send</button>
          </div>
        </div>
      </div>
    </div>
    <script nonce="${nonce}" src="${jsUri}"></script>
  </body>
</html>`;
  }
}
